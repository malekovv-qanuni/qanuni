# QANUNI - Legal Practice Management System

## Project Overview
Desktop-first legal ERP application for Lebanese law firms and MENA region. Built with Electron, React, SQLite, and Tailwind CSS. Bilingual Arabic/English support with RTL layout capabilities.

**Current Version:** v44.9  
**Last Updated:** January 25, 2026  
**App.js Lines:** ~5,371

---

## Tech Stack
- **Frontend:** React 18, Tailwind CSS
- **Backend:** Electron, Node.js
- **Database:** SQLite (via sql.js)
- **Icons:** Lucide React

---

## Project Structure

```
C:\Projects\qanuni\
├── src/
│   ├── App.js                    # Main app (~5,371 lines)
│   ├── components/
│   │   ├── lists/                # List components (10 total)
│   │   │   ├── index.js          # Exports all list components
│   │   │   ├── ClientsList.js    # Client management
│   │   │   ├── MattersList.js    # Matter/case management
│   │   │   ├── HearingsList.js   # Court hearings
│   │   │   ├── TimesheetsList.js # Time tracking (filters, pagination)
│   │   │   ├── ExpensesList.js   # Expense tracking (filters, pagination)
│   │   │   ├── TasksList.js      # Task management (filters, grouped sections)
│   │   │   ├── DeadlinesList.js  # Deadline tracking (filters, status tabs, pagination)
│   │   │   ├── InvoicesList.js   # Invoice management (filters, pagination)
│   │   │   ├── AdvancesList.js   # Payments/advances (sub-tabs, lawyer balances)
│   │   │   └── AppointmentsList.js # Appointments (basic table)
│   │   └── common/
│   │       └── index.js          # EmptyState, LoadingSpinner, etc.
│   └── forms/                    # Form components (12 total)
│       ├── index.js              # Exports all form components
│       ├── ClientForm.js
│       ├── MatterForm.js
│       ├── HearingForm.js
│       ├── TaskForm.js
│       ├── TimesheetForm.js
│       ├── ExpenseForm.js
│       ├── DeadlineForm.js
│       ├── InvoiceForm.js
│       ├── JudgmentForm.js
│       ├── AppointmentForm.js
│       ├── AdvanceForm.js
│       └── LawyerForm.js
├── main.js                       # Electron main process, IPC handlers
├── preload.js                    # IPC bridge (electronAPI)
├── package.json
└── CHECKPOINT_v44.9.md           # Latest checkpoint
```

---

## Core Modules (17)

| Module | List Component | Form Component | Features |
|--------|---------------|----------------|----------|
| Clients | ClientsList.js | ClientForm.js | Search, CRUD |
| Matters | MattersList.js | MatterForm.js | Search, CRUD, status tracking |
| Hearings | HearingsList.js | HearingForm.js | Calendar view, filters |
| Tasks | TasksList.js | TaskForm.js | Filters, summary cards, grouped sections |
| Timesheets | TimesheetsList.js | TimesheetForm.js | Filters, pagination, summary cards |
| Expenses | ExpensesList.js | ExpenseForm.js | Filters, pagination, summary cards |
| Deadlines | DeadlinesList.js | DeadlineForm.js | Filters, status tabs, pagination |
| Invoices | InvoicesList.js | InvoiceForm.js | Filters, pagination, Edit for drafts |
| Judgments | (inline) | JudgmentForm.js | Linked to hearings |
| Appointments | AppointmentsList.js | AppointmentForm.js | Calendar integration |
| Advances | AdvancesList.js | AdvanceForm.js | Sub-tabs (fees/trust), lawyer balances |
| Lawyers | (inline) | LawyerForm.js | Staff management |
| Calendar | (inline) | - | Monthly/weekly/daily views, click date → day view |
| Dashboard | (inline) | - | Stats, upcoming items |
| Reports | (inline) | - | Client Statement, Case Status, Client 360° |
| Settings | (inline) | - | Firm info, lookups |
| Corporate | (inline) | - | Entity management |

---

## Reports (v44.x)

| Report | Description | Exports |
|--------|-------------|---------|
| Client Statement | Financial report - invoices, payments, balance | PDF, Excel |
| Case Status Report | Case-focused - matters, hearings, judgments, deadlines | PDF, Excel |
| Client 360° Report | Comprehensive - all client data for internal management | PDF, Excel |

---

## Component Patterns

### List Components (Extracted)
All extracted list components follow this pattern:
- Receive data and setters as props from App.js
- Use `window.electronAPI` directly for database operations
- Include local `formatDate` utility function
- Import `EmptyState` from `../common`

**Props Pattern:**
```javascript
const ModuleList = ({
  data,              // Array of records
  filters,           // Filter state object
  setFilters,        // Filter setter
  page,              // Current page number
  setPage,           // Page setter
  pageSize,          // Items per page
  setPageSize,       // Page size setter
  clients,           // Lookup data
  matters,           // Lookup data
  language,          // 'en' or 'ar'
  t,                 // Translations object
  setEditing,        // Set record for editing
  setShowForm,       // Toggle form visibility
  showConfirm,       // Confirmation dialog
  showToast,         // Toast notifications
  hideConfirm,       // Hide confirmation
  refreshData        // Refresh function
}) => { ... }
```

### Enhanced Lists Features
- **Summary Cards:** 3-4 cards showing key metrics
- **Filter Bar:** Client, Matter (cascading), Status, Date range
- **Pagination:** 25/50/100 per page with Prev/Next
- **Clear Filters:** Button appears when filters active

---

## State Management

### Filter State (App.js)
```javascript
// Timesheet filters & pagination
const [timesheetFilters, setTimesheetFilters] = useState({
  clientId: '', matterId: '', lawyerId: '', billable: '', dateFrom: '', dateTo: ''
});
const [timesheetPage, setTimesheetPage] = useState(1);
const [timesheetPageSize, setTimesheetPageSize] = useState(25);

// Similar pattern for: expenses, tasks, deadlines, invoices
```

### Cascading Dropdowns
Client → Matter filtering uses String() for type-safe comparison:
```javascript
const filteredMatters = filters.clientId 
  ? matters.filter(m => String(m.client_id) === String(filters.clientId))
  : [];
```

### Calendar State (App level)
```javascript
const [calendarView, setCalendarView] = useState('weekly'); // daily, weekly, monthly
const [calendarDate, setCalendarDate] = useState(new Date());
```

---

## Database Schema (Key Tables)

- `clients` - Client information
- `matters` - Cases/matters linked to clients
- `hearings` - Court hearings linked to matters
- `tasks` - Task management with assignments
- `timesheets` - Time tracking entries
- `expenses` - Expense records
- `deadlines` - Deadline tracking
- `invoices` / `invoice_items` - Billing
- `judgments` - Court decisions
- `appointments` - Calendar appointments
- `advances` - Fee advances and trust accounts
- `lawyers` - Staff/lawyer records
- `corporate_entities` - Corporate secretary module

---

## IPC Handlers (preload.js → main.js)

All database operations go through `window.electronAPI`:
```javascript
// CRUD pattern for each module
window.electronAPI.getClients()
window.electronAPI.saveClient(data)
window.electronAPI.updateClient(data)
window.electronAPI.deleteClient(id)

// Refresh functions in App.js
const refreshClients = async () => {
  const data = await window.electronAPI.getClients();
  setClients(data || []);
};
```

---

## Development Workflow

### Session Start
1. Upload checkpoint zip or current files
2. State version: "Starting from v##"
3. List what to fix/add

### During Development
- Use `str_replace` tool for edits (preserves UTF-8 encoding)
- Work incrementally - one fix at a time
- Test after each major change

### Session End
1. Download modified files
2. Open in VS Code (preserves UTF-8)
3. Save to project folder
4. Test changes
5. Git commit: `git commit -m "v##: description"`
6. Create checkpoint if major changes

### Rules
- ❌ NEVER use PowerShell for file edits
- ✅ ALWAYS use VS Code for file editing
- ✅ ALWAYS verify Arabic text after changes
- ✅ Create checkpoint for major structural changes

---

## Git Workflow

```powershell
cd C:\Projects\qanuni
git add -A
git commit -m "v44.9: Extract AdvancesList, AppointmentsList, calendar click fix"
git tag v44.9
git log --oneline -5
```

---

## Known Issues / TODO

### Medium Priority
- Dashboard "Pending Judgments" title (clarify issue)

### UX Consistency Roadmap
Standardize filtering/display patterns across all list components for uniform UX:

**Target Pattern (from InvoicesList/TimesheetsList):**
- Summary cards (clickable to filter)
- Smart search (multi-field)
- Filter chips with "Clear All"
- Date presets dropdown
- Cascading dropdowns (Client → Matter)
- Pagination (25/50/100)

**Components needing upgrade:**
- ClientsList - Add search, pagination
- MattersList - Add search, pagination  
- HearingsList - Add summary cards, search, filter chips, pagination
- TasksList - Add date presets, pagination
- AdvancesList - Add smart search, filter chips
- AppointmentsList - Add all filter features

### Enhancements
- Conflict Check: True conflict of interest logic

### Future Roadmap
- Add ~18 Lebanese court types (religious, commercial, specialized)
- Corporate Secretary enhancements (company registration, shareholder management)

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| v44.9 | Jan 25, 2026 | Extract AdvancesList, AppointmentsList components |
| v44.7 | Jan 25, 2026 | Calendar click date → day view fix (state lifting) |
| v44.5 | Jan 25, 2026 | Client 360° Report with Excel/PDF exports |
| v42.8 | Jan 24, 2026 | Extract DeadlinesList, InvoicesList, Invoice Edit button |
| v42.7 | Jan 24, 2026 | Extract TimesheetsList, ExpensesList, TasksList |

---

## Completed Items

- ✅ Double-click issues in forms (state lifting fix)
- ✅ Calendar click date → day view
- ✅ Client 360° Report
- ✅ All 10 list components extracted
- ✅ All 12 form components extracted
- ✅ InvoicesList hybrid filter pattern (summary cards, search, filter chips, date presets)

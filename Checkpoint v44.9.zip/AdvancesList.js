import React, { useState } from 'react';
import { Plus } from 'lucide-react';

// Local utility function
const formatDate = (dateStr) => {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
};

const AdvancesList = ({
  advances,
  lawyers,
  expenses,
  clients,
  language,
  t,
  setShowAdvanceForm,
  setEditingAdvance,
  showConfirm,
  hideConfirm,
  showToast,
  refreshAdvances
}) => {
  const [activeTab, setActiveTab] = useState('fees');
  const [clientFilter, setClientFilter] = useState('');
  const [lawyerFilter, setLawyerFilter] = useState('');
  
  // Helper to check if type is a fee (retainer or fee_payment_*)
  const isFeeType = (type) => type === 'client_retainer' || type?.startsWith('fee_payment');
  
  // Calculate totals by category
  const totals = {
    retainers: advances.filter(a => a.advance_type === 'client_retainer').reduce((sum, a) => sum + parseFloat(a.amount || 0), 0),
    expenseAdvances: advances.filter(a => a.advance_type === 'client_expense_advance').reduce((sum, a) => sum + parseFloat(a.amount || 0), 0),
    feePayments: advances.filter(a => a.advance_type?.startsWith('fee_payment')).reduce((sum, a) => sum + parseFloat(a.amount || 0), 0),
    lawyerAdvances: advances.filter(a => a.advance_type === 'lawyer_advance').reduce((sum, a) => sum + parseFloat(a.amount || 0), 0),
  };
  // Combined fees total (retainers + fee payments)
  totals.allFees = totals.retainers + totals.feePayments;
  
  // Calculate per-lawyer net balances from advance records AND expenses
  const lawyerBalances = lawyers.map(lawyer => {
    const lawyerAdvances = advances.filter(a => a.advance_type === 'lawyer_advance' && a.lawyer_id === lawyer.lawyer_id);
    const totalAdvanced = lawyerAdvances.reduce((sum, a) => sum + parseFloat(a.amount || 0), 0);
    
    // If lawyer has advances, use balance_remaining to calculate net balance
    // This already accounts for deductions made from advances
    const balanceFromAdvances = lawyerAdvances.reduce((sum, a) => sum + parseFloat(a.balance_remaining ?? a.amount ?? 0), 0);
    
    // Also check for expenses paid by this lawyer that might not be linked to advances yet
    // (e.g., lawyer paid out of pocket before receiving an advance)
    const expensesPaidByLawyer = expenses
      .filter(e => e.paid_by_lawyer_id === lawyer.lawyer_id)
      .reduce((sum, e) => sum + parseFloat(e.amount || 0), 0);
    
    // If there are advances, spent = advanced - balance_remaining
    // If no advances but has expenses, those are unreimbursed expenses
    const spentFromAdvances = totalAdvanced - balanceFromAdvances;
    
    // For display, we show the larger of: spent from advances OR expenses paid
    // This handles the case where expenses are tracked both ways during transition
    const totalSpent = Math.max(spentFromAdvances, expensesPaidByLawyer);
    
    // Net balance: what was advanced minus what was spent
    const netBalance = totalAdvanced - totalSpent;
    
    return {
      lawyer_id: lawyer.lawyer_id,
      name: lawyer.full_name || lawyer.name,
      totalAdvanced,
      totalSpent,
      netBalance
    };
  }).filter(lb => lb.totalAdvanced > 0 || lb.totalSpent > 0); // Only show lawyers with activity
  
  // Filter advances based on active tab
  const filteredAdvances = advances.filter(adv => {
    // Tab filter
    if (activeTab === 'fees' && !isFeeType(adv.advance_type)) return false;
    if (activeTab === 'expense_advances' && adv.advance_type !== 'client_expense_advance') return false;
    if (activeTab === 'lawyer_advances' && adv.advance_type !== 'lawyer_advance') return false;
    
    // Client filter (for non-lawyer advances)
    if (clientFilter && adv.advance_type !== 'lawyer_advance' && adv.client_id !== clientFilter) return false;
    
    // Lawyer filter (for lawyer advances)
    if (lawyerFilter && adv.advance_type === 'lawyer_advance' && adv.lawyer_id !== lawyerFilter) return false;
    
    return true;
  });
  
  // Get type label
  const getTypeLabel = (type) => {
    switch(type) {
      case 'client_retainer': return t[language].clientRetainer;
      case 'client_expense_advance': return t[language].clientExpenseAdvance;
      case 'lawyer_advance': return t[language].lawyerAdvance;
      case 'fee_payment_fixed': return t[language].feePaymentFixed;
      case 'fee_payment_consultation': return t[language].feePaymentConsultation;
      case 'fee_payment_success': return t[language].feePaymentSuccess;
      case 'fee_payment_milestone': return t[language].feePaymentMilestone;
      case 'fee_payment_other': return t[language].feePaymentOther;
      default: return type;
    }
  };
  
  const isFeePayment = (type) => type?.startsWith('fee_payment');
  
  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t[language].advances}</h2>
        <button onClick={() => setShowAdvanceForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          <Plus className="w-5 h-5" /> {t[language].addAdvance}
        </button>
      </div>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow p-4 border-l-4 border-blue-500">
          <div className="text-sm text-gray-500">{t[language].totalFees}</div>
          <div className="text-xl font-bold text-blue-600">${totals.allFees.toFixed(2)}</div>
          <div className="text-xs text-gray-400 mt-1">
            Retainers: ${totals.retainers.toFixed(2)} | Other: ${totals.feePayments.toFixed(2)}
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-4 border-l-4 border-green-500">
          <div className="text-sm text-gray-500">{t[language].totalExpenseAdv}</div>
          <div className="text-xl font-bold text-green-600">${totals.expenseAdvances.toFixed(2)}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4 border-l-4 border-orange-500">
          <div className="text-sm text-gray-500">{t[language].lawyerAdvance}</div>
          <div className="text-xl font-bold text-orange-600">${totals.lawyerAdvances.toFixed(2)}</div>
        </div>
      </div>
      
      {/* Per-Lawyer Balance Cards - Only show on Lawyer Advance tab */}
      {activeTab === 'lawyer_advances' && lawyerBalances.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {lawyerBalances.map(lb => (
            <div 
              key={lb.lawyer_id} 
              className={`bg-white rounded-lg shadow p-4 border-l-4 ${
                lb.netBalance < 0 ? 'border-red-500' : lb.netBalance > 0 ? 'border-green-500' : 'border-gray-300'
              }`}
            >
              <div className="font-medium text-gray-900 truncate">{lb.name}</div>
              <div className="mt-2 space-y-1 text-sm">
                <div className="flex justify-between text-gray-500">
                  <span>Advanced:</span>
                  <span className="text-green-600">${lb.totalAdvanced.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-500">
                  <span>Spent:</span>
                  <span className="text-orange-600">${lb.totalSpent.toFixed(2)}</span>
                </div>
                <div className={`flex justify-between font-semibold pt-1 border-t ${
                  lb.netBalance < 0 ? 'text-red-600' : lb.netBalance > 0 ? 'text-green-600' : 'text-gray-600'
                }`}>
                  <span>Balance:</span>
                  <span>${lb.netBalance.toFixed(2)}</span>
                </div>
              </div>
              <div className={`text-xs mt-2 ${lb.netBalance < 0 ? 'text-red-500' : 'text-gray-400'}`}>
                {lb.netBalance < 0 ? 'Firm owes lawyer' : lb.netBalance > 0 ? 'Available balance' : 'Settled'}
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Sub-tabs */}
      <div className="bg-white rounded-lg shadow">
        <div className="border-b">
          <div className="flex flex-wrap">
            {[
              { id: 'fees', label: t[language].feesTab, count: advances.filter(a => a.advance_type === 'client_retainer' || a.advance_type?.startsWith('fee_payment')).length },
              { id: 'expense_advances', label: t[language].expenseAdvancesTab, count: advances.filter(a => a.advance_type === 'client_expense_advance').length },
              { id: 'lawyer_advances', label: t[language].lawyerAdvance, count: advances.filter(a => a.advance_type === 'lawyer_advance').length },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  // Reset filters when switching tabs (per CODING_STANDARDS.md)
                  setClientFilter('');
                  setLawyerFilter('');
                }}
                className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600 bg-blue-50'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                {tab.label}
                <span className={`ml-2 px-2 py-0.5 text-xs rounded-full ${
                  activeTab === tab.id ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'
                }`}>{tab.count}</span>
              </button>
            ))}
          </div>
        </div>
        
        {/* Context-aware Filter */}
        <div className="p-4 border-b bg-gray-50">
          <div className="flex gap-4 items-center">
            {activeTab === 'lawyer_advances' ? (
              <>
                <label className="text-sm font-medium text-gray-700">{t[language].lawyer}:</label>
                <select
                  value={lawyerFilter}
                  onChange={(e) => setLawyerFilter(e.target.value)}
                  className="px-3 py-1.5 border rounded-md text-sm"
                >
                  <option value="">{t[language].allLawyers || 'All Lawyers'}</option>
                  {lawyers.map(l => (
                    <option key={l.lawyer_id} value={l.lawyer_id}>{l.full_name || l.name}</option>
                  ))}
                </select>
                {lawyerFilter && (
                  <button onClick={() => setLawyerFilter('')} className="text-sm text-blue-600 hover:underline">
                    Clear filter
                  </button>
                )}
              </>
            ) : (
              <>
                <label className="text-sm font-medium text-gray-700">{t[language].client}:</label>
                <select
                  value={clientFilter}
                  onChange={(e) => setClientFilter(e.target.value)}
                  className="px-3 py-1.5 border rounded-md text-sm"
                >
                  <option value="">{t[language].allClients || 'All Clients'}</option>
                  {clients.map(c => (
                    <option key={c.client_id} value={c.client_id}>{c.client_name}</option>
                  ))}
                </select>
                {clientFilter && (
                  <button onClick={() => setClientFilter('')} className="text-sm text-blue-600 hover:underline">
                    Clear filter
                  </button>
                )}
              </>
            )}
          </div>
        </div>
        
        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].dateReceived}</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].client} / {t[language].lawyer}</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].advanceType}</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].amount}</th>
                {activeTab !== 'lawyer_advances' && (
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].balanceRemaining}</th>
                )}
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].status}</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredAdvances.length === 0 ? (
                <tr><td colSpan={activeTab === 'lawyer_advances' ? 6 : 7} className="px-6 py-8 text-center text-gray-500">{t[language].noData}</td></tr>
              ) : (
                filteredAdvances.map(adv => {
                  const client = clients.find(c => c.client_id === adv.client_id);
                  const typeLabel = getTypeLabel(adv.advance_type);
                  const isFeePmt = isFeePayment(adv.advance_type);
                  const usedPercent = adv.amount > 0 ? ((adv.amount - adv.balance_remaining) / adv.amount * 100).toFixed(0) : 0;
                  const displayName = adv.advance_type === 'lawyer_advance' 
                    ? (adv.lawyer_name || 'N/A')
                    : (client?.client_name || 'N/A');
                  return (
                    <tr key={adv.advance_id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm">{formatDate(adv.date_received)}</td>
                      <td className="px-6 py-4 text-sm font-medium">
                        {displayName}
                        {adv.fee_description && (
                          <div className="text-xs text-gray-500">{adv.fee_description}</div>
                        )}
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          isFeePmt ? 'bg-purple-100 text-purple-800' :
                          adv.advance_type === 'client_retainer' ? 'bg-blue-100 text-blue-800' :
                          adv.advance_type === 'client_expense_advance' ? 'bg-green-100 text-green-800' :
                          'bg-orange-100 text-orange-800'
                        }`}>{typeLabel}</span>
                      </td>
                      <td className="px-6 py-4 text-sm">{adv.currency} {parseFloat(adv.amount).toFixed(2)}</td>
                      {activeTab !== 'lawyer_advances' && (
                        <td className="px-6 py-4">
                          {isFeePmt ? (
                            <span className="text-gray-400">{t[language].noBalance}</span>
                          ) : (
                            <div className="flex items-center gap-2">
                              <span className={`font-medium ${parseFloat(adv.balance_remaining) < 0 ? 'text-red-600' : adv.balance_remaining < (adv.minimum_balance_alert || 0) ? 'text-orange-600' : 'text-green-600'}`}>
                                {adv.currency} {parseFloat(adv.balance_remaining).toFixed(2)}
                              </span>
                              {parseFloat(adv.balance_remaining) >= 0 && (
                                <div className="w-16 bg-gray-200 rounded-full h-2">
                                  <div className="bg-blue-600 h-2 rounded-full" style={{width: `${100 - usedPercent}%`}}></div>
                                </div>
                              )}
                            </div>
                          )}
                        </td>
                      )}
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          adv.status === 'active' ? 'bg-green-100 text-green-800' :
                          adv.status === 'depleted' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'}`}>
                          {isFeePmt ? 'Received' : (t[language][adv.status] || adv.status)}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <button onClick={() => { setEditingAdvance(adv); setShowAdvanceForm(true); }}
                          className="text-blue-600 hover:text-blue-900 mr-3">{t[language].edit}</button>
                        <button onClick={() => {
                          showConfirm(
                            'Delete Payment',
                            'Are you sure you want to delete this payment record?',
                            async () => {
                              await window.electronAPI.deleteAdvance(adv.advance_id);
                              await refreshAdvances();
                              showToast('Payment deleted');
                              hideConfirm();
                            }
                          );
                        }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdvancesList;

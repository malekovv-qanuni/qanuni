import React from 'react';
import { Plus } from 'lucide-react';

const AppointmentsList = ({
  appointments,
  clients,
  language,
  t,
  setShowAppointmentForm,
  setEditingAppointment,
  showConfirm,
  hideConfirm,
  showToast,
  refreshAppointments
}) => {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t[language].appointments}</h2>
        <button onClick={() => setShowAppointmentForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          <Plus className="w-5 h-5" /> {t[language].addAppointment}
        </button>
      </div>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].date}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].title}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].appointmentType}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].client}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].locationType}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {appointments.length === 0 ? (
              <tr><td colSpan="6" className="px-6 py-8 text-center text-gray-500">{t[language].noData}</td></tr>
            ) : (
              appointments.map(a => {
                const client = clients.find(c => c.client_id === a.client_id);
                return (
                  <tr key={a.appointment_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm">
                      {a.date} {!a.all_day && a.start_time && `${a.start_time}-${a.end_time}`}
                    </td>
                    <td className="px-6 py-4 font-medium">{a.title}</td>
                    <td className="px-6 py-4 text-sm">{t[language][a.appointment_type?.replace('_', '')] || a.appointment_type}</td>
                    <td className="px-6 py-4 text-sm">{client?.client_name || '--'}</td>
                    <td className="px-6 py-4 text-sm">{t[language][a.location_type] || a.location_type}</td>
                    <td className="px-6 py-4 text-sm">
                      <button onClick={() => { setEditingAppointment(a); setShowAppointmentForm(true); }}
                        className="text-blue-600 hover:text-blue-900 mr-3">{t[language].edit}</button>
                      <button onClick={() => {
                        showConfirm(
                          language === 'ar' ? 'حذف الموعد' : 'Delete Appointment',
                          language === 'ar' ? 'هل أنت متأكد من حذف هذا الموعد؟' : 'Are you sure you want to delete this appointment?',
                          async () => {
                            await window.electronAPI.deleteAppointment(a.appointment_id);
                            await refreshAppointments();
                            showToast(language === 'ar' ? 'تم حذف الموعد' : 'Appointment deleted');
                            hideConfirm();
                          }
                        );
                      }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AppointmentsList;

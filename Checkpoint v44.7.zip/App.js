import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Plus, Users, Briefcase, Clock, Calendar, CalendarDays, FileText, BarChart3,
  Menu, X, Globe, Search, AlertTriangle, CheckCircle, ChevronRight, AlertCircle,
  Phone, Mail, Building, Building2, User, Gavel, ClipboardList, Settings, Trash2, Edit3, Pencil, Scale,
  DollarSign, Receipt, Wallet, CreditCard, PieChart, Download, Upload, Loader2,
  Play, Pause, Square, Timer, Minimize2, Maximize2, Save, FileSpreadsheet
} from 'lucide-react';

// Extracted common components
import Toast from './components/common/Toast';
import ConfirmDialog from './components/common/ConfirmDialog';
import LoadingButton from './components/common/LoadingButton';
import EmptyState from './components/common/EmptyState';
import FormField from './components/common/FormField';

// Extracted corporate components (v42.0.3)
import { EntityForm, EntitiesList } from './components/corporate';

// Extracted form components (v42.0.4-v42.0.8)
import { ClientForm, MatterForm, HearingForm } from './components/forms';
import { TaskForm, TimesheetForm, JudgmentForm, DeadlineForm, AppointmentForm, ExpenseForm, AdvanceForm, InvoiceForm, LookupForm } from './forms';

// Extracted list components (v42.0.5-v42.0.6)
import { ClientsList, MattersList, HearingsList, TimesheetsList, ExpensesList, TasksList, DeadlinesList, InvoicesList } from './components/lists';

// ============================================
// VALIDATION UTILITIES
// ============================================
const validators = {
  required: (value, message) => (!value || (typeof value === 'string' && !value.trim())) ? message : null,
  email: (value, message) => {
    if (!value) return null; // Not required check, just format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return !emailRegex.test(value) ? message : null;
  },
  phone: (value, message) => {
    if (!value) return null;
    const phoneRegex = /^[\d\s\+\-\(\)]{7,}$/;
    return !phoneRegex.test(value) ? message : null;
  },
  minLength: (value, min, message) => {
    if (!value) return null;
    return value.length < min ? message.replace('{min}', min) : null;
  },
  maxLength: (value, max, message) => {
    if (!value) return null;
    return value.length > max ? message.replace('{max}', max) : null;
  }
};

// Hook for form validation
const useFormValidation = (initialValues, validationRules, translations, language) => {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  const validateField = useCallback((name, value) => {
    const rules = validationRules[name];
    if (!rules) return null;

    for (const rule of rules) {
      let error = null;
      if (rule.type === 'required') {
        error = validators.required(value, translations[language][rule.message] || rule.message);
      } else if (rule.type === 'email') {
        error = validators.email(value, translations[language][rule.message] || rule.message);
      } else if (rule.type === 'phone') {
        error = validators.phone(value, translations[language][rule.message] || rule.message);
      } else if (rule.type === 'minLength') {
        error = validators.minLength(value, rule.min, translations[language][rule.message] || rule.message);
      } else if (rule.type === 'maxLength') {
        error = validators.maxLength(value, rule.max, translations[language][rule.message] || rule.message);
      }
      if (error) return error;
    }
    return null;
  }, [validationRules, translations, language]);

  const handleChange = useCallback((name, value) => {
    setValues(prev => ({ ...prev, [name]: value }));
    // Clear error on change if field was touched
    if (touched[name]) {
      const error = validateField(name, value);
      setErrors(prev => ({ ...prev, [name]: error }));
    }
  }, [touched, validateField]);

  const handleBlur = useCallback((name) => {
    setTouched(prev => ({ ...prev, [name]: true }));
    const error = validateField(name, values[name]);
    setErrors(prev => ({ ...prev, [name]: error }));
  }, [values, validateField]);

  const validateAll = useCallback(() => {
    const newErrors = {};
    let isValid = true;
    
    Object.keys(validationRules).forEach(name => {
      const error = validateField(name, values[name]);
      if (error) {
        newErrors[name] = error;
        isValid = false;
      }
    });
    
    setErrors(newErrors);
    setTouched(Object.keys(validationRules).reduce((acc, key) => ({ ...acc, [key]: true }), {}));
    return isValid;
  }, [values, validationRules, validateField]);

  const resetForm = useCallback((newValues) => {
    setValues(newValues || initialValues);
    setErrors({});
    setTouched({});
  }, [initialValues]);

  return {
    values,
    errors,
    touched,
    handleChange,
    handleBlur,
    validateAll,
    resetForm,
    setValues
  };
};

// ============================================
// PRINT STYLES COMPONENT
// ============================================
const PrintStyles = () => (
  <style>{`
    @media print {
      /* Hide non-printable elements */
      .no-print, 
      button, 
      nav, 
      .sidebar,
      [class*="fixed inset-0 bg-black"] {
        display: none !important;
      }
      
      /* Reset modal for print */
      .print-invoice {
        position: static !important;
        background: white !important;
        box-shadow: none !important;
        max-height: none !important;
        overflow: visible !important;
        padding: 0 !important;
      }
      
      .print-invoice > div {
        max-width: 100% !important;
        max-height: none !important;
        overflow: visible !important;
        box-shadow: none !important;
        border-radius: 0 !important;
      }
      
      /* Invoice styling for print */
      .invoice-header {
        border-bottom: 2px solid #333 !important;
        padding-bottom: 1rem !important;
        margin-bottom: 1rem !important;
      }
      
      .invoice-table {
        border-collapse: collapse !important;
        width: 100% !important;
      }
      
      .invoice-table th,
      .invoice-table td {
        border: 1px solid #ddd !important;
        padding: 8px !important;
      }
      
      .invoice-table th {
        background-color: #f5f5f5 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      
      /* Page settings */
      @page {
        margin: 1cm;
        size: A4;
      }
      
      body {
        font-size: 12pt !important;
        line-height: 1.4 !important;
      }
      
      /* Ensure proper page breaks */
      .page-break-before {
        page-break-before: always;
      }
      
      .avoid-break {
        page-break-inside: avoid;
      }
    }
  `}</style>
);

// ============================================
// MAIN APP COMPONENT
// ============================================
// ============================================
// UTILITY FUNCTIONS (moved outside App)
// ============================================
const generateID = (prefix) => {
  const year = new Date().getFullYear();
  const random = Math.random().toString(36).substr(2, 4).toUpperCase();
  return `${prefix}-${year}-${random}`;
};

const formatDate = (dateStr) => {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleDateString('en-GB');
};

// ============================================
// TRANSLATIONS (moved outside App)
// ============================================
const t = {
  en: {
    appName: 'Qanuni', dashboard: 'Dashboard', clients: 'Clients', contacts: 'Contacts',
    matters: 'Matters', hearings: 'Hearings', tasks: 'Tasks', timesheets: 'Timesheets',
    calendar: 'Calendar', reports: 'Reports', settings: 'Settings',
    addClient: 'Add Client', addContact: 'Add Contact', addMatter: 'Add Matter',
    addHearing: 'Add Hearing', addTask: 'Add Task', addTimesheet: 'Add Timesheet',
    addParty: 'Add Party', save: 'Save', cancel: 'Cancel', edit: 'Edit', delete: 'Delete',
    view: 'View', close: 'Close', search: 'Search', filter: 'Filter',
    loading: 'Loading...', noData: 'No data available',
    // Client fields
    clientName: 'Client Name', clientNameArabic: 'Client Name (Arabic)', clientType: 'Client Type',
    individual: 'Individual', legalEntity: 'Legal Entity', entityType: 'Entity Type', clientID: 'Client ID',
    serviceType: 'Service Type', litigationOnly: 'Litigation Only', corporateOnly: 'Corporate Only',
    bothServices: 'Both', corporateServiceNote: 'Corporate/Both clients appear in Companies section',
    customID: 'Custom ID', registrationNumber: 'Registration Number', vatNumber: 'VAT Number',
    mainContact: 'Main Contact', email: 'Email', phone: 'Phone', mobile: 'Mobile',
    address: 'Address', website: 'Website', industry: 'Industry',
    billingTerms: 'Billing Terms', retainer: 'Retainer', fixedFee: 'Fixed Fee',
    successFee: 'Success Fee', hourly: 'Hourly', custom: 'Custom', customType: 'Custom Type',
    currency: 'Currency', source: 'Source', notes: 'Notes',
    // Contact fields
    contactType: 'Contact Type', clientContact: 'Client Contact', opposingCounsel: 'Opposing Counsel',
    judge: 'Judge', expert: 'Expert', courtClerk: 'Court Clerk', other: 'Other',
    title: 'Title', organization: 'Organization', name: 'Name',
    // Matter fields
    matterName: 'Matter Name', matterType: 'Matter Type', litigation: 'Litigation',
    arbitration: 'Arbitration', advisory: 'Advisory', transactional: 'Transactional',
    status: 'Status', active: 'Active', pending: 'Pending', closed: 'Closed',
    onHold: 'On Hold', consultation: 'Consultation', engaged: 'Engaged', archived: 'Archived',
    caseNumber: 'Case Number', courtType: 'Court Type', region: 'Region',
    judgeName: 'Judge Name', responsibleLawyer: 'Responsible Lawyer', openingDate: 'Opening Date',
    parties: 'Parties', selectClient: 'Select Client',
    // Party fields
    partyName: 'Party Name', partyRole: 'Party Role', partyType: 'Party Type',
    partyPosition: 'Party Position', plaintiff: 'Plaintiff', defendant: 'Defendant',
    petitioner: 'Petitioner', respondent: 'Respondent', appellant: 'Appellant',
    claimant: 'Claimant', witness: 'Witness', thirdParty: 'Third Party',
    ourClient: 'Our Client', opposing: 'Opposing', neutral: 'Neutral',
    // Hearing fields
    hearingDate: 'Hearing Date', hearingTime: 'Time', purpose: 'Purpose',
    outcome: 'Outcome', adjourned: 'Adjourned', takenForJudgment: 'Taken for Judgment',
    settled: 'Settled', dismissed: 'Dismissed', completed: 'Completed',
    nextHearing: 'Next Hearing', attendedBy: 'Attended By',
    // Task fields
    taskNumber: 'Task Number', taskType: 'Task Type', taskTitle: 'Title',
    description: 'Description', instructions: 'Instructions', dueDate: 'Due Date',
    priority: 'Priority', high: 'High', medium: 'Medium', low: 'Low',
    assigned: 'Assigned', inProgress: 'In Progress', review: 'Review', done: 'Done',
    assignedTo: 'Assigned To', assignedBy: 'Assigned By',
    // Timesheet fields
    lawyer: 'Lawyer', client: 'Client', matter: 'Matter', date: 'Date',
    minutes: 'Minutes', hours: 'Hours', narrative: 'Narrative',
    billable: 'Billable', nonBillable: 'Non-Billable', ratePerHour: 'Rate/Hour', amount: 'Amount',
    // Dashboard
    totalClients: 'Total Clients', activeMatters: 'Active Matters',
    pendingTasks: 'Pending Tasks', upcomingHearings: 'Upcoming Hearings',
    thisMonth: 'This Month Revenue', todaySchedule: "Today's Schedule",
    overdue: 'Overdue', dueToday: 'Due Today', thisWeek: 'This Week',
    // Conflict Check
    conflictCheck: 'Conflict Check', potentialConflict: 'Potential Conflict Detected',
    noConflicts: 'No conflicts found', proceedAnyway: 'Proceed Anyway',
    runConflictCheck: 'Run Conflict Check', conflictWarning: 'Review potential conflicts before proceeding',
    // Additional UI
    select: 'Select', selectMatter: 'Select Matter', selectClientFirst: 'Select client first',
    customRegion: 'Custom Region', customPurpose: 'Custom Purpose', endTime: 'End Time',
    outcomeNotes: 'Outcome Notes',
    // Settings
    settings: 'Settings', lookups: 'Lookups', courtTypes: 'Court Types', regions: 'Regions',
    hearingPurposes: 'Hearing Purposes', taskTypes: 'Task Types', expenseCategories: 'Expense Categories',
    lawyers: 'Lawyers', addNew: 'Add New', nameEn: 'Name (English)', nameAr: 'Name (Arabic)',
    initials: 'Initials', hourlyRate: 'Hourly Rate', isActive: 'Active', icon: 'Icon',
    systemDefault: 'System Default', userDefined: 'User Defined', confirmDelete: 'Are you sure you want to delete this item?',
    cannotDeleteSystem: 'Cannot delete system default items', addLawyer: 'Add Lawyer', addCourtType: 'Add Court Type',
    addRegion: 'Add Region', addPurpose: 'Add Purpose', addTaskType: 'Add Task Type', addCategory: 'Add Category',
    // Calendar
    today: 'Today', daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly',
    previousWeek: 'Previous', nextWeek: 'Next', noEvents: 'No events',
    // Judgments
    judgments: 'Judgments', addJudgment: 'Add Judgment', judgmentType: 'Judgment Type',
    firstInstance: 'First Instance', appeal: 'Appeal', cassation: 'Cassation', arbitralAward: 'Arbitral Award',
    expectedDate: 'Expected Date', actualDate: 'Actual Date', reminderDays: 'Reminder Days',
    judgmentOutcome: 'Outcome', won: 'Won', lost: 'Lost', partialWin: 'Partial Win',
    inFavorOf: 'In Favor Of', ourClient: 'Our Client', opposing: 'Opposing', partial: 'Partial',
    appealPossible: 'Appeal Possible', appealDeadline: 'Appeal Deadline', appealed: 'Appealed',
    judgmentSummary: 'Summary', amountAwarded: 'Amount Awarded', judgmentStatus: 'Status',
    issued: 'Issued', final: 'Final',
    // Appointments
    appointments: 'Appointments', addAppointment: 'Add Appointment', appointmentType: 'Type',
    clientMeeting: 'Client Meeting', internalMeeting: 'Internal Meeting', call: 'Call',
    courtVisit: 'Court Visit', consultation: 'Consultation', personal: 'Personal',
    startTime: 'Start Time', locationType: 'Location Type', office: 'Office',
    external: 'External', virtual: 'Virtual', court: 'Court', locationDetails: 'Location Details',
    virtualLink: 'Virtual Link', attendees: 'Attendees', allDay: 'All Day',
    // Expenses
    expenses: 'Expenses', addExpense: 'Add Expense', expenseType: 'Expense Type',
    clientExpense: 'Client Expense', firmExpense: 'Firm Expense', category: 'Category',
    receipt: 'Receipt', markup: 'Markup %', deductFromAdvance: 'Deduct from Advance',
    approved: 'Approved', rejected: 'Rejected', reimbursed: 'Reimbursed', billed: 'Billed',
    // Advances & Payments
    advances: 'Payments Received', addAdvance: 'Add Payment', advanceType: 'Payment Type',
    clientRetainer: 'Client Retainer', clientExpenseAdvance: 'Expense Advance',
    lawyerAdvance: 'Lawyer Advance', dateReceived: 'Date Received', paymentMethod: 'Payment Method',
    referenceNumber: 'Reference Number', balanceRemaining: 'Balance Remaining',
    minimumBalanceAlert: 'Minimum Balance Alert', depleted: 'Depleted', refunded: 'Refunded',
    bankTransfer: 'Bank Transfer', check: 'Check', cash: 'Cash', creditCard: 'Credit Card',
    // Fee Payment Types
    feePayment: 'Fee Payment', feePaymentFixed: 'Fixed Fee Payment', feePaymentConsultation: 'Consultation Fee',
    feePaymentSuccess: 'Success Fee', feePaymentMilestone: 'Milestone Payment', feePaymentOther: 'Other Fee Payment',
    // Sub-tabs
    allPayments: 'All', feesTab: 'Fees', expenseAdvancesTab: 'Expense Advances', 
    feePaymentsTab: 'Fee Payments', internalTab: 'Internal',
    totalFees: 'Total Fees', totalRetainers: 'Total Retainers', totalExpenseAdv: 'Expense Advances', totalFeePayments: 'Fee Payments',
    // Fee payment specific
    feeDescription: 'Fee Description', noBalance: '-',
    // Invoices
    invoices: 'Invoices', addInvoice: 'Add Invoice', createInvoice: 'Create Invoice',
    invoiceNumber: 'Invoice Number', periodStart: 'Period Start', periodEnd: 'Period End',
    issueDate: 'Issue Date', dueDate: 'Due Date', subtotal: 'Subtotal',
    discount: 'Discount', discountType: 'Discount Type', percentage: 'Percentage', fixed: 'Fixed',
    taxableAmount: 'Taxable Amount', vatRate: 'VAT Rate', vatAmount: 'VAT Amount',
    total: 'Total', invoiceStatus: 'Status', draft: 'Draft', sent: 'Sent', viewed: 'Viewed',
    partialPaid: 'Partial', paid: 'Paid', overdue: 'Overdue', cancelled: 'Cancelled', writtenOff: 'Written Off',
    unbilledTime: 'Unbilled Time', unbilledExpenses: 'Unbilled Expenses', fixedFeeItem: 'Fixed Fee Item',
    generateInvoice: 'Generate Invoice', selectItems: 'Select Items', invoicePreview: 'Invoice Preview',
    markAsSent: 'Mark as Sent', markAsPaid: 'Mark as Paid', paymentTerms: 'Payment Terms',
    notesToClient: 'Notes to Client', internalNotes: 'Internal Notes',
    // v12 - New translations
    paidBy: 'Paid By', firmDirect: 'Firm (Direct)', balanceWarning: 'Balance will go negative',
    negative: 'negative', selectLawyer: 'Select Lawyer', lawyerName: 'Lawyer',
    viewInvoice: 'View', professionalFees: 'Professional Fees', lessRetainer: 'Less: Retainer Applied',
    netFees: 'Net Professional Fees', disbursements: 'Disbursements/Expenses',
    availableBalance: 'Available Balance', applyRetainer: 'Apply Retainer', amountToApply: 'Amount to Apply',
    applyMax: 'Apply Max', retainerAppliedToFeesOnly: 'Note: Retainer is applied to professional fees only, not expenses',
    billingPeriod: 'Billing Period', fixedFee: 'Fixed Fee',
    // Phase 2 - New translations
    searchClients: 'Search clients...', searchMatters: 'Search matters...',
    allStatuses: 'All Statuses', allPriorities: 'All Priorities',
    nextHearingDate: 'Next Hearing Date', nextHearingPurpose: 'Next Hearing Purpose',
    createFollowupTask: 'Create Follow-up Task', taskTitle: 'Task Title',
    adjournedWorkflow: 'Adjourned - Schedule Next Hearing',
    showingOf: 'Showing', of: 'of',
    // Expense Filters
    allClients: 'All Clients', allMatters: 'All Matters', allStatuses: 'All Statuses',
    allLawyers: 'All Lawyers', clearFilters: 'Clear Filters', fromDate: 'From', toDate: 'To',
    firm: 'Firm', page: 'Page', prev: 'Prev', next: 'Next', show: 'Show',
    pendingJudgmentsWidget: 'Pending Judgments', outstandingBalance: 'Outstanding Balance',
    // Phase 3 - Hearing/Judgment Workflow (Simplified)
    notFinal: 'Not Final',
    notFinalWorkflow: 'Not Final - Schedule Next Hearing',
    fromHearing: 'From Hearing',
    // v14 - Export and Backup translations
    backupRestore: 'Backup & Restore', backup: 'Backup Database', restore: 'Restore Database',
    createBackup: 'Create Backup', restoreBackup: 'Restore from Backup',
    exportAll: 'Export All Data', exportToExcel: 'Export to Excel',
    // Phase 2 v19 - Empty States & Validation
    emptyClients: 'No clients yet', emptyClientsDesc: 'Add your first client to get started with managing your practice.',
    emptyMatters: 'No matters yet', emptyMattersDesc: 'Create a matter to start tracking cases and legal work.',
    emptyHearings: 'No hearings scheduled', emptyHearingsDesc: 'Schedule hearings to track court appearances.',
    emptyTasks: 'No tasks yet', emptyTasksDesc: 'Create tasks to manage your work and deadlines.',
    emptyTimesheets: 'No time entries', emptyTimesheetsDesc: 'Log time to track billable hours.',
    emptyInvoices: 'No invoices yet', emptyInvoicesDesc: 'Create invoices to bill your clients.',
    emptyExpenses: 'No expenses recorded', emptyExpensesDesc: 'Record expenses to track costs and disbursements.',
    emptyAppointments: 'No appointments', emptyAppointmentsDesc: 'Schedule appointments to manage your calendar.',
    emptyJudgments: 'No pending judgments', emptyJudgmentsDesc: 'Judgments will appear here when cases are taken for judgment.',
    emptyAdvances: 'No advances received', emptyAdvancesDesc: 'Record client retainers and advances here.',
    // Validation messages
    required: 'This field is required',
    invalidEmail: 'Please enter a valid email address',
    invalidPhone: 'Please enter a valid phone number',
    invalidDate: 'Please enter a valid date',
    minLength: 'Must be at least {min} characters',
    maxLength: 'Must be no more than {max} characters',
    selectRequired: 'Please select an option',
    // Print
    print: 'Print', printInvoice: 'Print Invoice',
    // Dashboard widgets
    customizeDashboard: 'Customize Dashboard', showWidget: 'Show', hideWidget: 'Hide',
    dragToReorder: 'Drag to reorder', statsWidget: 'Statistics Cards',
    todayScheduleWidget: 'Today\'s Schedule', tasksDueWidget: 'Tasks Due',
    upcomingHearingsWidget: 'Upcoming Hearings', pendingJudgmentsWidgetLabel: 'Pending Judgments',
    resetLayout: 'Reset Layout', closeSettings: 'Close',
    // Time Tracking Timer
    timer: 'Timer', startTimer: 'Start', stopTimer: 'Stop', pauseTimer: 'Pause',
    resumeTimer: 'Resume', saveTime: 'Save Time', discardTimer: 'Discard',
    timerRunning: 'Timer Running', noMatterSelected: 'No matter selected',
    confirmDiscardTimer: 'Are you sure you want to discard this time entry?',
    timerSaved: 'Time entry saved successfully', selectMatterForTimer: 'Select a matter to track time',
    logTime: 'Log Time', quickTimer: 'Quick Timer', timerPaused: 'Paused',
    workDescription: 'Work description...',
    // Deadlines
    deadlines: 'Deadlines', addDeadline: 'Add Deadline', deadlineTitle: 'Deadline Title',
    deadlineDate: 'Deadline Date', reminderDays: 'Reminder (days before)',
    deadlineStatus: 'Status', deadlinePending: 'Pending', deadlineCompleted: 'Completed',
    deadlineMissed: 'Missed', markComplete: 'Mark Complete', markMissed: 'Mark Missed', markPending: 'Mark Pending',
    overdueDeadlines: 'Overdue', upcomingDeadlines: 'Upcoming Deadlines', thisWeek: 'This Week',
    daysRemaining: 'days remaining', daysOverdue: 'days overdue', dueToday: 'Due Today',
    emptyDeadlines: 'No deadlines', emptyDeadlinesDesc: 'Deadlines are auto-generated from Judgments.',
    deadlineSaved: 'Deadline saved successfully', deadlineDeleted: 'Deadline deleted',
    deadlineMarkedComplete: 'Deadline marked complete', deadlineMarkedMissed: 'Deadline marked missed',
    viewSource: 'View Source', viewJudgment: 'View Judgment', sourceJudgment: 'From Judgment',
    completeDeadlineConfirm: 'Mark this deadline as complete?', completeDeadlineNote: 'This will also update the source judgment.',
    createReminderTask: 'Create reminder task', linkedToMatter: 'Linked to Matter',
    allDeadlines: 'All', deadlineNotes: 'Notes',
    // Deadline-Judgment Integration (v24)
    linkedToJudgment: 'Linked to Judgment', createAppealDeadline: 'Create Appeal Deadline',
    appealDeadlineCreated: 'Appeal deadline created automatically', addDeadlineToJudgment: 'Add Deadline',
    judgmentDeadlines: 'Judgment Deadlines', noLinkedDeadlines: 'No linked deadlines',
    selectClientForDeadline: 'Select client first', selectMatterForDeadline: 'Select matter first',
    // Corporate Secretary (v41.1)
    corporate: 'Corporate', companies: 'Companies', addEntity: 'Add Entity', addCompany: 'Add Company',
    registrationNumber: 'Registration Number', registrationDate: 'Registration Date',
    registeredAddress: 'Registered Address', shareCapital: 'Share Capital',
    numberOfShares: 'Number of Shares', fiscalYearEnd: 'Fiscal Year End',
    taxId: 'Tax ID', commercialRegister: 'Commercial Register',
    entityStatus: 'Status', entityActive: 'Active', entityDormant: 'Dormant',
    entityLiquidating: 'Liquidating', entityStruckOff: 'Struck Off',
    corporateDetails: 'Corporate Details', manageCorporate: 'Manage Corporate Details',
    noEntities: 'No corporate entities', noEntitiesDesc: 'Add corporate details for your company clients.',
    capitalCurrency: 'Capital Currency', all: 'All', actions: 'Actions',
    // Shareholders (v41.7)
    shareholders: 'Shareholders', directors: 'Directors', details: 'Details',
    shareholderName: 'Shareholder Name', idNumber: 'ID Number', nationality: 'Nationality',
    sharesOwned: 'Shares Owned', shareClass: 'Share Class', percentage: 'Percentage',
    dateAcquired: 'Date Acquired', ordinary: 'Ordinary', preferred: 'Preferred',
    addShareholder: 'Add Shareholder', editShareholder: 'Edit Shareholder',
    totalShares: 'Total Shares',
    // Directors (v41.8)
    directorName: 'Director Name', position: 'Position', dateAppointed: 'Date Appointed',
    dateResigned: 'Date Resigned', isSignatory: 'Signatory', 
    addDirector: 'Add Director', editDirector: 'Edit Director',
    chairman: 'Chairman', director: 'Director', managingDirector: 'Managing Director',
    secretary: 'Secretary', treasurer: 'Treasurer', member: 'Member',
    activeDirectors: 'Active Directors', resignedDirectors: 'Resigned Directors',
    noDirectors: 'No directors registered', signatoryYes: 'Yes', signatoryNo: 'No'
  }
};





const App = () => {
  const [language, setLanguage] = useState('en');
  const [currentModule, setCurrentModule] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading, setLoading] = useState(true);
  
  // Toast notification state
  const [toast, setToast] = useState(null);
  const showToast = useCallback((message, type = 'success') => {
    setToast({ message, type });
  }, []);
  const hideToast = useCallback(() => setToast(null), []);
  
  // Confirmation dialog state
  const [confirmDialog, setConfirmDialog] = useState({ isOpen: false });
  const showConfirm = useCallback((title, message, onConfirm, options = {}) => {
    // options: { confirmText, danger }
    setConfirmDialog({ isOpen: true, title, message, onConfirm, ...options });
  }, []);
  const hideConfirm = useCallback(() => setConfirmDialog({ isOpen: false }), []);
  
  // Unsaved changes tracking
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [pendingNavigation, setPendingNavigation] = useState(null);
  
  // Track form dirty state
  const markFormDirty = useCallback(() => setHasUnsavedChanges(true), []);
  const clearFormDirty = useCallback(() => setHasUnsavedChanges(false), []);
  
  // Handle navigation with unsaved changes warning
  const handleModuleChange = useCallback((newModule) => {
    if (hasUnsavedChanges) {
      setPendingNavigation(newModule);
      showConfirm(
        language === 'ar' ? 'تغييرات غير محفوظة' : 'Unsaved Changes',
        language === 'ar' ? 'لديك تغييرات غير محفوظة. هل تريد المتابعة بدون حفظ؟' : 'You have unsaved changes. Do you want to continue without saving?',
        () => {
          setCurrentModule(newModule);
          setHasUnsavedChanges(false);
          setPendingNavigation(null);
          hideConfirm();
        }
      );
    } else {
      setCurrentModule(newModule);
    }
  }, [hasUnsavedChanges, language, showConfirm, hideConfirm]);
  
  // Data state
  const [clients, setClients] = useState([]);
  const [matters, setMatters] = useState([]);
  const [hearings, setHearings] = useState([]);
  const [judgments, setJudgments] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [timesheets, setTimesheets] = useState([]);
  // Timesheet filters & pagination (v42.3, search added v44.2)
  const [timesheetFilters, setTimesheetFilters] = useState({
    clientId: '', matterId: '', lawyerId: '', billable: '', dateFrom: '', dateTo: '', search: ''
  });
  const [timesheetPage, setTimesheetPage] = useState(1);
  const [timesheetPageSize, setTimesheetPageSize] = useState(25);
  const [appointments, setAppointments] = useState([]);
  const [expenses, setExpenses] = useState([]);
  // Expense filters & pagination (search added v44.2)
  const [expenseFilters, setExpenseFilters] = useState({
    clientId: '', matterId: '', paidBy: '', status: '', billable: '', dateFrom: '', dateTo: '', search: ''
  });
  const [expensePage, setExpensePage] = useState(1);
  const [expensePageSize, setExpensePageSize] = useState(25);
  const [advances, setAdvances] = useState([]);
  const [invoices, setInvoices] = useState([]);
  // Invoice filters & pagination (v42.5, search+datePreset added v44.3)
  const [invoiceFilters, setInvoiceFilters] = useState({
    clientId: '', matterId: '', status: '', dateType: 'issue', dateFrom: '', dateTo: '', datePreset: 'all', search: ''
  });
  const [invoicePage, setInvoicePage] = useState(1);
  const [invoicePageSize, setInvoicePageSize] = useState(25);
  const [deadlines, setDeadlines] = useState([]);
  // Deadline filters & pagination (v42.6, search added v44.2)
  const [deadlineFilters, setDeadlineFilters] = useState({
    clientId: '', matterId: '', priority: '', dateFrom: '', dateTo: '', search: ''
  });
  const [deadlinePage, setDeadlinePage] = useState(1);
  const [deadlinePageSize, setDeadlinePageSize] = useState(25);
  const [corporateEntities, setCorporateEntities] = useState([]);
  const [dashboardStats, setDashboardStats] = useState({});
  
  // Lookup data
  const [courtTypes, setCourtTypes] = useState([]);
  const [regions, setRegions] = useState([]);
  const [hearingPurposes, setHearingPurposes] = useState([]);
  const [taskTypes, setTaskTypes] = useState([]);
  const [expenseCategories, setExpenseCategories] = useState([]);
  const [entityTypes, setEntityTypes] = useState([]);
  const [lawyers, setLawyers] = useState([]);
  
  // Calendar state
  const [calendarView, setCalendarView] = useState('weekly'); // daily, weekly, monthly
  const [calendarDate, setCalendarDate] = useState(new Date());
  
  // Form visibility
  const [showClientForm, setShowClientForm] = useState(false);
  const [showMatterForm, setShowMatterForm] = useState(false);
  const [showHearingForm, setShowHearingForm] = useState(false);
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [showTimesheetForm, setShowTimesheetForm] = useState(false);
  const [showPartyForm, setShowPartyForm] = useState(false);
  const [showConflictResults, setShowConflictResults] = useState(false);
  const [showLookupForm, setShowLookupForm] = useState(false);
  const [showJudgmentForm, setShowJudgmentForm] = useState(false);
  const [showAppointmentForm, setShowAppointmentForm] = useState(false);
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [showAdvanceForm, setShowAdvanceForm] = useState(false);
  const [showInvoiceForm, setShowInvoiceForm] = useState(false);
  const [showDeadlineForm, setShowDeadlineForm] = useState(false);
  const [showEntityForm, setShowEntityForm] = useState(false);
  const [entityFormTab, setEntityFormTab] = useState('details');
  
  // Client Statement modal state (v44.3)
  const [showClientStatement, setShowClientStatement] = useState(false);
  const [clientStatementData, setClientStatementData] = useState(null);
  const [clientStatementLoading, setClientStatementLoading] = useState(false);
  const [clientStatementFilters, setClientStatementFilters] = useState({
    clientId: '',
    dateFrom: new Date(new Date().getFullYear(), 0, 1).toISOString().split('T')[0], // Jan 1 this year
    dateTo: new Date().toISOString().split('T')[0] // Today
  });

  // Case Status Report modal state (v44.3)
  const [showCaseStatusReport, setShowCaseStatusReport] = useState(false);
  const [caseStatusData, setCaseStatusData] = useState(null);
  const [caseStatusLoading, setCaseStatusLoading] = useState(false);
  const [caseStatusClientId, setCaseStatusClientId] = useState('');

  // Client 360° Report modal state (v44.5)
  const [showClient360Report, setShowClient360Report] = useState(false);
  const [client360Data, setClient360Data] = useState(null);
  const [client360Loading, setClient360Loading] = useState(false);
  const [client360ClientId, setClient360ClientId] = useState('');

  // Editing state
  const [editingClient, setEditingClient] = useState(null);
  const [editingMatter, setEditingMatter] = useState(null);
  const [editingHearing, setEditingHearing] = useState(null);
  const [editingTask, setEditingTask] = useState(null);
  const [editingTimesheet, setEditingTimesheet] = useState(null);
  const [editingJudgment, setEditingJudgment] = useState(null);
  const [editingAppointment, setEditingAppointment] = useState(null);
  const [editingExpense, setEditingExpense] = useState(null);
  const [editingAdvance, setEditingAdvance] = useState(null);
  const [editingInvoice, setEditingInvoice] = useState(null);
  const [editingEntity, setEditingEntity] = useState(null);

  // Hearing form data (lifted to App level to prevent state loss on re-render)
  const [hearingFormData, setHearingFormData] = useState(null);
  const [clientFormData, setClientFormData] = useState(null);
  const [matterFormData, setMatterFormData] = useState(null);
  const [taskFormData, setTaskFormData] = useState(null);
  const [timesheetFormData, setTimesheetFormData] = useState(null);
  const [deadlineFormData, setDeadlineFormData] = useState(null);
  const [editingDeadline, setEditingDeadline] = useState(null);
  const [selectedMatter, setSelectedMatter] = useState(null);
  const [conflictResults, setConflictResults] = useState([]);
  const [viewingInvoice, setViewingInvoice] = useState(null);
  const [editingLookup, setEditingLookup] = useState(null);
  const [currentLookupType, setCurrentLookupType] = useState('courtTypes');
  const [settingsTab, setSettingsTab] = useState('firmInfo');
  
  // Firm Info (needed for Invoices and Settings)
  const [firmInfo, setFirmInfo] = useState({
    firm_name: '', firm_name_arabic: '', firm_address: '', firm_phone: '', firm_email: '',
    firm_website: '', firm_vat_number: '', default_currency: 'USD', default_vat_rate: '11'
  });
  
  // Phase 2: Search and filter state
  const [clientSearch, setClientSearch] = useState('');
  const [matterSearch, setMatterSearch] = useState('');
  const [taskStatusFilter, setTaskStatusFilter] = useState('all');
  const [taskPriorityFilter, setTaskPriorityFilter] = useState('all');
  // Enhanced task filters (v42.4, v43.3 added taskTypeId, v44 added search)
  const [taskFilters, setTaskFilters] = useState({
    clientId: '', matterId: '', lawyerId: '', taskTypeId: '', dateFrom: '', dateTo: '', search: ''
  });
  // Task pagination (v44)
  const [taskPage, setTaskPage] = useState(1);
  const [taskPageSize, setTaskPageSize] = useState(25);
  
  // Phase 2.5: Dashboard widget configuration
  const [dashboardWidgets, setDashboardWidgets] = useState(() => {
    const saved = localStorage.getItem('qanuni_dashboard_widgets');
    return saved ? JSON.parse(saved) : {
      order: ['stats', 'todaySchedule', 'upcomingDeadlines', 'tasksDue', 'upcomingHearings', 'pendingJudgments'],
      visible: {
        stats: true,
        todaySchedule: true,
        upcomingDeadlines: true,
        tasksDue: true,
        upcomingHearings: true,
        pendingJudgments: true
      }
    };
  });
  const [showWidgetSettings, setShowWidgetSettings] = useState(false);
  const [draggedWidget, setDraggedWidget] = useState(null);

  // ============================================
  // TIME TRACKING TIMER STATE
  // ============================================
  const [timerExpanded, setTimerExpanded] = useState(false);
  const [timerRunning, setTimerRunning] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [timerClientId, setTimerClientId] = useState('');
  const [timerMatterId, setTimerMatterId] = useState('');
  const [timerNarrative, setTimerNarrative] = useState('');
  const [timerLawyerId, setTimerLawyerId] = useState('');
  const timerIntervalRef = useRef(null);
  
  // Load timer state from localStorage on mount
  useEffect(() => {
    const savedTimer = localStorage.getItem('qanuni_timer');
    if (savedTimer) {
      try {
        const parsed = JSON.parse(savedTimer);
        setTimerClientId(parsed.clientId || '');
        setTimerMatterId(parsed.matterId || '');
        setTimerNarrative(parsed.narrative || '');
        setTimerLawyerId(parsed.lawyerId || '');
        
        // If timer was running, calculate elapsed time since startTime
        if (parsed.running && parsed.startTime) {
          const elapsed = Math.floor((Date.now() - parsed.startTime) / 1000) + (parsed.pausedSeconds || 0);
          setTimerSeconds(elapsed);
          setTimerRunning(true);
          setTimerExpanded(true);
        } else {
          setTimerSeconds(parsed.pausedSeconds || 0);
        }
      } catch (e) {
        console.error('Error loading timer state:', e);
      }
    }
  }, []);
  
  // Save timer state to localStorage
  const saveTimerState = useCallback((running, seconds, startTime = null) => {
    const timerState = {
      clientId: timerClientId,
      matterId: timerMatterId,
      narrative: timerNarrative,
      lawyerId: timerLawyerId,
      running,
      startTime: running ? (startTime || Date.now()) : null,
      pausedSeconds: running ? 0 : seconds
    };
    localStorage.setItem('qanuni_timer', JSON.stringify(timerState));
  }, [timerClientId, timerMatterId, timerNarrative, timerLawyerId]);
  
  // Timer interval effect
  useEffect(() => {
    if (timerRunning) {
      timerIntervalRef.current = setInterval(() => {
        setTimerSeconds(prev => prev + 1);
      }, 1000);
    } else {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    }
    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    };
  }, [timerRunning]);

  const isRTL = language === 'ar';

  // ============================================
  // TRANSLATIONS
  // ============================================
  // t moved outside App

  // ============================================
  // DATA LOADING
  // ============================================
  useEffect(() => {
    loadAllData();
  }, []);

  // Load firm info on mount (needed for Invoices)
  useEffect(() => {
    const loadFirmInfo = async () => {
      try {
        const info = await window.electronAPI.getFirmInfo();
        if (info) setFirmInfo(prev => ({ ...prev, ...info }));
      } catch (error) {
        console.error('Error loading firm info:', error);
      }
    };
    loadFirmInfo();
  }, []);

  // ============================================
  // KEYBOARD SHORTCUTS
  // ============================================
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Escape to close any open form
      if (e.key === 'Escape') {
        if (showClientForm) { setShowClientForm(false); setEditingClient(null); setClientFormData(null); }
        else if (showMatterForm) { setShowMatterForm(false); setEditingMatter(null); setMatterFormData(null); }
        else if (showHearingForm) { setShowHearingForm(false); setEditingHearing(null); setHearingFormData(null); }
        else if (showTaskForm) { setShowTaskForm(false); setEditingTask(null); setTaskFormData(null); }
        else if (showTimesheetForm) { setShowTimesheetForm(false); setEditingTimesheet(null); setTimesheetFormData(null); }
        else if (showJudgmentForm) { setShowJudgmentForm(false); setEditingJudgment(null); }
        else if (showAppointmentForm) { setShowAppointmentForm(false); setEditingAppointment(null); }
        else if (showExpenseForm) { setShowExpenseForm(false); setEditingExpense(null); }
        else if (showAdvanceForm) { setShowAdvanceForm(false); setEditingAdvance(null); }
        else if (showInvoiceForm) setShowInvoiceForm(false);
        else if (showDeadlineForm) { setShowDeadlineForm(false); setEditingDeadline(null); setDeadlineFormData(null); }
        else if (viewingInvoice) setViewingInvoice(null);
        else if (showLookupForm) { setShowLookupForm(false); setEditingLookup(null); }
        else if (confirmDialog.isOpen) hideConfirm();
      }
      
      // Ctrl+N or Cmd+N to open new form for current module
      if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
        e.preventDefault();
        if (currentModule === 'clients') setShowClientForm(true);
        else if (currentModule === 'matters') setShowMatterForm(true);
        else if (currentModule === 'hearings') setShowHearingForm(true);
        else if (currentModule === 'tasks') setShowTaskForm(true);
        else if (currentModule === 'timesheets') setShowTimesheetForm(true);
        else if (currentModule === 'judgments') setShowJudgmentForm(true);
        else if (currentModule === 'appointments') setShowAppointmentForm(true);
        else if (currentModule === 'expenses') setShowExpenseForm(true);
        else if (currentModule === 'advances') setShowAdvanceForm(true);
        else if (currentModule === 'invoices') setShowInvoiceForm(true);
        // Deadlines: No manual add - auto-generated from Judgments only
      }
      
      // Ctrl+T or Cmd+T to toggle timer
      if ((e.ctrlKey || e.metaKey) && e.key === 't') {
        e.preventDefault();
        setTimerExpanded(prev => !prev);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showClientForm, showMatterForm, showHearingForm, showTaskForm, showTimesheetForm, 
      showJudgmentForm, showAppointmentForm, showExpenseForm, showAdvanceForm, showInvoiceForm,
      showDeadlineForm, viewingInvoice, showLookupForm, confirmDialog.isOpen, currentModule, hideConfirm, timerExpanded]);

  const loadAllData = async () => {
    try {
      setLoading(true);
      const [
        clientsData, mattersData, hearingsData, judgmentsData, tasksData,
        timesheetsData, appointmentsData, expensesData, advancesData, invoicesData,
        courtTypesData, regionsData, purposesData, taskTypesData,
        expenseCategoriesData, entityTypesData, lawyersData, statsData
      ] = await Promise.all([
        window.electronAPI.getAllClients(),
        window.electronAPI.getAllMatters(),
        window.electronAPI.getAllHearings(),
        window.electronAPI.getAllJudgments(),
        window.electronAPI.getAllTasks(),
        window.electronAPI.getAllTimesheets(),
        window.electronAPI.getAllAppointments(),
        window.electronAPI.getAllExpenses(),
        window.electronAPI.getAllAdvances(),
        window.electronAPI.getAllInvoices(),
        window.electronAPI.getCourtTypes(),
        window.electronAPI.getRegions(),
        window.electronAPI.getHearingPurposes(),
        window.electronAPI.getTaskTypes(),
        window.electronAPI.getExpenseCategories(),
        window.electronAPI.getEntityTypes(),
        window.electronAPI.getLawyers(),
        window.electronAPI.getDashboardStats()
      ]);
      
      setClients(clientsData);
      setMatters(mattersData);
      setHearings(hearingsData);
      setJudgments(judgmentsData);
      setTasks(tasksData);
      setTimesheets(timesheetsData.map(ts => ({ ...ts, billable: ts.billable === 1 })));
      setAppointments(appointmentsData);
      setExpenses(expensesData.map(e => ({ ...e, billable: e.billable === 1 })));
      setAdvances(advancesData);
      setInvoices(invoicesData);
      setCourtTypes(courtTypesData);
      setRegions(regionsData);
      setHearingPurposes(purposesData);
      setTaskTypes(taskTypesData);
      setExpenseCategories(expenseCategoriesData);
      setEntityTypes(entityTypesData || []);
      setLawyers(lawyersData);
      setDashboardStats(statsData);
      
      // Load deadlines separately (graceful if API not yet available)
      try {
        const deadlinesData = await window.electronAPI.getAllDeadlines();
        setDeadlines(deadlinesData || []);
      } catch (e) {
        console.log('Deadlines API not available yet');
        setDeadlines([]);
      }

      // Load corporate entities (v41.1)
      try {
        const corporateData = await window.electronAPI.getAllCorporateEntities();
        setCorporateEntities(corporateData || []);
      } catch (e) {
        console.log('Corporate entities API not available yet');
        setCorporateEntities([]);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  // ============================================
  // TARGETED REFRESH FUNCTIONS
  // ============================================
  const refreshClients = async () => {
    try {
      const [clientsData, statsData] = await Promise.all([
        window.electronAPI.getAllClients(),
        window.electronAPI.getDashboardStats()
      ]);
      setClients(clientsData);
      setDashboardStats(statsData);
    } catch (error) {
      console.error('Error refreshing clients:', error);
    }
  };

  const refreshMatters = async () => {
    try {
      const [mattersData, statsData] = await Promise.all([
        window.electronAPI.getAllMatters(),
        window.electronAPI.getDashboardStats()
      ]);
      setMatters(mattersData);
      setDashboardStats(statsData);
    } catch (error) {
      console.error('Error refreshing matters:', error);
    }
  };

  const refreshHearings = async () => {
    try {
      const [hearingsData, statsData] = await Promise.all([
        window.electronAPI.getAllHearings(),
        window.electronAPI.getDashboardStats()
      ]);
      setHearings(hearingsData);
      setDashboardStats(statsData);
    } catch (error) {
      console.error('Error refreshing hearings:', error);
    }
  };

  const refreshJudgments = async () => {
    try {
      const judgmentsData = await window.electronAPI.getAllJudgments();
      setJudgments(judgmentsData);
    } catch (error) {
      console.error('Error refreshing judgments:', error);
    }
  };

  const refreshTasks = async () => {
    try {
      const [tasksData, statsData] = await Promise.all([
        window.electronAPI.getAllTasks(),
        window.electronAPI.getDashboardStats()
      ]);
      setTasks(tasksData);
      setDashboardStats(statsData);
    } catch (error) {
      console.error('Error refreshing tasks:', error);
    }
  };

  const refreshTimesheets = async () => {
    try {
      const timesheetsData = await window.electronAPI.getAllTimesheets();
      setTimesheets(timesheetsData.map(ts => ({ ...ts, billable: ts.billable === 1 })));
    } catch (error) {
      console.error('Error refreshing timesheets:', error);
    }
  };

  const refreshAppointments = async () => {
    try {
      const appointmentsData = await window.electronAPI.getAllAppointments();
      setAppointments(appointmentsData);
    } catch (error) {
      console.error('Error refreshing appointments:', error);
    }
  };

  const refreshExpenses = async () => {
    try {
      const expensesData = await window.electronAPI.getAllExpenses();
      setExpenses(expensesData.map(e => ({ ...e, billable: e.billable === 1 })));
    } catch (error) {
      console.error('Error refreshing expenses:', error);
    }
  };

  const refreshAdvances = async () => {
    try {
      const advancesData = await window.electronAPI.getAllAdvances();
      setAdvances(advancesData);
    } catch (error) {
      console.error('Error refreshing advances:', error);
    }
  };

  const refreshInvoices = async () => {
    try {
      const [invoicesData, statsData, advancesData] = await Promise.all([
        window.electronAPI.getAllInvoices(),
        window.electronAPI.getDashboardStats(),
        window.electronAPI.getAllAdvances()
      ]);
      setInvoices(invoicesData);
      setDashboardStats(statsData);
      setAdvances(advancesData);
    } catch (error) {
      console.error('Error refreshing invoices:', error);
    }
  };

  const refreshDeadlines = async () => {
    try {
      const deadlinesData = await window.electronAPI.getAllDeadlines();
      setDeadlines(deadlinesData || []);
    } catch (error) {
      console.error('Error refreshing deadlines:', error);
    }
  };

  // Generate Client Statement (v44.3)
  const generateClientStatement = async (clientId, dateFrom, dateTo) => {
    if (!clientId) {
      showToast(language === 'ar' ? 'يرجى اختيار عميل' : 'Please select a client', 'error');
      return;
    }
    
    setClientStatementLoading(true);
    try {
      const data = await window.electronAPI.generateReport('client-statement', {
        clientId,
        dateFrom: dateFrom || '2000-01-01',
        dateTo: dateTo || new Date().toISOString().split('T')[0]
      });
      
      if (data.error) {
        showToast(data.error, 'error');
        return;
      }
      
      setClientStatementData(data);
    } catch (error) {
      console.error('Error generating client statement:', error);
      showToast(language === 'ar' ? 'خطأ في إنشاء البيان' : 'Error generating statement', 'error');
    } finally {
      setClientStatementLoading(false);
    }
  };

  // Export Client Statement (v44.3)
  const exportClientStatement = async (format) => {
    if (!clientStatementData) return;
    
    try {
      const firmInfo = await window.electronAPI.getFirmInfo();
      let result;
      
      if (format === 'pdf') {
        result = await window.electronAPI.exportClientStatementPdf(clientStatementData, firmInfo);
      } else {
        result = await window.electronAPI.exportClientStatementExcel(clientStatementData);
      }
      
      if (result.success) {
        showToast(language === 'ar' ? 'تم تصدير البيان بنجاح' : 'Statement exported successfully');
      } else if (!result.canceled) {
        showToast(result.error || 'Export failed', 'error');
      }
    } catch (error) {
      console.error('Error exporting statement:', error);
      showToast(language === 'ar' ? 'خطأ في التصدير' : 'Export error', 'error');
    }
  };

  // Generate Case Status Report (v44.3)
  const generateCaseStatusReport = async (clientId) => {
    if (!clientId) {
      showToast(language === 'ar' ? 'يرجى اختيار عميل' : 'Please select a client', 'error');
      return;
    }
    
    setCaseStatusLoading(true);
    try {
      const data = await window.electronAPI.generateReport('case-status-report', { clientId });
      
      if (data.error) {
        showToast(data.error, 'error');
        return;
      }
      
      setCaseStatusData(data);
    } catch (error) {
      console.error('Error generating case status report:', error);
      showToast(language === 'ar' ? 'خطأ في إنشاء التقرير' : 'Error generating report', 'error');
    } finally {
      setCaseStatusLoading(false);
    }
  };

  // Export Case Status Report (v44.3)
  const exportCaseStatusReport = async (format) => {
    if (!caseStatusData) return;
    
    try {
      const firmInfo = await window.electronAPI.getFirmInfo();
      let result;
      
      if (format === 'pdf') {
        result = await window.electronAPI.exportCaseStatusPdf(caseStatusData, firmInfo);
      } else {
        result = await window.electronAPI.exportCaseStatusExcel(caseStatusData);
      }
      
      if (result.success) {
        showToast(language === 'ar' ? 'تم تصدير التقرير بنجاح' : 'Report exported successfully');
      } else if (!result.canceled) {
        showToast(result.error || 'Export failed', 'error');
      }
    } catch (error) {
      console.error('Error exporting report:', error);
      showToast(language === 'ar' ? 'خطأ في التصدير' : 'Export error', 'error');
    }
  };

  // Generate Client 360° Report (v44.5)
  const generateClient360Report = async (clientId) => {
    if (!clientId) return;
    
    setClient360Loading(true);
    try {
      const data = await window.electronAPI.generateReport('client-360-report', { clientId });
      
      if (!data || data.error) {
        showToast(data?.error || 'Error generating report', 'error');
        return;
      }
      
      setClient360Data(data);
    } catch (error) {
      console.error('Error generating client 360 report:', error);
      showToast(language === 'ar' ? 'خطأ في إنشاء التقرير' : 'Error generating report', 'error');
    } finally {
      setClient360Loading(false);
    }
  };

  // Export Client 360° Report (v44.5)
  const exportClient360Report = async (format) => {
    if (!client360Data) return;
    
    try {
      const firmInfo = await window.electronAPI.getFirmInfo();
      let result;
      
      if (format === 'pdf') {
        result = await window.electronAPI.exportClient360Pdf(client360Data, firmInfo);
      } else {
        result = await window.electronAPI.exportClient360Excel(client360Data);
      }
      
      if (result.success) {
        showToast(language === 'ar' ? 'تم تصدير التقرير بنجاح' : 'Report exported successfully');
      } else if (!result.canceled) {
        showToast(result.error || 'Export failed', 'error');
      }
    } catch (error) {
      console.error('Error exporting report:', error);
      showToast(language === 'ar' ? 'خطأ في التصدير' : 'Export error', 'error');
    }
  };

  const refreshCorporateEntities = async () => {
    try {
      // Issue #1 fix: Use getCorporateClients to get ALL qualifying clients
      // (not just those with corporate_entities records)
      const data = await window.electronAPI.getCorporateClients();
      setCorporateEntities(data || []);
    } catch (error) {
      console.error('Error refreshing corporate entities:', error);
    }
  };

  const refreshLookups = async () => {
    try {
      const [courtTypesData, regionsData, purposesData, taskTypesData, expenseCategoriesData, entityTypesData, lawyersData] = await Promise.all([
        window.electronAPI.getCourtTypes(),
        window.electronAPI.getRegions(),
        window.electronAPI.getHearingPurposes(),
        window.electronAPI.getTaskTypes(),
        window.electronAPI.getExpenseCategories(),
        window.electronAPI.getEntityTypes(),
        window.electronAPI.getLawyers()
      ]);
      setCourtTypes(courtTypesData);
      setRegions(regionsData);
      setHearingPurposes(purposesData);
      setTaskTypes(taskTypesData);
      setExpenseCategories(expenseCategoriesData);
      setEntityTypes(entityTypesData || []);
      setLawyers(lawyersData);
    } catch (error) {
      console.error('Error refreshing lookups:', error);
    }
  };

  // ============================================
  // UTILITY FUNCTIONS
  // ============================================
  // generateID moved outside App

  // formatDate moved outside App

  // ============================================
  // CONFLICT CHECK
  // ============================================
  const runConflictCheck = async (searchTerms) => {
    try {
      const results = await window.electronAPI.conflictCheck(searchTerms);
      setConflictResults(results);
      if (results.length > 0) {
        setShowConflictResults(true);
      }
      return results;
    } catch (error) {
      console.error('Error running conflict check:', error);
      return [];
    }
  };

  // ClientForm moved outside App


  // ============================================
  // CONTACT FORM COMPONENT
  // ============================================
  // MatterForm moved outside App


  // HearingForm moved outside App


  // TaskForm moved outside App


  // TimesheetForm moved outside App


  // JudgmentForm moved outside App


  // AppointmentForm moved outside App


  // ============================================
  // CALENDAR COMPONENT
  // ============================================
  const CalendarModule = () => {
    // viewMode lifted to App level: calendarView, setCalendarView
    const viewMode = calendarView;
    const setViewMode = setCalendarView;
    
    // Get week dates
    const getWeekDates = (date) => {
      const start = new Date(date);
      start.setDate(start.getDate() - start.getDay()); // Start from Sunday
      const dates = [];
      for (let i = 0; i < 7; i++) {
        const d = new Date(start);
        d.setDate(start.getDate() + i);
        dates.push(d);
      }
      return dates;
    };

    // Get month dates (including padding from prev/next months)
    const getMonthDates = (date) => {
      const year = date.getFullYear();
      const month = date.getMonth();
      const firstDay = new Date(year, month, 1);
      const lastDay = new Date(year, month + 1, 0);
      const startPadding = firstDay.getDay();
      const dates = [];
      
      for (let i = startPadding - 1; i >= 0; i--) {
        const d = new Date(year, month, -i);
        dates.push({ date: d, isCurrentMonth: false });
      }
      
      for (let i = 1; i <= lastDay.getDate(); i++) {
        dates.push({ date: new Date(year, month, i), isCurrentMonth: true });
      }
      
      const remaining = 42 - dates.length;
      for (let i = 1; i <= remaining; i++) {
        dates.push({ date: new Date(year, month + 1, i), isCurrentMonth: false });
      }
      
      return dates;
    };

    const weekDates = getWeekDates(calendarDate);
    const monthDates = getMonthDates(calendarDate);
    const today = new Date().toISOString().split('T')[0];
    
    // Find Judgment Pronouncement purpose to exclude
    const jpPurpose = hearingPurposes.find(p => p.name_en === 'Judgment Pronouncement');

    const getEventsForDate = (dateStr) => {
      const events = [];
      
      hearings.filter(h => h.hearing_date === dateStr && !(jpPurpose && h.purpose_id === jpPurpose.purpose_id)).forEach(h => {
        const matter = matters.find(m => m.matter_id === h.matter_id);
        events.push({
          type: 'hearing', time: h.hearing_time, title: matter?.matter_name || 'Hearing',
          color: 'bg-red-100 text-red-800 border-red-300', id: h.hearing_id
        });
      });
      
      appointments.filter(a => a.date === dateStr).forEach(a => {
        events.push({
          type: 'appointment', time: a.start_time, title: a.title,
          color: 'bg-blue-100 text-blue-800 border-blue-300', id: a.appointment_id
        });
      });
      
      tasks.filter(t => t.due_date === dateStr && t.status !== 'done').forEach(t => {
        events.push({
          type: 'task', time: t.due_time || '', title: t.title,
          color: 'bg-yellow-100 text-yellow-800 border-yellow-300', id: t.task_id
        });
      });
      
      judgments.filter(j => j.expected_date === dateStr && j.status === 'pending').forEach(j => {
        const matter = matters.find(m => m.matter_id === j.matter_id);
        events.push({
          type: 'judgment', time: '', title: matter?.matter_name || 'Judgment',
          color: 'bg-purple-100 text-purple-800 border-purple-300', id: j.judgment_id
        });
      });
      
      return events.sort((a, b) => (a.time || '').localeCompare(b.time || ''));
    };

    const navigate = (direction) => {
      const newDate = new Date(calendarDate);
      if (viewMode === 'daily') {
        newDate.setDate(newDate.getDate() + direction);
      } else if (viewMode === 'weekly') {
        newDate.setDate(newDate.getDate() + (direction * 7));
      } else {
        newDate.setMonth(newDate.getMonth() + direction);
      }
      setCalendarDate(newDate);
    };

    const goToToday = () => setCalendarDate(new Date());
    const formatDate = (date) => date.toISOString().split('T')[0];
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dayNamesAr = ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
    const timeSlots = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];

    const DayView = () => {
      const dateStr = formatDate(calendarDate);
      const events = getEventsForDate(dateStr);
      const isToday = dateStr === today;
      
      return (
        <div className="bg-white rounded-lg border">
          <div className={`text-center py-3 border-b ${isToday ? 'bg-blue-600 text-white' : 'bg-gray-50'}`}>
            <div className="text-sm">{language === 'ar' ? dayNamesAr[calendarDate.getDay()] : dayNames[calendarDate.getDay()]}</div>
            <div className="text-2xl font-bold">{calendarDate.getDate()}</div>
            <div className="text-sm">{calendarDate.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', { month: 'long', year: 'numeric' })}</div>
          </div>
          
          <div className="divide-y max-h-[500px] overflow-y-auto">
            {timeSlots.map(slot => {
              const slotEvents = events.filter(e => e.time && e.time.startsWith(slot.split(':')[0]));
              return (
                <div key={slot} className="flex min-h-[50px]">
                  <div className="w-16 py-2 px-2 text-xs text-gray-500 bg-gray-50 border-r flex-shrink-0">{slot}</div>
                  <div className="flex-1 p-1 space-y-1">
                    {slotEvents.map((event, i) => (
                      <div key={i} className={`text-sm p-2 rounded border ${event.color}`}>
                        <span className="font-medium">{event.time}</span> - {event.title}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
          
          {events.filter(e => !e.time).length > 0 && (
            <div className="border-t p-3">
              <div className="text-xs text-gray-500 mb-2">{t[language].allDay || 'All Day'}</div>
              <div className="space-y-1">
                {events.filter(e => !e.time).map((event, i) => (
                  <div key={i} className={`text-sm p-2 rounded border ${event.color}`}>{event.title}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      );
    };

    const WeekView = () => (
      <div className="grid grid-cols-7 gap-2">
        {weekDates.map((date, idx) => {
          const dateStr = formatDate(date);
          const events = getEventsForDate(dateStr);
          const isToday = dateStr === today;
          
          return (
            <div 
              key={idx} 
              onClick={() => { setCalendarDate(date); setViewMode('daily'); }}
              className={`border rounded-lg min-h-[200px] cursor-pointer hover:border-blue-400 hover:shadow-sm transition-all ${isToday ? 'bg-blue-50 border-blue-300' : ''}`}
            >
              <div 
                className={`text-center py-2 border-b ${isToday ? 'bg-blue-600 text-white' : 'bg-gray-50'}`}
              >
                <div className="text-xs">{language === 'ar' ? dayNamesAr[idx] : dayNames[idx]}</div>
                <div className="text-lg font-bold">{date.getDate()}</div>
              </div>
              <div className="p-1 space-y-1">
                {events.length === 0 ? (
                  <div className="text-xs text-gray-400 text-center py-4">{t[language].noEvents}</div>
                ) : (
                  events.slice(0, 5).map((event, i) => (
                    <div key={i} className={`text-xs p-1 rounded border ${event.color} truncate`}>
                      {event.time && <span className="font-medium">{event.time} </span>}
                      {event.title}
                    </div>
                  ))
                )}
                {events.length > 5 && (
                  <div className="text-xs text-gray-500 text-center">+{events.length - 5} more</div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    );

    const MonthView = () => (
      <div>
        <div className="grid grid-cols-7 gap-1 mb-1">
          {(language === 'ar' ? dayNamesAr : dayNames).map((day, idx) => (
            <div key={idx} className="text-center text-xs font-medium text-gray-500 py-2">{day}</div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 gap-1">
          {monthDates.map((item, idx) => {
            const dateStr = formatDate(item.date);
            const events = getEventsForDate(dateStr);
            const isToday = dateStr === today;
            
            return (
              <div 
                key={idx} 
                onClick={() => { setCalendarDate(item.date); setViewMode('daily'); }}
                className={`border rounded min-h-[80px] cursor-pointer hover:border-blue-400 hover:shadow-sm transition-all ${
                  !item.isCurrentMonth ? 'bg-gray-50 text-gray-400' : isToday ? 'bg-blue-50 border-blue-300' : ''
                }`}
              >
                <div className={`text-right p-1 ${isToday ? 'font-bold text-blue-600' : ''}`}>{item.date.getDate()}</div>
                <div className="px-1 pb-1 space-y-0.5">
                  {events.slice(0, 3).map((event, i) => (
                    <div key={i} className={`text-xs px-1 rounded truncate ${event.color}`}>{event.title}</div>
                  ))}
                  {events.length > 3 && <div className="text-xs text-gray-500 px-1">+{events.length - 3}</div>}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );

    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">{t[language].calendar}</h2>
          <button onClick={() => setShowAppointmentForm(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
            <Plus className="w-4 h-4" /> {t[language].addAppointment}
          </button>
        </div>

        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <button onClick={() => navigate(-1)} className="px-3 py-1 border rounded hover:bg-gray-50">
                {t[language].previousWeek || 'Previous'}
              </button>
              <button onClick={goToToday} className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700">
                {t[language].today}
              </button>
              <button onClick={() => navigate(1)} className="px-3 py-1 border rounded hover:bg-gray-50">
                {t[language].nextWeek || 'Next'}
              </button>
            </div>
            
            <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
              <button onClick={() => setViewMode('daily')}
                className={`px-3 py-1 rounded text-sm ${viewMode === 'daily' ? 'bg-white shadow' : 'hover:bg-gray-200'}`}>
                {t[language].daily}
              </button>
              <button onClick={() => setViewMode('weekly')}
                className={`px-3 py-1 rounded text-sm ${viewMode === 'weekly' ? 'bg-white shadow' : 'hover:bg-gray-200'}`}>
                {t[language].weekly}
              </button>
              <button onClick={() => setViewMode('monthly')}
                className={`px-3 py-1 rounded text-sm ${viewMode === 'monthly' ? 'bg-white shadow' : 'hover:bg-gray-200'}`}>
                {t[language].monthly}
              </button>
            </div>
            
            <div className="text-lg font-semibold">
              {viewMode === 'daily' 
                ? calendarDate.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })
                : calendarDate.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', { month: 'long', year: 'numeric' })
              }
            </div>
          </div>

          {viewMode === 'daily' && <DayView />}
          {viewMode === 'weekly' && <WeekView />}
          {viewMode === 'monthly' && <MonthView />}
        </div>

        <div className="flex gap-4 text-sm">
          <span className="flex items-center gap-1"><span className="w-3 h-3 bg-red-200 rounded"></span> {t[language].hearings}</span>
          <span className="flex items-center gap-1"><span className="w-3 h-3 bg-blue-200 rounded"></span> {t[language].appointments}</span>
          <span className="flex items-center gap-1"><span className="w-3 h-3 bg-yellow-200 rounded"></span> {t[language].tasks}</span>
          <span className="flex items-center gap-1"><span className="w-3 h-3 bg-purple-200 rounded"></span> {t[language].judgments}</span>
        </div>
      </div>
    );
  };

  // ============================================
  // JUDGMENTS LIST COMPONENT
  // ============================================
  const JudgmentsList = () => {
    const today = new Date().toISOString().split('T')[0];
    
    // Helper to translate judgment type
    const getJudgmentTypeLabel = (type) => {
      const typeMap = {
        'first_instance': t[language].firstInstance,
        'appeal': t[language].appeal,
        'cassation': t[language].cassation,
        'arbitral_award': t[language].arbitralAward
      };
      return typeMap[type] || type;
    };

    // Get linked deadlines for a judgment
    const getJudgmentDeadlines = (judgmentId) => {
      return deadlines.filter(d => d.judgment_id === judgmentId);
    };

    // Get deadline status indicator
    const getDeadlineIndicator = (judgmentId) => {
      const linkedDeadlines = getJudgmentDeadlines(judgmentId);
      if (linkedDeadlines.length === 0) return null;
      
      const pendingDeadlines = linkedDeadlines.filter(d => d.status === 'pending');
      const overdueDeadlines = pendingDeadlines.filter(d => d.deadline_date < today);
      const upcomingDeadlines = pendingDeadlines.filter(d => d.deadline_date >= today && d.deadline_date <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
      
      if (overdueDeadlines.length > 0) {
        return <span className="px-2 py-0.5 text-xs rounded-full bg-red-100 text-red-800 ml-2">⚠️ {overdueDeadlines.length} {t[language].overdueDeadlines}</span>;
      }
      if (upcomingDeadlines.length > 0) {
        return <span className="px-2 py-0.5 text-xs rounded-full bg-yellow-100 text-yellow-800 ml-2">🕐 {upcomingDeadlines.length} {language === 'ar' ? 'قريب' : 'soon'}</span>;
      }
      return <span className="px-2 py-0.5 text-xs rounded-full bg-green-100 text-green-800 ml-2">✓ {linkedDeadlines.length}</span>;
    };

    // Add deadline for judgment
    const handleAddDeadlineForJudgment = (judgment) => {
      const matter = matters.find(m => m.matter_id === judgment.matter_id);
      // Auto-generate title based on matter name
      const autoTitle = language === 'ar' 
        ? `موعد استئناف - ${matter?.matter_name || ''}` 
        : `Appeal Deadline - ${matter?.matter_name || ''}`;
      setEditingDeadline({
        client_id: matter?.client_id || '',
        matter_id: judgment.matter_id,
        judgment_id: judgment.judgment_id,
        title: autoTitle,
        deadline_date: judgment.expected_date || '',
        reminder_days: '7',
        priority: 'high',
        status: 'pending',
        notes: '',
        _fromJudgment: true  // Flag to hide title field in form
      });
      setShowDeadlineForm(true);
    };

    // Filter out judgments that have been moved to hearings (not_final with follow-up hearing)
    const filteredJudgments = judgments.filter(j => j.status !== 'moved_to_hearing');

    return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t[language].judgments}</h2>
        <button onClick={() => setShowJudgmentForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          <Plus className="w-5 h-5" /> {t[language].addJudgment}
        </button>
      </div>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].matter}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].client}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].judgmentDate || (language === 'ar' ? 'تاريخ الحكم' : 'Judgment Date')}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].deadline || 'Deadline'}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].judgmentType}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].status}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].actions}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredJudgments.length === 0 ? (
              <tr><td colSpan="7" className="px-6 py-8 text-center text-gray-500">{t[language].noData}</td></tr>
            ) : (
              filteredJudgments.map(j => {
                const matter = matters.find(m => m.matter_id === j.matter_id);
                const client = clients.find(c => c.client_id === matter?.client_id);
                const sourceHearing = j.hearing_id ? hearings.find(h => h.hearing_id === j.hearing_id) : null;
                const judgmentDeadline = deadlines.find(d => d.judgment_id === j.judgment_id);
                
                return (
                  <tr key={j.judgment_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="font-medium">{matter?.matter_name || '--'}</div>
                      {sourceHearing && (
                        <div className="text-xs text-blue-600 mt-1">
                          📋 {t[language].fromHearing || 'From Hearing'}: {formatDate(sourceHearing.hearing_date)}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">{client?.client_name || '--'}</td>
                    <td className="px-6 py-4 text-sm">
                      {j.expected_date ? (
                        <span className="font-medium">{formatDate(j.expected_date)}</span>
                      ) : (
                        <span className="text-gray-400">--</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      {judgmentDeadline ? (
                        <span className="font-medium text-orange-600">{formatDate(judgmentDeadline.deadline_date)}</span>
                      ) : (
                        <button onClick={() => handleAddDeadlineForJudgment(j)}
                          className="text-orange-600 hover:text-orange-900 text-xs flex items-center gap-1">
                          <Plus className="w-3 h-3" /> {t[language].add || 'Add'}
                        </button>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm">{getJudgmentTypeLabel(j.judgment_type)}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        j.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        j.status === 'pronounced' ? 'bg-blue-100 text-blue-800' :
                        j.status === 'appealed' ? 'bg-purple-100 text-purple-800' :
                        j.status === 'final' ? 'bg-green-100 text-green-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>{t[language][j.status] || j.status}</span>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <div className="flex items-center gap-2">
                        <button onClick={() => { setEditingJudgment(j); setShowJudgmentForm(true); }}
                          className="text-blue-600 hover:text-blue-900">{t[language].edit}</button>
                        <button onClick={() => {
                          showConfirm(
                            language === 'ar' ? 'حذف الحكم' : 'Delete Judgment',
                            language === 'ar' ? 'هل أنت متأكد من حذف هذا الحكم؟' : 'Are you sure you want to delete this judgment?',
                            async () => {
                              await window.electronAPI.deleteJudgment(j.judgment_id);
                              await refreshJudgments();
                              showToast(language === 'ar' ? 'تم حذف الحكم' : 'Judgment deleted');
                              hideConfirm();
                            }
                          );
                        }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
  };

  // ============================================
  // APPOINTMENTS LIST COMPONENT
  // ============================================
  const AppointmentsList = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t[language].appointments}</h2>
        <button onClick={() => setShowAppointmentForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          <Plus className="w-5 h-5" /> {t[language].addAppointment}
        </button>
      </div>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].date}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].title}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].appointmentType}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].client}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].locationType}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {appointments.length === 0 ? (
              <tr><td colSpan="6" className="px-6 py-8 text-center text-gray-500">{t[language].noData}</td></tr>
            ) : (
              appointments.map(a => {
                const client = clients.find(c => c.client_id === a.client_id);
                return (
                  <tr key={a.appointment_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm">
                      {a.date} {!a.all_day && a.start_time && `${a.start_time}-${a.end_time}`}
                    </td>
                    <td className="px-6 py-4 font-medium">{a.title}</td>
                    <td className="px-6 py-4 text-sm">{t[language][a.appointment_type?.replace('_', '')] || a.appointment_type}</td>
                    <td className="px-6 py-4 text-sm">{client?.client_name || '--'}</td>
                    <td className="px-6 py-4 text-sm">{t[language][a.location_type] || a.location_type}</td>
                    <td className="px-6 py-4 text-sm">
                      <button onClick={() => { setEditingAppointment(a); setShowAppointmentForm(true); }}
                        className="text-blue-600 hover:text-blue-900 mr-3">{t[language].edit}</button>
                      <button onClick={() => {
                        showConfirm(
                          language === 'ar' ? 'حذف الموعد' : 'Delete Appointment',
                          language === 'ar' ? 'هل أنت متأكد من حذف هذا الموعد؟' : 'Are you sure you want to delete this appointment?',
                          async () => {
                            await window.electronAPI.deleteAppointment(a.appointment_id);
                            await refreshAppointments();
                            showToast(language === 'ar' ? 'تم حذف الموعد' : 'Appointment deleted');
                            hideConfirm();
                          }
                        );
                      }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  // ============================================
  // DASHBOARD COMPONENT
  // ============================================
  const Dashboard = () => {
    const today = new Date().toISOString().split('T')[0];
    
    // Find Judgment Pronouncement purpose to exclude from hearings displays
    const jpPurpose = hearingPurposes.find(p => p.name_en === 'Judgment Pronouncement');
    const isJPHearing = (h) => jpPurpose && h.purpose_id === jpPurpose.purpose_id;
    
    const todayHearings = hearings.filter(h => h.hearing_date === today && !isJPHearing(h));
    const overdueTasks = tasks.filter(t => t.status !== 'done' && t.due_date && t.due_date < today);
    const todayTasks = tasks.filter(t => t.status !== 'done' && t.due_date === today);
    const pendingJudgments = judgments.filter(j => j.status === 'pending');
    const upcomingHearingsFiltered = hearings.filter(h => h.hearing_date >= today && !isJPHearing(h)).sort((a,b) => a.hearing_date.localeCompare(b.hearing_date));
    const upcomingHearingsCount = upcomingHearingsFiltered.length;
    const upcomingHearingsList = upcomingHearingsFiltered.slice(0, 5);
    
    // Deadline calculations
    const overdueDeadlines = deadlines.filter(d => d.status === 'pending' && d.deadline_date < today);
    const upcomingDeadlinesList = deadlines
      .filter(d => d.status === 'pending' && d.deadline_date >= today)
      .sort((a,b) => a.deadline_date.localeCompare(b.deadline_date))
      .slice(0, 5);

    // Widget names mapping
    const widgetNames = {
      stats: t[language].statsWidget || 'Statistics Cards',
      todaySchedule: t[language].todayScheduleWidget || "Today's Schedule",
      tasksDue: t[language].tasksDueWidget || 'Tasks Due',
      upcomingHearings: t[language].upcomingHearingsWidget || 'Upcoming Hearings',
      pendingJudgments: t[language].pendingJudgmentsWidgetLabel || 'Pending Judgments',
      upcomingDeadlines: t[language].upcomingDeadlines || 'Upcoming Deadlines'
    };

    // Save widget preferences to localStorage
    const saveWidgetPrefs = (newConfig) => {
      setDashboardWidgets(newConfig);
      localStorage.setItem('qanuni_dashboard_widgets', JSON.stringify(newConfig));
    };

    // Toggle widget visibility
    const toggleWidget = (widgetId) => {
      const newConfig = {
        ...dashboardWidgets,
        visible: { ...dashboardWidgets.visible, [widgetId]: !dashboardWidgets.visible[widgetId] }
      };
      saveWidgetPrefs(newConfig);
    };

    // Handle drag start
    const handleDragStart = (e, widgetId) => {
      setDraggedWidget(widgetId);
      e.dataTransfer.effectAllowed = 'move';
    };

    // Handle drag over
    const handleDragOver = (e, widgetId) => {
      e.preventDefault();
      if (draggedWidget === widgetId) return;
    };

    // Handle drop
    const handleDrop = (e, targetId) => {
      e.preventDefault();
      if (!draggedWidget || draggedWidget === targetId) return;
      
      const newOrder = [...dashboardWidgets.order];
      const draggedIndex = newOrder.indexOf(draggedWidget);
      const targetIndex = newOrder.indexOf(targetId);
      
      newOrder.splice(draggedIndex, 1);
      newOrder.splice(targetIndex, 0, draggedWidget);
      
      saveWidgetPrefs({ ...dashboardWidgets, order: newOrder });
      setDraggedWidget(null);
    };

    // Reset to default layout
    const resetLayout = () => {
      const defaultConfig = {
        order: ['stats', 'todaySchedule', 'upcomingDeadlines', 'tasksDue', 'upcomingHearings', 'pendingJudgments'],
        visible: { stats: true, todaySchedule: true, upcomingDeadlines: true, tasksDue: true, upcomingHearings: true, pendingJudgments: true }
      };
      saveWidgetPrefs(defaultConfig);
    };

    // Widget components
    const widgets = {
      stats: (
        <>
          {/* Stats Cards - Row 1 */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">{t[language].totalClients}</p>
                  <p className="text-3xl font-bold mt-2">{dashboardStats.totalClients || clients.length}</p>
                </div>
                <Users className="w-12 h-12 text-blue-500" />
              </div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">{t[language].activeMatters}</p>
                  <p className="text-3xl font-bold mt-2">{dashboardStats.activeMatters || matters.filter(m => m.status === 'active').length}</p>
                </div>
                <Briefcase className="w-12 h-12 text-green-500" />
              </div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">{t[language].pendingTasks}</p>
                  <p className="text-3xl font-bold mt-2">{dashboardStats.pendingTasks || tasks.filter(t => t.status !== 'done').length}</p>
                </div>
                <ClipboardList className="w-12 h-12 text-orange-500" />
              </div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">{t[language].upcomingHearings}</p>
                  <p className="text-3xl font-bold mt-2">{dashboardStats.upcomingHearings ?? upcomingHearingsCount}</p>
                </div>
                <Gavel className="w-12 h-12 text-purple-500" />
              </div>
            </div>
          </div>

          {/* Stats Cards - Row 2 */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">{t[language].overdueTasks || 'Overdue Tasks'}</p>
                  <p className="text-3xl font-bold mt-2 text-red-600">{dashboardStats.overdueTasks || overdueTasks.length}</p>
                </div>
                <AlertCircle className="w-12 h-12 text-red-500" />
              </div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">{t[language].pendingJudgmentsWidget || 'Pending Judgments'}</p>
                  <p className="text-3xl font-bold mt-2">{dashboardStats.pendingJudgments || pendingJudgments.length}</p>
                </div>
                <Scale className="w-12 h-12 text-indigo-500" />
              </div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">{t[language].outstandingBalance || 'Outstanding Balance'}</p>
                  <p className="text-2xl font-bold mt-2">${(dashboardStats.outstandingInvoices || 0).toLocaleString()}</p>
                </div>
                <DollarSign className="w-12 h-12 text-yellow-500" />
              </div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">{t[language].thisMonth}</p>
                  <p className="text-2xl font-bold mt-2 text-green-600">${(dashboardStats.thisMonthRevenue || 0).toLocaleString()}</p>
                </div>
                <Wallet className="w-12 h-12 text-green-500" />
              </div>
            </div>
          </div>
        </>
      ),
      todaySchedule: (
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">{t[language].todaySchedule}</h3>
          {todayHearings.length === 0 ? (
            <p className="text-gray-500">{t[language].noHearingsToday || 'No hearings scheduled for today'}</p>
          ) : (
            <div className="space-y-3">
              {todayHearings.map(h => {
                const matter = matters.find(m => m.matter_id === h.matter_id);
                return (
                  <div key={h.hearing_id} className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                    <Gavel className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="font-medium">{matter?.matter_name}</p>
                      <p className="text-sm text-gray-600">{h.hearing_time} - {h.purpose_custom}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ),
      tasksDue: (
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">{t[language].tasks}</h3>
          {overdueTasks.length > 0 && (
            <div className="mb-4">
              <h4 className="text-sm font-medium text-red-600 mb-2">{t[language].overdue} ({overdueTasks.length})</h4>
              <div className="space-y-2">
                {overdueTasks.slice(0, 3).map(task => (
                  <div key={task.task_id} className="flex items-center gap-2 p-2 bg-red-50 rounded">
                    <span className={`w-2 h-2 rounded-full ${task.priority === 'high' ? 'bg-red-500' : 'bg-yellow-500'}`}></span>
                    <span className="text-sm">{task.title}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          {todayTasks.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-orange-600 mb-2">{t[language].dueToday} ({todayTasks.length})</h4>
              <div className="space-y-2">
                {todayTasks.slice(0, 3).map(task => (
                  <div key={task.task_id} className="flex items-center gap-2 p-2 bg-orange-50 rounded">
                    <span className={`w-2 h-2 rounded-full ${task.priority === 'high' ? 'bg-red-500' : 'bg-yellow-500'}`}></span>
                    <span className="text-sm">{task.title}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          {overdueTasks.length === 0 && todayTasks.length === 0 && (
            <p className="text-gray-500">{t[language].noTasksDue || 'No tasks due'}</p>
          )}
        </div>
      ),
      upcomingHearings: (
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">{t[language].upcomingHearings}</h3>
          {upcomingHearingsList.length === 0 ? (
            <p className="text-gray-500">{t[language].noData}</p>
          ) : (
            <div className="space-y-3">
              {upcomingHearingsList.map(h => {
                const matter = matters.find(m => m.matter_id === h.matter_id);
                const client = matter ? clients.find(c => c.client_id === matter.client_id) : null;
                return (
                  <div key={h.hearing_id} className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-purple-600" />
                      <div>
                        <p className="font-medium">{matter?.matter_name || 'Unknown'}</p>
                        <p className="text-sm text-gray-600">{client?.client_name}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{formatDate(h.hearing_date)}</p>
                      <p className="text-xs text-gray-500">{h.hearing_time}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ),
      pendingJudgments: (
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">{t[language].pendingJudgments}</h3>
          {pendingJudgments.length === 0 ? (
            <p className="text-gray-500">{t[language].noData}</p>
          ) : (
            <div className="space-y-3">
              {pendingJudgments.slice(0, 5).map(j => {
                const matter = matters.find(m => m.matter_id === j.matter_id);
                return (
                  <div key={j.judgment_id} className="flex items-center justify-between p-3 bg-indigo-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Scale className="w-5 h-5 text-indigo-600" />
                      <div>
                        <p className="font-medium">{matter?.matter_name || 'Unknown'}</p>
                        <p className="text-sm text-gray-600">{j.judgment_type}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{j.expected_date ? formatDate(j.expected_date) : 'TBD'}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ),
      upcomingDeadlines: (
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">{t[language].upcomingDeadlines}</h3>
            {overdueDeadlines.length > 0 && (
              <span className="px-2 py-1 text-xs rounded-full bg-red-100 text-red-800">
                {overdueDeadlines.length} {t[language].overdueDeadlines}
              </span>
            )}
          </div>
          {upcomingDeadlinesList.length === 0 && overdueDeadlines.length === 0 ? (
            <p className="text-gray-500">{t[language].noData}</p>
          ) : (
            <div className="space-y-3">
              {/* Show overdue first */}
              {overdueDeadlines.slice(0, 3).map(d => {
                const matter = matters.find(m => m.matter_id === d.matter_id);
                const daysOver = Math.ceil((new Date() - new Date(d.deadline_date)) / (1000 * 60 * 60 * 24));
                return (
                  <div key={d.deadline_id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg border-l-4 border-red-500">
                    <div className="flex items-center gap-3">
                      <AlertTriangle className="w-5 h-5 text-red-600" />
                      <div>
                        <p className="font-medium text-red-800">{d.title}</p>
                        <p className="text-sm text-red-600">{matter?.matter_name || ''}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-red-600">{daysOver} {t[language].daysOverdue}</p>
                    </div>
                  </div>
                );
              })}
              {/* Show upcoming */}
              {upcomingDeadlinesList.map(d => {
                const matter = matters.find(m => m.matter_id === d.matter_id);
                const daysUntil = Math.ceil((new Date(d.deadline_date) - new Date()) / (1000 * 60 * 60 * 24));
                const bgColor = daysUntil === 0 ? 'bg-orange-50' : daysUntil <= 7 ? 'bg-yellow-50' : 'bg-gray-50';
                const textColor = daysUntil === 0 ? 'text-orange-600' : daysUntil <= 7 ? 'text-yellow-700' : 'text-gray-600';
                return (
                  <div key={d.deadline_id} className={`flex items-center justify-between p-3 ${bgColor} rounded-lg`}>
                    <div className="flex items-center gap-3">
                      <AlertTriangle className={`w-5 h-5 ${textColor}`} />
                      <div>
                        <p className="font-medium">{d.title}</p>
                        <p className="text-sm text-gray-600">{matter?.matter_name || ''}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{formatDate(d.deadline_date)}</p>
                      <p className={`text-xs ${textColor}`}>
                        {daysUntil === 0 ? t[language].dueToday : `${daysUntil} ${t[language].daysRemaining}`}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          <button 
            onClick={() => handleModuleChange('deadlines')}
            className="mt-3 text-sm text-blue-600 hover:text-blue-800"
          >
            {t[language].view} {t[language].allDeadlines} →
          </button>
        </div>
      )
    };

    // Render widgets in order, respecting visibility
    const renderWidgets = () => {
      return dashboardWidgets.order.map((widgetId, index) => {
        if (!dashboardWidgets.visible[widgetId]) return null;
        
        // Special layout handling for stats (full width) vs others (2 columns)
        if (widgetId === 'stats') {
          return <div key={widgetId}>{widgets[widgetId]}</div>;
        }
        
        return widgets[widgetId];
      }).filter(Boolean);
    };

    // Group non-stats widgets for 2-column layout
    const nonStatsWidgets = dashboardWidgets.order
      .filter(id => id !== 'stats' && dashboardWidgets.visible[id])
      .map(id => widgets[id]);

    return (
      <div className="space-y-6">
        {/* Header with Customize button */}
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">{t[language].dashboard}</h2>
          <button 
            onClick={() => setShowWidgetSettings(!showWidgetSettings)}
            className="flex items-center gap-2 px-3 py-2 text-sm border rounded-md hover:bg-gray-50"
          >
            <Settings className="w-4 h-4" />
            {t[language].customizeDashboard || 'Customize'}
          </button>
        </div>

        {/* Widget Settings Panel */}
        {showWidgetSettings && (
          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold">{t[language].customizeDashboard || 'Customize Dashboard'}</h3>
              <button onClick={() => setShowWidgetSettings(false)} className="text-gray-500 hover:text-gray-700">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-sm text-gray-500 mb-4">{t[language].dragToReorder || 'Drag to reorder widgets'}</p>
            
            <div className="space-y-2">
              {dashboardWidgets.order.map((widgetId) => (
                <div 
                  key={widgetId}
                  draggable
                  onDragStart={(e) => handleDragStart(e, widgetId)}
                  onDragOver={(e) => handleDragOver(e, widgetId)}
                  onDrop={(e) => handleDrop(e, widgetId)}
                  className={`flex items-center justify-between p-3 border rounded-md cursor-move ${
                    draggedWidget === widgetId ? 'bg-blue-50 border-blue-300' : 'bg-gray-50 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Menu className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium">{widgetNames[widgetId]}</span>
                  </div>
                  <button 
                    onClick={() => toggleWidget(widgetId)}
                    className={`px-3 py-1 text-xs rounded-full ${
                      dashboardWidgets.visible[widgetId] 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {dashboardWidgets.visible[widgetId] ? (t[language].showWidget || 'Show') : (t[language].hideWidget || 'Hide')}
                  </button>
                </div>
              ))}
            </div>
            
            <div className="mt-4 flex justify-end">
              <button 
                onClick={resetLayout}
                className="px-4 py-2 text-sm border rounded-md hover:bg-gray-50"
              >
                {t[language].resetLayout || 'Reset Layout'}
              </button>
            </div>
          </div>
        )}

        {/* Stats Cards (always at top if visible) */}
        {dashboardWidgets.visible.stats && widgets.stats}

        {/* Other Widgets in 2-column grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {dashboardWidgets.order
            .filter(id => id !== 'stats' && dashboardWidgets.visible[id])
            .map(id => <div key={id}>{widgets[id]}</div>)
          }
        </div>
      </div>
    );
  };

  // ============================================
  // CONTACTS LIST COMPONENT
  // ============================================



  // ExpenseForm moved outside App



  // AdvanceForm moved outside App

  // ============================================
  // ADVANCES LIST COMPONENT (with sub-tabs)
  // ============================================
  const AdvancesList = () => {
    const [activeTab, setActiveTab] = useState('fees');
    const [clientFilter, setClientFilter] = useState('');
    const [lawyerFilter, setLawyerFilter] = useState('');
    
    // Helper to check if type is a fee (retainer or fee_payment_*)
    const isFeeType = (type) => type === 'client_retainer' || type?.startsWith('fee_payment');
    
    // Calculate totals by category
    const totals = {
      retainers: advances.filter(a => a.advance_type === 'client_retainer').reduce((sum, a) => sum + parseFloat(a.amount || 0), 0),
      expenseAdvances: advances.filter(a => a.advance_type === 'client_expense_advance').reduce((sum, a) => sum + parseFloat(a.amount || 0), 0),
      feePayments: advances.filter(a => a.advance_type?.startsWith('fee_payment')).reduce((sum, a) => sum + parseFloat(a.amount || 0), 0),
      lawyerAdvances: advances.filter(a => a.advance_type === 'lawyer_advance').reduce((sum, a) => sum + parseFloat(a.amount || 0), 0),
    };
    // Combined fees total (retainers + fee payments)
    totals.allFees = totals.retainers + totals.feePayments;
    
    // Calculate per-lawyer net balances from advance records AND expenses
    const lawyerBalances = lawyers.map(lawyer => {
      const lawyerAdvances = advances.filter(a => a.advance_type === 'lawyer_advance' && a.lawyer_id === lawyer.lawyer_id);
      const totalAdvanced = lawyerAdvances.reduce((sum, a) => sum + parseFloat(a.amount || 0), 0);
      
      // If lawyer has advances, use balance_remaining to calculate net balance
      // This already accounts for deductions made from advances
      const balanceFromAdvances = lawyerAdvances.reduce((sum, a) => sum + parseFloat(a.balance_remaining ?? a.amount ?? 0), 0);
      
      // Also check for expenses paid by this lawyer that might not be linked to advances yet
      // (e.g., lawyer paid out of pocket before receiving an advance)
      const expensesPaidByLawyer = expenses
        .filter(e => e.paid_by_lawyer_id === lawyer.lawyer_id)
        .reduce((sum, e) => sum + parseFloat(e.amount || 0), 0);
      
      // If there are advances, spent = advanced - balance_remaining
      // If no advances but has expenses, those are unreimbursed expenses
      const spentFromAdvances = totalAdvanced - balanceFromAdvances;
      
      // For display, we show the larger of: spent from advances OR expenses paid
      // This handles the case where expenses are tracked both ways during transition
      const totalSpent = Math.max(spentFromAdvances, expensesPaidByLawyer);
      
      // Net balance: what was advanced minus what was spent
      const netBalance = totalAdvanced - totalSpent;
      
      return {
        lawyer_id: lawyer.lawyer_id,
        name: lawyer.full_name || lawyer.name,
        totalAdvanced,
        totalSpent,
        netBalance
      };
    }).filter(lb => lb.totalAdvanced > 0 || lb.totalSpent > 0); // Only show lawyers with activity
    
    // Filter advances based on active tab
    const filteredAdvances = advances.filter(adv => {
      // Tab filter
      if (activeTab === 'fees' && !isFeeType(adv.advance_type)) return false;
      if (activeTab === 'expense_advances' && adv.advance_type !== 'client_expense_advance') return false;
      if (activeTab === 'lawyer_advances' && adv.advance_type !== 'lawyer_advance') return false;
      
      // Client filter (for non-lawyer advances)
      if (clientFilter && adv.advance_type !== 'lawyer_advance' && adv.client_id !== clientFilter) return false;
      
      // Lawyer filter (for lawyer advances)
      if (lawyerFilter && adv.advance_type === 'lawyer_advance' && adv.lawyer_id !== lawyerFilter) return false;
      
      return true;
    });
    
    // Get type label
    const getTypeLabel = (type) => {
      switch(type) {
        case 'client_retainer': return t[language].clientRetainer;
        case 'client_expense_advance': return t[language].clientExpenseAdvance;
        case 'lawyer_advance': return t[language].lawyerAdvance;
        case 'fee_payment_fixed': return t[language].feePaymentFixed;
        case 'fee_payment_consultation': return t[language].feePaymentConsultation;
        case 'fee_payment_success': return t[language].feePaymentSuccess;
        case 'fee_payment_milestone': return t[language].feePaymentMilestone;
        case 'fee_payment_other': return t[language].feePaymentOther;
        default: return type;
      }
    };
    
    const isFeePayment = (type) => type?.startsWith('fee_payment');
    
    return (
      <div className="space-y-4">
        {/* Header */}
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">{t[language].advances}</h2>
          <button onClick={() => setShowAdvanceForm(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
            <Plus className="w-5 h-5" /> {t[language].addAdvance}
          </button>
        </div>
        
        {/* Summary Cards */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-white rounded-lg shadow p-4 border-l-4 border-blue-500">
            <div className="text-sm text-gray-500">{t[language].totalFees}</div>
            <div className="text-xl font-bold text-blue-600">${totals.allFees.toFixed(2)}</div>
            <div className="text-xs text-gray-400 mt-1">
              Retainers: ${totals.retainers.toFixed(2)} | Other: ${totals.feePayments.toFixed(2)}
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-4 border-l-4 border-green-500">
            <div className="text-sm text-gray-500">{t[language].totalExpenseAdv}</div>
            <div className="text-xl font-bold text-green-600">${totals.expenseAdvances.toFixed(2)}</div>
          </div>
          <div className="bg-white rounded-lg shadow p-4 border-l-4 border-orange-500">
            <div className="text-sm text-gray-500">{t[language].lawyerAdvance}</div>
            <div className="text-xl font-bold text-orange-600">${totals.lawyerAdvances.toFixed(2)}</div>
          </div>
        </div>
        
        {/* Per-Lawyer Balance Cards - Only show on Lawyer Advance tab */}
        {activeTab === 'lawyer_advances' && lawyerBalances.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {lawyerBalances.map(lb => (
              <div 
                key={lb.lawyer_id} 
                className={`bg-white rounded-lg shadow p-4 border-l-4 ${
                  lb.netBalance < 0 ? 'border-red-500' : lb.netBalance > 0 ? 'border-green-500' : 'border-gray-300'
                }`}
              >
                <div className="font-medium text-gray-900 truncate">{lb.name}</div>
                <div className="mt-2 space-y-1 text-sm">
                  <div className="flex justify-between text-gray-500">
                    <span>Advanced:</span>
                    <span className="text-green-600">${lb.totalAdvanced.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-gray-500">
                    <span>Spent:</span>
                    <span className="text-orange-600">${lb.totalSpent.toFixed(2)}</span>
                  </div>
                  <div className={`flex justify-between font-semibold pt-1 border-t ${
                    lb.netBalance < 0 ? 'text-red-600' : lb.netBalance > 0 ? 'text-green-600' : 'text-gray-600'
                  }`}>
                    <span>Balance:</span>
                    <span>${lb.netBalance.toFixed(2)}</span>
                  </div>
                </div>
                <div className={`text-xs mt-2 ${lb.netBalance < 0 ? 'text-red-500' : 'text-gray-400'}`}>
                  {lb.netBalance < 0 ? 'Firm owes lawyer' : lb.netBalance > 0 ? 'Available balance' : 'Settled'}
                </div>
              </div>
            ))}
          </div>
        )}
        
        {/* Sub-tabs */}
        <div className="bg-white rounded-lg shadow">
          <div className="border-b">
            <div className="flex flex-wrap">
              {[
                { id: 'fees', label: t[language].feesTab, count: advances.filter(a => a.advance_type === 'client_retainer' || a.advance_type?.startsWith('fee_payment')).length },
                { id: 'expense_advances', label: t[language].expenseAdvancesTab, count: advances.filter(a => a.advance_type === 'client_expense_advance').length },
                { id: 'lawyer_advances', label: t[language].lawyerAdvance, count: advances.filter(a => a.advance_type === 'lawyer_advance').length },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    // Reset filters when switching tabs (per CODING_STANDARDS.md)
                    setClientFilter('');
                    setLawyerFilter('');
                  }}
                  className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600 bg-blue-50'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {tab.label}
                  <span className={`ml-2 px-2 py-0.5 text-xs rounded-full ${
                    activeTab === tab.id ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'
                  }`}>{tab.count}</span>
                </button>
              ))}
            </div>
          </div>
          
          {/* Context-aware Filter */}
          <div className="p-4 border-b bg-gray-50">
            <div className="flex gap-4 items-center">
              {activeTab === 'lawyer_advances' ? (
                <>
                  <label className="text-sm font-medium text-gray-700">{t[language].lawyer}:</label>
                  <select
                    value={lawyerFilter}
                    onChange={(e) => setLawyerFilter(e.target.value)}
                    className="px-3 py-1.5 border rounded-md text-sm"
                  >
                    <option value="">{t[language].allLawyers || 'All Lawyers'}</option>
                    {lawyers.map(l => (
                      <option key={l.lawyer_id} value={l.lawyer_id}>{l.full_name || l.name}</option>
                    ))}
                  </select>
                  {lawyerFilter && (
                    <button onClick={() => setLawyerFilter('')} className="text-sm text-blue-600 hover:underline">
                      Clear filter
                    </button>
                  )}
                </>
              ) : (
                <>
                  <label className="text-sm font-medium text-gray-700">{t[language].client}:</label>
                  <select
                    value={clientFilter}
                    onChange={(e) => setClientFilter(e.target.value)}
                    className="px-3 py-1.5 border rounded-md text-sm"
                  >
                    <option value="">{t[language].allClients || 'All Clients'}</option>
                    {clients.map(c => (
                      <option key={c.client_id} value={c.client_id}>{c.client_name}</option>
                    ))}
                  </select>
                  {clientFilter && (
                    <button onClick={() => setClientFilter('')} className="text-sm text-blue-600 hover:underline">
                      Clear filter
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
          
          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].dateReceived}</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].client} / {t[language].lawyer}</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].advanceType}</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].amount}</th>
                  {activeTab !== 'lawyer_advances' && (
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].balanceRemaining}</th>
                  )}
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].status}</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredAdvances.length === 0 ? (
                  <tr><td colSpan={activeTab === 'lawyer_advances' ? 6 : 7} className="px-6 py-8 text-center text-gray-500">{t[language].noData}</td></tr>
                ) : (
                  filteredAdvances.map(adv => {
                    const client = clients.find(c => c.client_id === adv.client_id);
                    const typeLabel = getTypeLabel(adv.advance_type);
                    const isFeePmt = isFeePayment(adv.advance_type);
                    const usedPercent = adv.amount > 0 ? ((adv.amount - adv.balance_remaining) / adv.amount * 100).toFixed(0) : 0;
                    const displayName = adv.advance_type === 'lawyer_advance' 
                      ? (adv.lawyer_name || 'N/A')
                      : (client?.client_name || 'N/A');
                    return (
                      <tr key={adv.advance_id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm">{formatDate(adv.date_received)}</td>
                        <td className="px-6 py-4 text-sm font-medium">
                          {displayName}
                          {adv.fee_description && (
                            <div className="text-xs text-gray-500">{adv.fee_description}</div>
                          )}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            isFeePmt ? 'bg-purple-100 text-purple-800' :
                            adv.advance_type === 'client_retainer' ? 'bg-blue-100 text-blue-800' :
                            adv.advance_type === 'client_expense_advance' ? 'bg-green-100 text-green-800' :
                            'bg-orange-100 text-orange-800'
                          }`}>{typeLabel}</span>
                        </td>
                        <td className="px-6 py-4 text-sm">{adv.currency} {parseFloat(adv.amount).toFixed(2)}</td>
                        {activeTab !== 'lawyer_advances' && (
                          <td className="px-6 py-4">
                            {isFeePmt ? (
                              <span className="text-gray-400">{t[language].noBalance}</span>
                            ) : (
                              <div className="flex items-center gap-2">
                                <span className={`font-medium ${parseFloat(adv.balance_remaining) < 0 ? 'text-red-600' : adv.balance_remaining < (adv.minimum_balance_alert || 0) ? 'text-orange-600' : 'text-green-600'}`}>
                                  {adv.currency} {parseFloat(adv.balance_remaining).toFixed(2)}
                                </span>
                                {parseFloat(adv.balance_remaining) >= 0 && (
                                  <div className="w-16 bg-gray-200 rounded-full h-2">
                                    <div className="bg-blue-600 h-2 rounded-full" style={{width: `${100 - usedPercent}%`}}></div>
                                  </div>
                                )}
                              </div>
                            )}
                          </td>
                        )}
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            adv.status === 'active' ? 'bg-green-100 text-green-800' :
                            adv.status === 'depleted' ? 'bg-red-100 text-red-800' :
                            'bg-gray-100 text-gray-800'}`}>
                            {isFeePmt ? 'Received' : (t[language][adv.status] || adv.status)}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <button onClick={() => { setEditingAdvance(adv); setShowAdvanceForm(true); }}
                            className="text-blue-600 hover:text-blue-900 mr-3">{t[language].edit}</button>
                          <button onClick={() => {
                            showConfirm(
                              'Delete Payment',
                              'Are you sure you want to delete this payment record?',
                              async () => {
                                await window.electronAPI.deleteAdvance(adv.advance_id);
                                await refreshAdvances();
                                showToast('Payment deleted');
                                hideConfirm();
                              }
                            );
                          }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  // DeadlineForm moved outside App





  // InvoiceForm moved outside App


  // ============================================
  // INVOICE VIEW MODAL COMPONENT
  // ============================================
  const InvoiceViewModal = () => {
    const [invoiceItems, setInvoiceItems] = useState([]);
    const [loading, setLoading] = useState(true);
    
    useEffect(() => {
      const loadItems = async () => {
        if (viewingInvoice) {
          setLoading(true);
          try {
            const items = await window.electronAPI.getInvoiceItems(viewingInvoice.invoice_id);
            setInvoiceItems(items || []);
          } catch (error) {
            console.error('Error loading invoice items:', error);
          }
          setLoading(false);
        }
      };
      loadItems();
    }, [viewingInvoice]);

    if (!viewingInvoice) return null;
    
    const client = clients.find(c => c.client_id === viewingInvoice.client_id);
    const matter = viewingInvoice.matter_id ? matters.find(m => m.matter_id === viewingInvoice.matter_id) : null;
    
    // Separate time entries and expenses
    const timeItems = invoiceItems.filter(item => item.item_type === 'time');
    const expenseItems = invoiceItems.filter(item => item.item_type === 'expense');
    const fixedFeeItems = invoiceItems.filter(item => item.item_type === 'fixed_fee');
    
    const timeTotal = timeItems.reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);
    const fixedTotal = fixedFeeItems.reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);
    const feesTotal = timeTotal + fixedTotal;
    const expenseTotal = expenseItems.reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);
    
    // Calculate retainer applied (stored in discount if it was applied)
    const retainerApplied = viewingInvoice.retainer_applied || 0;
    
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 print-invoice">
        <div className={`bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto ${isRTL ? 'rtl' : 'ltr'}`}>
          <div className="p-6">
            {/* Header */}
            <div className="flex justify-between items-start mb-6 invoice-header">
              <div>
                <h2 className="text-2xl font-bold">{viewingInvoice.invoice_number}</h2>
                <p className="text-gray-500">
                  {t[language].issueDate}: {formatDate(viewingInvoice.issue_date)}
                  {viewingInvoice.due_date && ` | ${t[language].dueDate}: ${formatDate(viewingInvoice.due_date)}`}
                </p>
              </div>
              <span className={`px-3 py-1 text-sm rounded-full ${
                viewingInvoice.status === 'paid' ? 'bg-green-100 text-green-800' :
                viewingInvoice.status === 'sent' ? 'bg-blue-100 text-blue-800' :
                viewingInvoice.status === 'overdue' ? 'bg-red-100 text-red-800' :
                'bg-gray-100 text-gray-800'
              }`}>{t[language][viewingInvoice.status] || viewingInvoice.status}</span>
            </div>
            
            {/* Client & Matter Info */}
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">{t[language].client}</p>
                  <p className="font-medium">{client?.client_name || 'N/A'}</p>
                </div>
                {matter && (
                  <div>
                    <p className="text-sm text-gray-500">{t[language].matter}</p>
                    <p className="font-medium">{matter.matter_name}</p>
                  </div>
                )}
              </div>
              {viewingInvoice.period_start && (
                <div className="mt-2">
                  <p className="text-sm text-gray-500">{t[language].billingPeriod}</p>
                  <p className="font-medium">{formatDate(viewingInvoice.period_start)} - {formatDate(viewingInvoice.period_end)}</p>
                </div>
              )}
            </div>
            
            {loading ? (
              <div className="text-center py-8">{t[language].loading}</div>
            ) : (
              <>
                {/* Professional Fees Section */}
                {(timeItems.length > 0 || fixedFeeItems.length > 0) && (
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-3 border-b pb-2">{t[language].professionalFees}</h3>
                    <table className="w-full text-sm">
                      <thead className="bg-gray-100">
                        <tr>
                          <th className="px-3 py-2 text-left">{t[language].date}</th>
                          <th className="px-3 py-2 text-left">{t[language].description}</th>
                          <th className="px-3 py-2 text-right">{t[language].hours}</th>
                          <th className="px-3 py-2 text-right">{t[language].rate}</th>
                          <th className="px-3 py-2 text-right">{t[language].amount}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {timeItems.map((item, idx) => (
                          <tr key={idx} className="border-b">
                            <td className="px-3 py-2">{formatDate(item.item_date)}</td>
                            <td className="px-3 py-2">{item.description}</td>
                            <td className="px-3 py-2 text-right">{parseFloat(item.quantity).toFixed(2)}</td>
                            <td className="px-3 py-2 text-right">{parseFloat(item.rate).toFixed(2)}</td>
                            <td className="px-3 py-2 text-right">{parseFloat(item.amount).toFixed(2)}</td>
                          </tr>
                        ))}
                        {fixedFeeItems.map((item, idx) => (
                          <tr key={`ff-${idx}`} className="border-b">
                            <td className="px-3 py-2">{formatDate(item.item_date)}</td>
                            <td className="px-3 py-2">{item.description}</td>
                            <td className="px-3 py-2 text-right">-</td>
                            <td className="px-3 py-2 text-right">{t[language].fixedFee}</td>
                            <td className="px-3 py-2 text-right">{parseFloat(item.amount).toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot className="bg-gray-50 font-medium">
                        <tr>
                          <td colSpan="4" className="px-3 py-2 text-right">{t[language].professionalFees} {t[language].subtotal}:</td>
                          <td className="px-3 py-2 text-right">{viewingInvoice.currency} {feesTotal.toFixed(2)}</td>
                        </tr>
                        {retainerApplied > 0 && (
                          <tr className="text-green-700">
                            <td colSpan="4" className="px-3 py-2 text-right">{t[language].lessRetainer}:</td>
                            <td className="px-3 py-2 text-right">({viewingInvoice.currency} {retainerApplied.toFixed(2)})</td>
                          </tr>
                        )}
                        <tr className="border-t-2 border-gray-300">
                          <td colSpan="4" className="px-3 py-2 text-right">{t[language].netFees}:</td>
                          <td className="px-3 py-2 text-right">{viewingInvoice.currency} {(feesTotal - retainerApplied).toFixed(2)}</td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                )}
                
                {/* Expenses/Disbursements Section */}
                {expenseItems.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-3 border-b pb-2">{t[language].disbursements}</h3>
                    <table className="w-full text-sm">
                      <thead className="bg-gray-100">
                        <tr>
                          <th className="px-3 py-2 text-left">{t[language].date}</th>
                          <th className="px-3 py-2 text-left">{t[language].description}</th>
                          <th className="px-3 py-2 text-right">{t[language].amount}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {expenseItems.map((item, idx) => (
                          <tr key={idx} className="border-b">
                            <td className="px-3 py-2">{formatDate(item.item_date)}</td>
                            <td className="px-3 py-2">{item.description}</td>
                            <td className="px-3 py-2 text-right">{parseFloat(item.amount).toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot className="bg-gray-50 font-medium">
                        <tr>
                          <td colSpan="2" className="px-3 py-2 text-right">{t[language].disbursements} {t[language].total}:</td>
                          <td className="px-3 py-2 text-right">{viewingInvoice.currency} {expenseTotal.toFixed(2)}</td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                )}
                
                {/* Invoice Summary */}
                <div className="bg-gray-100 rounded-lg p-4">
                  <div className="flex justify-between items-center text-lg">
                    <span>{t[language].subtotal}:</span>
                    <span>{viewingInvoice.currency} {parseFloat(viewingInvoice.subtotal).toFixed(2)}</span>
                  </div>
                  {viewingInvoice.discount_amount > 0 && (
                    <div className="flex justify-between items-center text-green-700">
                      <span>{t[language].discount} ({viewingInvoice.discount_type === 'percentage' ? `${viewingInvoice.discount_value}%` : t[language].fixedFee}):</span>
                      <span>-{viewingInvoice.currency} {parseFloat(viewingInvoice.discount_amount).toFixed(2)}</span>
                    </div>
                  )}
                  {viewingInvoice.vat_amount > 0 && (
                    <div className="flex justify-between items-center">
                      <span>{t[language].vat} ({viewingInvoice.vat_rate}%):</span>
                      <span>{viewingInvoice.currency} {parseFloat(viewingInvoice.vat_amount).toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center text-xl font-bold border-t-2 border-gray-300 mt-2 pt-2">
                    <span>{t[language].total}:</span>
                    <span>{viewingInvoice.currency} {parseFloat(viewingInvoice.total).toFixed(2)}</span>
                  </div>
                </div>
                
                {/* Notes */}
                {viewingInvoice.notes_to_client && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-gray-600">{t[language].notes}:</p>
                    <p className="mt-1">{viewingInvoice.notes_to_client}</p>
                  </div>
                )}
              </>
            )}
            
            {/* Actions */}
            <div className="flex justify-end gap-3 mt-6 pt-4 border-t no-print">
              <button onClick={() => window.print()}
                className="px-4 py-2 border rounded-md hover:bg-gray-50 flex items-center gap-2">
                <Download className="w-4 h-4" />
                {t[language].print || 'Print'}
              </button>
              <button onClick={() => setViewingInvoice(null)}
                className="px-4 py-2 border rounded-md hover:bg-gray-50">
                {t[language].close}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };


  // ============================================
  // REPORTS MODULE COMPONENT
  // ============================================
  const ReportsModule = () => {
    const [selectedReport, setSelectedReport] = useState(null);
    const [reportData, setReportData] = useState([]);
    const [loading, setLoading] = useState(false);
    
    // Date filter state
    const today = new Date().toISOString().split('T')[0];
    const firstOfMonth = today.substring(0, 7) + '-01';
    const firstOfYear = today.substring(0, 4) + '-01-01';
    const [dateFrom, setDateFrom] = useState(firstOfMonth);
    const [dateTo, setDateTo] = useState(today);
    const [datePreset, setDatePreset] = useState('thisMonth');

    const reports = [
      { id: 'outstanding-receivables', label: t[language].outstandingReceivables || 'Outstanding Receivables', category: 'financial' },
      { id: 'revenue-by-client', label: t[language].revenueByClient || 'Revenue by Client', category: 'financial' },
      { id: 'revenue-by-matter', label: t[language].revenueByMatter || 'Revenue by Matter', category: 'financial' },
      { id: 'retainer-balances', label: t[language].retainerBalances || 'Retainer Balances', category: 'financial' },
      { id: 'time-by-lawyer', label: t[language].timeByLawyer || 'Time by Lawyer', category: 'time' },
      { id: 'time-by-client', label: t[language].timeByClient || 'Time by Client', category: 'time' },
      { id: 'unbilled-time', label: t[language].unbilledTime || 'Unbilled Time', category: 'time' },
      { id: 'active-matters', label: t[language].activeMatters || 'Active Matters', category: 'matters' },
      { id: 'upcoming-hearings', label: t[language].upcomingHearings || 'Upcoming Hearings', category: 'matters' },
      { id: 'pending-judgments', label: t[language].pendingJudgments || 'Pending Judgments', category: 'matters' },
      { id: 'tasks-overdue', label: t[language].overdueTasks || 'Overdue Tasks', category: 'tasks' },
      { id: 'expenses-by-category', label: t[language].expensesByCategory || 'Expenses by Category', category: 'expenses' },
    ];

    // Reports that support date filtering
    const dateFilterableReports = ['revenue-by-client', 'revenue-by-matter', 'time-by-lawyer', 'time-by-client', 'expenses-by-category'];

    const handlePresetChange = (preset) => {
      setDatePreset(preset);
      const now = new Date();
      switch (preset) {
        case 'thisMonth':
          setDateFrom(firstOfMonth);
          setDateTo(today);
          break;
        case 'lastMonth':
          const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
          const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);
          setDateFrom(lastMonth.toISOString().split('T')[0]);
          setDateTo(lastMonthEnd.toISOString().split('T')[0]);
          break;
        case 'thisQuarter':
          const qStart = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1);
          setDateFrom(qStart.toISOString().split('T')[0]);
          setDateTo(today);
          break;
        case 'thisYear':
          setDateFrom(firstOfYear);
          setDateTo(today);
          break;
        case 'allTime':
          setDateFrom('2020-01-01');
          setDateTo(today);
          break;
        default:
          break;
      }
    };

    const loadReport = async (reportId) => {
      setLoading(true);
      setSelectedReport(reportId);
      try {
        const filters = dateFilterableReports.includes(reportId) 
          ? { dateFrom, dateTo } 
          : {};
        const data = await window.electronAPI.generateReport(reportId, filters);
        setReportData(data || []);
      } catch (error) {
        console.error('Error loading report:', error);
        setReportData([]);
      } finally {
        setLoading(false);
      }
    };

    // Reload report when date filters change
    useEffect(() => {
      if (selectedReport && dateFilterableReports.includes(selectedReport)) {
        loadReport(selectedReport);
      }
    }, [dateFrom, dateTo]);

    const formatMinutes = (mins) => {
      if (!mins) return '0h';
      const hours = Math.floor(mins / 60);
      const minutes = mins % 60;
      return `${hours}h ${minutes}m`;
    };

    // Export handler
    const handleExport = async (format) => {
      if (!selectedReport || reportData.length === 0) return;
      
      const reportName = reports.find(r => r.id === selectedReport)?.label || 'Report';
      
      try {
        let result;
        if (format === 'excel') {
          result = await window.electronAPI.exportToExcel(reportData, reportName);
        } else if (format === 'csv') {
          result = await window.electronAPI.exportToCsv(reportData, reportName);
        } else if (format === 'pdf') {
          // Get column headers based on report type
          const columns = Object.keys(reportData[0] || {});
          result = await window.electronAPI.exportToPdf(reportData, reportName, columns);
        }
        
        if (result?.success) {
          // Optionally open the file
          const openFile = window.confirm(`Export successful!\n\nFile saved to:\n${result.filePath}\n\nWould you like to open it?`);
          if (openFile) {
            await window.electronAPI.openFile(result.filePath);
          }
        } else if (!result?.canceled) {
          alert('Export failed: ' + (result?.error || 'Unknown error'));
        }
      } catch (error) {
        console.error('Export error:', error);
        alert('Export failed: ' + error.message);
      }
    };

    const renderReportTable = () => {
      if (loading) return <div className="text-center py-8">{t[language].loading}</div>;
      if (!selectedReport) return <div className="text-center py-8 text-gray-500">Select a report to view</div>;
      if (reportData.length === 0) return <div className="text-center py-8 text-gray-500">{t[language].noData}</div>;

      // Render different tables based on report type
      switch (selectedReport) {
        case 'outstanding-receivables':
          return (
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Invoice #</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Due Date</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Days Overdue</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {reportData.map(row => (
                  <tr key={row.invoice_id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">{row.invoice_number}</td>
                    <td className="px-4 py-3">{row.client_name}</td>
                    <td className="px-4 py-3">{formatDate(row.due_date)}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${row.days_overdue > 30 ? 'bg-red-100 text-red-800' : row.days_overdue > 0 ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}`}>
                        {Math.max(0, Math.round(row.days_overdue))} days
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right font-medium">${row.total?.toFixed(2)}</td>
                  </tr>
                ))}
                <tr className="bg-gray-50 font-bold">
                  <td colSpan="4" className="px-4 py-3">Total Outstanding</td>
                  <td className="px-4 py-3 text-right">${reportData.reduce((sum, r) => sum + (r.total || 0), 0).toFixed(2)}</td>
                </tr>
              </tbody>
            </table>
          );

        case 'time-by-lawyer':
          return (
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lawyer</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Billable</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Non-Billable</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {reportData.map(row => (
                  <tr key={row.lawyer_id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">{row.lawyer_name || row.full_name}</td>
                    <td className="px-4 py-3 text-right text-green-600">{formatMinutes(row.billable_minutes)}</td>
                    <td className="px-4 py-3 text-right text-gray-500">{formatMinutes(row.non_billable_minutes)}</td>
                    <td className="px-4 py-3 text-right font-medium">{formatMinutes(row.total_minutes)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          );

        case 'revenue-by-client':
          return (
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Invoices Paid</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Retainers</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Fee Payments</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total Revenue</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {reportData.filter(r => r.total_revenue > 0).map(row => (
                  <tr key={row.client_id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium">{row.client_name}</td>
                    <td className="px-4 py-3 text-right">${(row.invoice_revenue || 0).toLocaleString()}</td>
                    <td className="px-4 py-3 text-right">${(row.retainer_revenue || 0).toLocaleString()}</td>
                    <td className="px-4 py-3 text-right">${(row.fee_payment_revenue || 0).toLocaleString()}</td>
                    <td className="px-4 py-3 text-right font-bold text-green-600">${(row.total_revenue || 0).toLocaleString()}</td>
                  </tr>
                ))}
                <tr className="bg-gray-100 font-bold">
                  <td className="px-4 py-3">Total</td>
                  <td className="px-4 py-3 text-right">${reportData.reduce((s, r) => s + (r.invoice_revenue || 0), 0).toLocaleString()}</td>
                  <td className="px-4 py-3 text-right">${reportData.reduce((s, r) => s + (r.retainer_revenue || 0), 0).toLocaleString()}</td>
                  <td className="px-4 py-3 text-right">${reportData.reduce((s, r) => s + (r.fee_payment_revenue || 0), 0).toLocaleString()}</td>
                  <td className="px-4 py-3 text-right text-green-600">${reportData.reduce((s, r) => s + (r.total_revenue || 0), 0).toLocaleString()}</td>
                </tr>
              </tbody>
            </table>
          );

        case 'revenue-by-matter':
          return (
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Matter</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Invoices</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Retainers</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Fee Payments</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {reportData.filter(r => r.total_revenue > 0).map(row => (
                  <tr key={row.matter_id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium">{row.matter_name}</td>
                    <td className="px-4 py-3 text-gray-600">{row.client_name}</td>
                    <td className="px-4 py-3 text-right">${(row.invoice_revenue || 0).toLocaleString()}</td>
                    <td className="px-4 py-3 text-right">${(row.retainer_revenue || 0).toLocaleString()}</td>
                    <td className="px-4 py-3 text-right">${(row.fee_payment_revenue || 0).toLocaleString()}</td>
                    <td className="px-4 py-3 text-right font-bold text-green-600">${(row.total_revenue || 0).toLocaleString()}</td>
                  </tr>
                ))}
                <tr className="bg-gray-100 font-bold">
                  <td className="px-4 py-3" colSpan="2">Total</td>
                  <td className="px-4 py-3 text-right">${reportData.reduce((s, r) => s + (r.invoice_revenue || 0), 0).toLocaleString()}</td>
                  <td className="px-4 py-3 text-right">${reportData.reduce((s, r) => s + (r.retainer_revenue || 0), 0).toLocaleString()}</td>
                  <td className="px-4 py-3 text-right">${reportData.reduce((s, r) => s + (r.fee_payment_revenue || 0), 0).toLocaleString()}</td>
                  <td className="px-4 py-3 text-right text-green-600">${reportData.reduce((s, r) => s + (r.total_revenue || 0), 0).toLocaleString()}</td>
                </tr>
              </tbody>
            </table>
          );

        case 'active-matters':
        case 'upcoming-hearings':
        case 'pending-judgments':
        case 'tasks-overdue':
          return (
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    {selectedReport === 'active-matters' ? 'Matter' : selectedReport === 'upcoming-hearings' ? 'Hearing' : selectedReport === 'pending-judgments' ? 'Judgment' : 'Task'}
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {reportData.map((row, idx) => (
                  <tr key={idx} className="hover:bg-gray-50">
                    <td className="px-4 py-3">{row.matter_name || row.title || row.judgment_summary?.substring(0, 50)}</td>
                    <td className="px-4 py-3">{row.client_name}</td>
                    <td className="px-4 py-3">{formatDate(row.hearing_date || row.expected_date || row.due_date || row.opening_date)}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          );

        default:
          return (
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  {Object.keys(reportData[0] || {}).slice(0, 5).map(key => (
                    <th key={key} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      {key.replace(/_/g, ' ')}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y">
                {reportData.map((row, idx) => (
                  <tr key={idx} className="hover:bg-gray-50">
                    {Object.values(row).slice(0, 5).map((val, vidx) => (
                      <td key={vidx} className="px-4 py-3 text-sm">
                        {typeof val === 'number' ? val.toLocaleString() : String(val || '--')}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          );
      }
    };

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">{t[language].reports || 'Reports'}</h2>
          <div className="flex gap-2">
            <button 
              onClick={() => setShowClientStatement(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              <FileText className="w-5 h-5" />
              {language === 'ar' ? 'كشف حساب مالي' : 'Financial Statement'}
            </button>
            <button 
              onClick={() => setShowCaseStatusReport(true)}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
            >
              <Briefcase className="w-5 h-5" />
              {language === 'ar' ? 'تقرير حالة القضايا' : 'Case Status Report'}
            </button>
            <button 
              onClick={() => setShowClient360Report(true)}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700"
            >
              <PieChart className="w-5 h-5" />
              {language === 'ar' ? 'تقرير 360° للعميل' : 'Client 360° Report'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Report Selection */}
          <div className="bg-white rounded-lg shadow p-4">
            <h3 className="font-medium mb-4">{t[language].selectReport || 'Select Report'}</h3>
            
            {/* Client Reports - Quick Access (v44.3) */}
            <div className="mb-4 space-y-2">
              <h4 className="text-xs font-medium text-gray-500 uppercase">{language === 'ar' ? 'تقارير للعملاء' : 'Client Reports'}</h4>
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-100">
                <button 
                  onClick={() => setShowClientStatement(true)}
                  className="w-full flex items-center gap-2 text-blue-700 hover:text-blue-800 font-medium text-sm"
                >
                  <DollarSign className="w-4 h-4" />
                  {language === 'ar' ? 'كشف حساب مالي' : 'Financial Statement'}
                </button>
                <p className="text-xs text-blue-600 mt-1">
                  {language === 'ar' ? 'الفواتير والمدفوعات والرصيد' : 'Invoices, payments & balance'}
                </p>
              </div>
              <div className="p-3 bg-indigo-50 rounded-lg border border-indigo-100">
                <button 
                  onClick={() => setShowCaseStatusReport(true)}
                  className="w-full flex items-center gap-2 text-indigo-700 hover:text-indigo-800 font-medium text-sm"
                >
                  <Briefcase className="w-4 h-4" />
                  {language === 'ar' ? 'تقرير حالة القضايا' : 'Case Status Report'}
                </button>
                <p className="text-xs text-indigo-600 mt-1">
                  {language === 'ar' ? 'القضايا والجلسات والأحكام' : 'Matters, hearings & judgments'}
                </p>
              </div>
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-100">
                <button 
                  onClick={() => setShowClient360Report(true)}
                  className="w-full flex items-center gap-2 text-emerald-700 hover:text-emerald-800 font-medium text-sm"
                >
                  <PieChart className="w-4 h-4" />
                  {language === 'ar' ? 'تقرير 360° للعميل' : 'Client 360° Report'}
                </button>
                <p className="text-xs text-emerald-600 mt-1">
                  {language === 'ar' ? 'تقرير شامل: مالي + قضايا + وقت + مصاريف' : 'Complete: financial + cases + time + expenses'}
                </p>
              </div>
            </div>
            
            <div className="mb-4">
              <h4 className="text-xs font-medium text-gray-500 uppercase mb-2">{t[language].financial || 'Financial'}</h4>
              {reports.filter(r => r.category === 'financial').map(report => (
                <button key={report.id} onClick={() => loadReport(report.id)}
                  className={`w-full text-left px-3 py-2 rounded text-sm mb-1 ${selectedReport === report.id ? 'bg-blue-100 text-blue-700' : 'hover:bg-gray-100'}`}>
                  {report.label}
                </button>
              ))}
            </div>

            <div className="mb-4">
              <h4 className="text-xs font-medium text-gray-500 uppercase mb-2">{t[language].time || 'Time'}</h4>
              {reports.filter(r => r.category === 'time').map(report => (
                <button key={report.id} onClick={() => loadReport(report.id)}
                  className={`w-full text-left px-3 py-2 rounded text-sm mb-1 ${selectedReport === report.id ? 'bg-blue-100 text-blue-700' : 'hover:bg-gray-100'}`}>
                  {report.label}
                </button>
              ))}
            </div>

            <div className="mb-4">
              <h4 className="text-xs font-medium text-gray-500 uppercase mb-2">{t[language].matters || 'Matters'}</h4>
              {reports.filter(r => r.category === 'matters').map(report => (
                <button key={report.id} onClick={() => loadReport(report.id)}
                  className={`w-full text-left px-3 py-2 rounded text-sm mb-1 ${selectedReport === report.id ? 'bg-blue-100 text-blue-700' : 'hover:bg-gray-100'}`}>
                  {report.label}
                </button>
              ))}
            </div>

            <div>
              <h4 className="text-xs font-medium text-gray-500 uppercase mb-2">{t[language].other || 'Other'}</h4>
              {reports.filter(r => r.category === 'tasks' || r.category === 'expenses').map(report => (
                <button key={report.id} onClick={() => loadReport(report.id)}
                  className={`w-full text-left px-3 py-2 rounded text-sm mb-1 ${selectedReport === report.id ? 'bg-blue-100 text-blue-700' : 'hover:bg-gray-100'}`}>
                  {report.label}
                </button>
              ))}
            </div>
          </div>

          {/* Report Results */}
          <div className="lg:col-span-3 bg-white rounded-lg shadow">
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="font-medium">
                {selectedReport ? reports.find(r => r.id === selectedReport)?.label : 'Report Results'}
              </h3>
              <div className="flex items-center gap-2">
                {reportData.length > 0 && (
                  <>
                    <span className="text-sm text-gray-500 mr-2">{reportData.length} records</span>
                    <button
                      onClick={() => handleExport('excel')}
                      className="flex items-center gap-1 px-3 py-1.5 bg-green-600 text-white text-sm rounded hover:bg-green-700"
                      title="Export to Excel"
                    >
                      <Download size={14} />
                      Excel
                    </button>
                    <button
                      onClick={() => handleExport('csv')}
                      className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
                      title="Export to CSV"
                    >
                      <Download size={14} />
                      CSV
                    </button>
                    <button
                      onClick={() => handleExport('pdf')}
                      className="flex items-center gap-1 px-3 py-1.5 bg-red-600 text-white text-sm rounded hover:bg-red-700"
                      title="Export to PDF"
                    >
                      <FileText size={14} />
                      PDF
                    </button>
                  </>
                )}
              </div>
            </div>
            
            {/* Date Filters - only show for applicable reports */}
            {selectedReport && dateFilterableReports.includes(selectedReport) && (
              <div className="p-4 bg-gray-50 border-b flex flex-wrap items-center gap-4">
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium text-gray-600">Period:</label>
                  <select
                    value={datePreset}
                    onChange={(e) => handlePresetChange(e.target.value)}
                    className="px-3 py-1.5 border rounded text-sm focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="thisMonth">This Month</option>
                    <option value="lastMonth">Last Month</option>
                    <option value="thisQuarter">This Quarter</option>
                    <option value="thisYear">This Year</option>
                    <option value="allTime">All Time</option>
                    <option value="custom">Custom</option>
                  </select>
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-sm text-gray-600">From:</label>
                  <input
                    type="date"
                    value={dateFrom}
                    onChange={(e) => { setDateFrom(e.target.value); setDatePreset('custom'); }}
                    className="px-2 py-1.5 border rounded text-sm focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-sm text-gray-600">To:</label>
                  <input
                    type="date"
                    value={dateTo}
                    onChange={(e) => { setDateTo(e.target.value); setDatePreset('custom'); }}
                    className="px-2 py-1.5 border rounded text-sm focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            )}
            
            <div className="overflow-x-auto">
              {renderReportTable()}
            </div>
          </div>
        </div>
      </div>
    );
  };

  // ============================================
  // SETTINGS MODULE COMPONENT
  // ============================================
  const SettingsModule = () => {
    // firmInfo state is at App level (needed for Invoices)
    const [firmSaving, setFirmSaving] = useState(false);

    const handleSaveFirmInfo = async () => {
      setFirmSaving(true);
      try {
        await window.electronAPI.saveFirmInfo(firmInfo);
        alert(t[language].saved || 'Saved successfully');
      } catch (error) {
        console.error('Error saving firm info:', error);
      } finally {
        setFirmSaving(false);
      }
    };

    const lookupTabs = [
      { id: 'lawyers', label: t[language].lawyers, addLabel: t[language].addLawyer },
      { id: 'courtTypes', label: t[language].courtTypes, addLabel: t[language].addCourtType },
      { id: 'regions', label: t[language].regions, addLabel: t[language].addRegion },
      { id: 'hearingPurposes', label: t[language].hearingPurposes, addLabel: t[language].addPurpose },
      { id: 'taskTypes', label: t[language].taskTypes, addLabel: t[language].addTaskType },
      { id: 'expenseCategories', label: t[language].expenseCategories, addLabel: t[language].addCategory },
    ];

    const getCurrentData = () => {
      switch (currentLookupType) {
        case 'lawyers': return lawyers;
        case 'courtTypes': return courtTypes;
        case 'regions': return regions;
        case 'hearingPurposes': return hearingPurposes;
        case 'taskTypes': return taskTypes;
        case 'expenseCategories': return expenseCategories;
        default: return [];
      }
    };

    const handleDelete = async (item) => {
      if (item.is_system === 1) {
        showToast(t[language].cannotDeleteSystem, 'error');
        return;
      }
      showConfirm(
        language === 'ar' ? 'حذف العنصر' : 'Delete Item',
        t[language].confirmDelete,
        async () => {
          try {
            await window.electronAPI.deleteLookupItem(currentLookupType, item);
            await refreshLookups();
            showToast(language === 'ar' ? 'تم حذف العنصر' : 'Item deleted');
            hideConfirm();
          } catch (error) {
            console.error('Error deleting item:', error);
            showToast(language === 'ar' ? 'خطأ في الحذف' : 'Error deleting item', 'error');
          }
        }
      );
    };

    const handleEdit = (item) => {
      setEditingLookup(item);
      setShowLookupForm(true);
    };

    const currentTab = lookupTabs.find(tab => tab.id === currentLookupType);
    const data = getCurrentData();

    return (
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">{t[language].settings}</h2>
        
        {/* Main Settings Tabs */}
        <div className="flex gap-4 border-b">
          <button onClick={() => setSettingsTab('firmInfo')}
            className={`px-4 py-2 font-medium border-b-2 -mb-px ${settingsTab === 'firmInfo' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
            {t[language].firmInfo || 'Firm Information'}
          </button>
          <button onClick={() => setSettingsTab('lookups')}
            className={`px-4 py-2 font-medium border-b-2 -mb-px ${settingsTab === 'lookups' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
            {t[language].lookups || 'Lookups & Lists'}
          </button>
          <button onClick={() => setSettingsTab('backup')}
            className={`px-4 py-2 font-medium border-b-2 -mb-px ${settingsTab === 'backup' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
            {t[language].backupRestore || 'Backup & Restore'}
          </button>
        </div>

        {/* Firm Info Tab */}
        {settingsTab === 'firmInfo' && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">{t[language].firmInfo || 'Firm Information'}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].firmName || 'Firm Name'}</label>
                <input type="text" value={firmInfo.firm_name}
                  onChange={(e) => setFirmInfo({...firmInfo, firm_name: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].firmNameArabic || 'Firm Name (Arabic)'}</label>
                <input type="text" dir="rtl" value={firmInfo.firm_name_arabic}
                  onChange={(e) => setFirmInfo({...firmInfo, firm_name_arabic: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-1">{t[language].address || 'Address'}</label>
                <textarea value={firmInfo.firm_address} rows="2"
                  onChange={(e) => setFirmInfo({...firmInfo, firm_address: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].phone || 'Phone'}</label>
                <input type="tel" value={firmInfo.firm_phone}
                  onChange={(e) => setFirmInfo({...firmInfo, firm_phone: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].email || 'Email'}</label>
                <input type="email" value={firmInfo.firm_email}
                  onChange={(e) => setFirmInfo({...firmInfo, firm_email: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].website || 'Website'}</label>
                <input type="url" value={firmInfo.firm_website}
                  onChange={(e) => setFirmInfo({...firmInfo, firm_website: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].vatNumber || 'VAT Number'}</label>
                <input type="text" value={firmInfo.firm_vat_number}
                  onChange={(e) => setFirmInfo({...firmInfo, firm_vat_number: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].defaultCurrency || 'Default Currency'}</label>
                <select value={firmInfo.default_currency}
                  onChange={(e) => setFirmInfo({...firmInfo, default_currency: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md">
                  <option value="USD">USD</option>
                  <option value="EUR">EUR</option>
                  <option value="LBP">LBP</option>
                  <option value="SAR">SAR</option>
                  <option value="AED">AED</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].defaultVatRate || 'Default VAT Rate (%)'}</label>
                <input type="number" step="0.01" value={firmInfo.default_vat_rate}
                  onChange={(e) => setFirmInfo({...firmInfo, default_vat_rate: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md" />
              </div>
            </div>
            <div className="mt-6 flex justify-end">
              <button onClick={handleSaveFirmInfo} disabled={firmSaving}
                className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50">
                {firmSaving ? (t[language].saving || 'Saving...') : (t[language].save || 'Save')}
              </button>
            </div>
          </div>
        )}

        {/* Lookups Tab */}
        {settingsTab === 'lookups' && (
        <div className="bg-white rounded-lg shadow">
          <div className="border-b">
            <nav className="flex flex-wrap gap-1 p-2">
              {lookupTabs.map(tab => (
                <button key={tab.id}
                  onClick={() => setCurrentLookupType(tab.id)}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    currentLookupType === tab.id 
                      ? 'bg-blue-600 text-white' 
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}>
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>
          
          {/* Tab Content */}
          <div className="p-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">{currentTab?.label}</h3>
              <button onClick={() => { setEditingLookup(null); setShowLookupForm(true); }}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                <Plus className="w-4 h-4" /> {currentTab?.addLabel}
              </button>
            </div>

            {/* Data Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].nameEn}</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].nameAr}</th>
                    {currentLookupType === 'lawyers' && (
                      <>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].initials}</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].hourlyRate}</th>
                      </>
                    )}
                    {currentLookupType === 'taskTypes' && (
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].icon}</th>
                    )}
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].status}</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {data.length === 0 ? (
                    <tr><td colSpan="6" className="px-4 py-8 text-center text-gray-500">{t[language].noData}</td></tr>
                  ) : (
                    data.map((item, index) => {
                      const idField = currentLookupType === 'lawyers' ? 'lawyer_id' :
                                     currentLookupType === 'courtTypes' ? 'court_type_id' :
                                     currentLookupType === 'regions' ? 'region_id' :
                                     currentLookupType === 'hearingPurposes' ? 'purpose_id' :
                                     currentLookupType === 'taskTypes' ? 'task_type_id' :
                                     'category_id';
                      return (
                        <tr key={item[idField] || index} className="hover:bg-gray-50">
                          <td className="px-4 py-3 text-sm">{item.name_en || item.full_name}</td>
                          <td className="px-4 py-3 text-sm">{item.name_ar || item.full_name_arabic || '--'}</td>
                          {currentLookupType === 'lawyers' && (
                            <>
                              <td className="px-4 py-3 text-sm">{item.initials || '--'}</td>
                              <td className="px-4 py-3 text-sm">${item.hourly_rate || 0}</td>
                            </>
                          )}
                          {currentLookupType === 'taskTypes' && (
                            <td className="px-4 py-3 text-sm">--</td>
                          )}
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 text-xs rounded-full ${
                              item.is_system === 1 ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                            }`}>
                              {item.is_system === 1 ? t[language].systemDefault : t[language].userDefined}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex gap-2">
                              <button onClick={() => handleEdit(item)}
                                className="p-1 text-blue-600 hover:bg-blue-50 rounded">
                                <Edit3 className="w-4 h-4" />
                              </button>
                              {item.is_system !== 1 && (
                                <button onClick={() => handleDelete(item)}
                                  className="p-1 text-red-600 hover:bg-red-50 rounded">
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        )}

        {/* Backup & Restore Tab */}
        {settingsTab === 'backup' && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-6">{t[language].backupRestore || 'Backup & Restore'}</h3>
            
            <div className="space-y-6">
              {/* Backup Section */}
              <div className="border rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">{t[language].backup || 'Backup Database'}</h4>
                <p className="text-sm text-gray-600 mb-4">
                  Create a backup of all your data. You can restore from this backup later.
                </p>
                <button
                  onClick={async () => {
                    try {
                      const result = await window.electronAPI.backupDatabase();
                      if (result?.success) {
                        alert(`Backup saved successfully to:\n${result.filePath}`);
                      } else if (!result?.canceled) {
                        alert('Backup failed: ' + (result?.error || 'Unknown error'));
                      }
                    } catch (error) {
                      alert('Backup failed: ' + error.message);
                    }
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  <Download size={18} />
                  {t[language].createBackup || 'Create Backup'}
                </button>
              </div>

              {/* Restore Section */}
              <div className="border rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">{t[language].restore || 'Restore Database'}</h4>
                <p className="text-sm text-gray-600 mb-2">
                  Restore your data from a previous backup file.
                </p>
                <p className="text-sm text-red-600 mb-4">
                  âš ï¸ Warning: This will replace ALL current data with the backup data.
                </p>
                <button
                  onClick={async () => {
                    try {
                      const result = await window.electronAPI.restoreDatabase();
                      if (result?.success) {
                        alert(result.message || 'Restore successful. Please restart the application.');
                      } else if (!result?.canceled) {
                        alert('Restore failed: ' + (result?.error || 'Unknown error'));
                      }
                    } catch (error) {
                      alert('Restore failed: ' + error.message);
                    }
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700"
                >
                  <Upload size={18} />
                  {t[language].restoreBackup || 'Restore from Backup'}
                </button>
              </div>

              {/* Export All Data Section */}
              <div className="border rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">{t[language].exportAll || 'Export All Data'}</h4>
                <p className="text-sm text-gray-600 mb-4">
                  Export all your data to an Excel file with multiple sheets (Clients, Matters, Hearings, etc.).
                </p>
                <button
                  onClick={async () => {
                    try {
                      const result = await window.electronAPI.exportAllData();
                      if (result?.success) {
                        const openFile = window.confirm(`Export successful!\n\nFile saved to:\n${result.filePath}\n\nWould you like to open it?`);
                        if (openFile) {
                          await window.electronAPI.openFile(result.filePath);
                        }
                      } else if (!result?.canceled) {
                        alert('Export failed: ' + (result?.error || 'Unknown error'));
                      }
                    } catch (error) {
                      alert('Export failed: ' + error.message);
                    }
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                >
                  <FileText size={18} />
                  {t[language].exportToExcel || 'Export to Excel'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  // LookupForm moved outside App


  // ============================================
  // TIME TRACKING TIMER WIDGET
  // ============================================
  const TimerWidget = () => {
    // Local state for narrative to prevent focus loss while typing
    const [localNarrative, setLocalNarrative] = useState(timerNarrative);
    
    // Sync local narrative when parent changes (e.g., on load from localStorage)
    useEffect(() => {
      setLocalNarrative(timerNarrative);
    }, [timerNarrative]);
    
    // Format seconds as HH:MM:SS
    const formatTime = (totalSeconds) => {
      const hrs = Math.floor(totalSeconds / 3600);
      const mins = Math.floor((totalSeconds % 3600) / 60);
      const secs = totalSeconds % 60;
      return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    // Get filtered matters for selected client
    const filteredMatters = timerClientId 
      ? matters.filter(m => m.client_id === timerClientId)
      : [];

    // Track if currently saving to prevent double-clicks
    const [isSaving, setIsSaving] = useState(false);

    // Start timer
    const handleStart = (e) => {
      e.stopPropagation();
      setTimerRunning(true);
      saveTimerState(true, timerSeconds, Date.now() - (timerSeconds * 1000));
    };

    // Pause timer
    const handlePause = (e) => {
      e.stopPropagation();
      setTimerRunning(false);
      saveTimerState(false, timerSeconds);
    };

    // Discard timer
    const handleDiscard = (e) => {
      e.stopPropagation();
      if (timerSeconds > 0) {
        showConfirm(
          language === 'ar' ? 'تجاهل الوقت' : 'Discard Time',
          t[language].confirmDiscardTimer,
          () => {
            setTimerRunning(false);
            setTimerSeconds(0);
            setTimerClientId('');
            setTimerMatterId('');
            setTimerNarrative('');
            setLocalNarrative('');
            localStorage.removeItem('qanuni_timer');
            hideConfirm();
          }
        );
      } else {
        setTimerExpanded(false);
      }
    };

    // Actually save the timesheet
    const doSave = async () => {
      if (isSaving) return;
      setIsSaving(true);
      
      try {
        const lawyer = lawyers.find(l => l.lawyer_id == timerLawyerId);
        const minutes = Math.ceil(timerSeconds / 60);
        
        const timesheetData = {
          lawyer_id: timerLawyerId || lawyers[0]?.lawyer_id || '',
          client_id: timerClientId,
          matter_id: timerMatterId,
          date: new Date().toISOString().split('T')[0],
          minutes: minutes,
          narrative: localNarrative || '',
          billable: true,
          rate_per_hour: lawyer?.hourly_rate || 0
        };

        await window.electronAPI.addTimesheet(timesheetData);
        await refreshTimesheets();
        
        // Reset timer
        setTimerRunning(false);
        setTimerSeconds(0);
        setTimerClientId('');
        setTimerMatterId('');
        setTimerNarrative('');
        setLocalNarrative('');
        setTimerExpanded(false);
        localStorage.removeItem('qanuni_timer');
        
        showToast(t[language].timerSaved);
      } catch (error) {
        console.error('Error saving timesheet:', error);
        showToast(language === 'ar' ? 'خطأ في حفظ سجل الوقت' : 'Error saving time entry', 'error');
      } finally {
        setIsSaving(false);
      }
    };

    // Save to timesheet with narrative check
    const handleSave = (e) => {
      e.stopPropagation();
      
      if (!timerMatterId) {
        showToast(t[language].selectMatterForTimer, 'error');
        return;
      }
      if (timerSeconds < 1) {
        showToast(language === 'ar' ? 'لم يتم تسجيل وقت' : 'No time recorded', 'error');
        return;
      }
      
      // Check if narrative is empty and prompt user
      if (!localNarrative || !localNarrative.trim()) {
        showConfirm(
          language === 'ar' ? 'الوصف فارغ' : 'No Description',
          language === 'ar' 
            ? 'لم تكتب وصف للعمل. هل تريد الحفظ بدون وصف؟' 
            : 'You haven\'t written a work description. Save without description?',
          () => {
            hideConfirm();
            doSave();
          }
        );
        return;
      }
      
      doSave();
    };

    // Update localStorage when dropdown fields change (not narrative - that would lag)
    useEffect(() => {
      if (timerClientId || timerMatterId || timerLawyerId) {
        const timerState = {
          clientId: timerClientId,
          matterId: timerMatterId,
          narrative: localNarrative,
          lawyerId: timerLawyerId,
          running: timerRunning,
          startTime: timerRunning ? Date.now() - (timerSeconds * 1000) : null,
          pausedSeconds: timerRunning ? 0 : timerSeconds
        };
        localStorage.setItem('qanuni_timer', JSON.stringify(timerState));
      }
    }, [timerClientId, timerMatterId, timerLawyerId, timerRunning]);

    // Save narrative to localStorage and parent state on blur (not on every keystroke)
    const handleNarrativeBlur = () => {
      // Sync to parent state
      setTimerNarrative(localNarrative);
      // Save to localStorage
      const saved = localStorage.getItem('qanuni_timer');
      if (saved) {
        const timerState = JSON.parse(saved);
        timerState.narrative = localNarrative;
        localStorage.setItem('qanuni_timer', JSON.stringify(timerState));
      }
    };

    // Minimized view (floating button)
    if (!timerExpanded) {
      return (
        <button
          onClick={() => setTimerExpanded(true)}
          className={`fixed bottom-20 ${isRTL ? 'left-4' : 'right-4'} z-40 p-4 rounded-full shadow-lg transition-all hover:scale-105 ${
            timerRunning 
              ? 'bg-green-500 text-white animate-pulse' 
              : timerSeconds > 0 
                ? 'bg-yellow-500 text-white' 
                : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
          title={timerRunning ? `${t[language].timerRunning}: ${formatTime(timerSeconds)}` : t[language].timer}
        >
          <Timer className="w-6 h-6" />
          {(timerRunning || timerSeconds > 0) && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full px-2 py-0.5">
              {formatTime(timerSeconds)}
            </span>
          )}
        </button>
      );
    }

    // Expanded view
    return (
      <div className={`fixed bottom-20 ${isRTL ? 'left-4' : 'right-4'} z-40 w-80 bg-white rounded-lg shadow-2xl border ${isRTL ? 'rtl' : 'ltr'}`}>
        {/* Header */}
        <div className={`flex items-center justify-between p-3 border-b ${timerRunning ? 'bg-green-50' : 'bg-gray-50'}`}>
          <div className="flex items-center gap-2">
            <Timer className={`w-5 h-5 ${timerRunning ? 'text-green-600' : 'text-gray-600'}`} />
            <span className="font-semibold">{t[language].quickTimer}</span>
            {timerRunning && (
              <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded-full animate-pulse">
                {language === 'ar' ? 'يعمل' : 'RUNNING'}
              </span>
            )}
            {!timerRunning && timerSeconds > 0 && (
              <span className="text-xs bg-yellow-500 text-white px-2 py-0.5 rounded-full">
                {t[language].timerPaused}
              </span>
            )}
          </div>
          <button onClick={() => setTimerExpanded(false)} className="p-1 hover:bg-gray-200 rounded">
            <Minimize2 className="w-4 h-4" />
          </button>
        </div>

        {/* Timer Display */}
        <div className="p-4 text-center bg-gradient-to-b from-gray-50 to-white">
          <div className={`text-4xl font-mono font-bold ${timerRunning ? 'text-green-600' : 'text-gray-800'}`}>
            {formatTime(timerSeconds)}
          </div>
        </div>

        {/* Controls */}
        <div className="flex justify-center gap-2 p-3 border-t border-b bg-gray-50">
          {!timerRunning ? (
            <button
              onClick={handleStart}
              className="flex items-center gap-1 px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors"
            >
              <Play className="w-4 h-4" />
              {timerSeconds > 0 ? t[language].resumeTimer : t[language].startTimer}
            </button>
          ) : (
            <button
              onClick={handlePause}
              className="flex items-center gap-1 px-4 py-2 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 transition-colors"
            >
              <Pause className="w-4 h-4" />
              {t[language].pauseTimer}
            </button>
          )}
          {timerSeconds > 0 && (
            <button
              onClick={handleDiscard}
              className="flex items-center gap-1 px-3 py-2 bg-red-100 text-red-600 rounded-md hover:bg-red-200 transition-colors"
            >
              <Square className="w-4 h-4" />
              {t[language].discardTimer}
            </button>
          )}
        </div>

        {/* Form Fields */}
        <div className="p-3 space-y-3">
          {/* Lawyer */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">{t[language].lawyer}</label>
            <select
              value={timerLawyerId}
              onChange={(e) => setTimerLawyerId(e.target.value)}
              className="w-full px-2 py-1.5 text-sm border rounded-md"
            >
              <option value="">-- {t[language].select} --</option>
              {lawyers.map(lawyer => (
                <option key={lawyer.lawyer_id} value={lawyer.lawyer_id}>
                  {language === 'ar' && lawyer.full_name_arabic ? lawyer.full_name_arabic : lawyer.full_name}
                </option>
              ))}
            </select>
          </div>

          {/* Client */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">{t[language].client}</label>
            <select
              value={timerClientId}
              onChange={(e) => { setTimerClientId(e.target.value); setTimerMatterId(''); }}
              className="w-full px-2 py-1.5 text-sm border rounded-md"
            >
              <option value="">-- {t[language].selectClient} --</option>
              {clients.map(client => (
                <option key={client.client_id} value={client.client_id}>
                  {language === 'ar' && client.client_name_arabic ? client.client_name_arabic : client.client_name}
                </option>
              ))}
            </select>
          </div>

          {/* Matter */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">{t[language].matter} *</label>
            <select
              value={timerMatterId}
              onChange={(e) => setTimerMatterId(e.target.value)}
              disabled={!timerClientId}
              className={`w-full px-2 py-1.5 text-sm border rounded-md ${!timerClientId ? 'bg-gray-100' : ''}`}
            >
              <option value="">{timerClientId ? `-- ${t[language].selectMatter} --` : t[language].selectClientFirst}</option>
              {filteredMatters.map(matter => (
                <option key={matter.matter_id} value={matter.matter_id}>
                  {language === 'ar' && matter.matter_name_arabic ? matter.matter_name_arabic : matter.matter_name}
                </option>
              ))}
            </select>
          </div>

          {/* Narrative */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">{t[language].narrative}</label>
            {timerRunning ? (
              <div className="w-full px-2 py-3 text-sm border rounded-md bg-gray-50 text-gray-400 italic">
                {language === 'ar' 
                  ? 'أوقف المؤقت مؤقتاً لكتابة الوصف...' 
                  : 'Pause timer to write description...'}
              </div>
            ) : (
              <textarea
                value={localNarrative}
                onChange={(e) => setLocalNarrative(e.target.value)}
                onBlur={handleNarrativeBlur}
                placeholder={t[language].workDescription}
                rows="2"
                className="w-full px-2 py-1.5 text-sm border rounded-md resize-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            )}
          </div>
        </div>

        {/* Save Button */}
        <div className="p-3 border-t bg-gray-50">
          <button
            onClick={handleSave}
            disabled={!timerMatterId || timerSeconds < 1 || timerRunning || isSaving}
            className={`w-full flex items-center justify-center gap-2 px-4 py-2 rounded-md transition-colors ${
              timerMatterId && timerSeconds >= 1 && !timerRunning && !isSaving
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : 'bg-gray-200 text-gray-500 cursor-not-allowed'
            }`}
          >
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                {language === 'ar' ? 'جاري الحفظ...' : 'Saving...'}
              </>
            ) : timerRunning ? (
              <>
                <Save className="w-4 h-4" />
                {language === 'ar' ? 'أوقف المؤقت أولاً' : 'Pause timer first'}
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                {t[language].saveTime} ({timerSeconds < 60 
                  ? `${timerSeconds}s` 
                  : `${Math.ceil(timerSeconds / 60)} ${t[language].minutes}`})
              </>
            )}
          </button>
        </div>
      </div>
    );
  };

  // ============================================
  // LOADING SCREEN
  // ============================================
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <div className="text-xl text-gray-600">{t[language].loading}</div>
        </div>
      </div>
    );
  }

  // ============================================
  // MAIN RENDER
  // ============================================
  return (
    <div className={`min-h-screen bg-gray-100 ${isRTL ? 'rtl' : 'ltr'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-gray-100 rounded-md lg:hidden">
              {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <h1 className="text-2xl font-bold text-blue-600">{t[language].appName}</h1>
          </div>
          {/* Language toggle - disabled until Arabic locale file is added
          <button onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
            className="flex items-center gap-2 px-3 py-2 border rounded-md hover:bg-gray-50">
            <Globe className="w-5 h-5" />
            {language === 'en' ? 'عربي' : 'English'}
          </button>
          */}
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <div className={`${sidebarOpen ? 'block' : 'hidden'} lg:block w-64 bg-white shadow-sm min-h-screen`}>
          <nav className="p-4 space-y-1">
            {[
              { id: 'dashboard', icon: BarChart3, label: t[language].dashboard },
              { id: 'calendar', icon: CalendarDays, label: t[language].calendar },
              { id: 'clients', icon: Users, label: t[language].clients },
              { id: 'matters', icon: Briefcase, label: t[language].matters },
              { id: 'hearings', icon: Gavel, label: t[language].hearings },
              { id: 'judgments', icon: Scale, label: t[language].judgments },
              { id: 'deadlines', icon: AlertTriangle, label: t[language].deadlines },
              { id: 'companies', icon: Building2, label: t[language].companies },
              { id: 'tasks', icon: ClipboardList, label: t[language].tasks },
              { id: 'appointments', icon: Calendar, label: t[language].appointments },
              { id: 'timesheets', icon: Clock, label: t[language].timesheets },
              { id: 'expenses', icon: Receipt, label: t[language].expenses },
              { id: 'advances', icon: Wallet, label: t[language].advances },
              { id: 'invoices', icon: FileText, label: t[language].invoices },
              { id: 'reports', icon: PieChart, label: t[language].reports || 'Reports' },
              { id: 'settings', icon: Settings, label: t[language].settings },
            ].map(item => (
              <button key={item.id} onClick={() => handleModuleChange(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-md transition-colors ${
                  currentModule === item.id ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'
                }`}>
                <item.icon className="w-5 h-5" />
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          {currentModule === 'dashboard' && <Dashboard />}
          {currentModule === 'calendar' && <CalendarModule />}
          {currentModule === 'clients' && (
            <ClientsList
              clients={clients}
              clientSearch={clientSearch}
              setClientSearch={setClientSearch}
              language={language}
              t={t}
              setShowClientForm={setShowClientForm}
              setEditingClient={setEditingClient}
              showConfirm={showConfirm}
              showToast={showToast}
              hideConfirm={hideConfirm}
              refreshClients={refreshClients}
              electronAPI={window.electronAPI}
            />
          )}
          {currentModule === 'matters' && (
            <MattersList
              matters={matters}
              clients={clients}
              matterSearch={matterSearch}
              setMatterSearch={setMatterSearch}
              language={language}
              t={t}
              setShowMatterForm={setShowMatterForm}
              setEditingMatter={setEditingMatter}
              showConfirm={showConfirm}
              showToast={showToast}
              hideConfirm={hideConfirm}
              refreshMatters={refreshMatters}
              electronAPI={window.electronAPI}
            />
          )}
          {currentModule === 'hearings' && (
            <HearingsList
              hearings={hearings}
              matters={matters}
              clients={clients}
              hearingPurposes={hearingPurposes}
              language={language}
              t={t}
              formatDate={formatDate}
              setShowHearingForm={setShowHearingForm}
              setEditingHearing={setEditingHearing}
              showConfirm={showConfirm}
              showToast={showToast}
              hideConfirm={hideConfirm}
              refreshHearings={refreshHearings}
              electronAPI={window.electronAPI}
            />
          )}
          {currentModule === 'judgments' && <JudgmentsList />}
          {currentModule === 'deadlines' && <DeadlinesList
            deadlines={deadlines}
            deadlineFilters={deadlineFilters}
            setDeadlineFilters={setDeadlineFilters}
            deadlinePage={deadlinePage}
            setDeadlinePage={setDeadlinePage}
            deadlinePageSize={deadlinePageSize}
            setDeadlinePageSize={setDeadlinePageSize}
            clients={clients}
            matters={matters}
            judgments={judgments}
            tasks={tasks}
            language={language}
            t={t}
            onViewJudgment={(judgment) => {
              setEditingJudgment(judgment);
              setShowJudgmentForm(true);
              setCurrentModule('judgments');
            }}
            onViewTask={(task) => {
              setEditingTask(task);
              setShowTaskForm(true);
              setCurrentModule('tasks');
            }}
            onViewMatter={(matter) => {
              setEditingMatter(matter);
              setShowMatterForm(true);
              setCurrentModule('matters');
            }}
          />}
          {currentModule === 'companies' && (
            showEntityForm ? (
              <EntityForm
                language={language}
                isRTL={isRTL}
                editingEntity={editingEntity}
                setEditingEntity={setEditingEntity}
                setShowEntityForm={setShowEntityForm}
                showToast={showToast}
                refreshCorporateEntities={refreshCorporateEntities}
                entityTypes={entityTypes}
                t={t}
                activeTab={entityFormTab}
                setActiveTab={setEntityFormTab}
              />
            ) : (
              <EntitiesList
                language={language}
                isRTL={isRTL}
                corporateEntities={corporateEntities}
                setShowEntityForm={setShowEntityForm}
                setEditingEntity={setEditingEntity}
                showToast={showToast}
                refreshCorporateEntities={refreshCorporateEntities}
                t={t}
              />
            )
          )}
          {currentModule === 'tasks' && <TasksList
            tasks={tasks}
            taskStatusFilter={taskStatusFilter}
            setTaskStatusFilter={setTaskStatusFilter}
            taskPriorityFilter={taskPriorityFilter}
            setTaskPriorityFilter={setTaskPriorityFilter}
            taskFilters={taskFilters}
            setTaskFilters={setTaskFilters}
            taskPage={taskPage}
            setTaskPage={setTaskPage}
            taskPageSize={taskPageSize}
            setTaskPageSize={setTaskPageSize}
            clients={clients}
            matters={matters}
            lawyers={lawyers}
            taskTypes={taskTypes}
            language={language}
            t={t}
            setEditingTask={setEditingTask}
            setShowTaskForm={setShowTaskForm}
            showConfirm={showConfirm}
            showToast={showToast}
            hideConfirm={hideConfirm}
            refreshTasks={refreshTasks}
          />}
          {currentModule === 'appointments' && <AppointmentsList />}
          {currentModule === 'timesheets' && <TimesheetsList
            timesheets={timesheets}
            timesheetFilters={timesheetFilters}
            setTimesheetFilters={setTimesheetFilters}
            timesheetPage={timesheetPage}
            setTimesheetPage={setTimesheetPage}
            timesheetPageSize={timesheetPageSize}
            setTimesheetPageSize={setTimesheetPageSize}
            clients={clients}
            matters={matters}
            lawyers={lawyers}
            language={language}
            t={t}
            setEditingTimesheet={setEditingTimesheet}
            setShowTimesheetForm={setShowTimesheetForm}
            showConfirm={showConfirm}
            showToast={showToast}
            hideConfirm={hideConfirm}
            refreshTimesheets={refreshTimesheets}
          />}
          {currentModule === 'expenses' && <ExpensesList
            expenses={expenses}
            expenseFilters={expenseFilters}
            setExpenseFilters={setExpenseFilters}
            expensePage={expensePage}
            setExpensePage={setExpensePage}
            expensePageSize={expensePageSize}
            setExpensePageSize={setExpensePageSize}
            clients={clients}
            matters={matters}
            lawyers={lawyers}
            expenseCategories={expenseCategories}
            language={language}
            t={t}
            setEditingExpense={setEditingExpense}
            setShowExpenseForm={setShowExpenseForm}
            showConfirm={showConfirm}
            showToast={showToast}
            hideConfirm={hideConfirm}
            refreshExpenses={refreshExpenses}
          />}
          {currentModule === 'advances' && <AdvancesList />}
          {currentModule === 'invoices' && <InvoicesList
            invoices={invoices}
            invoiceFilters={invoiceFilters}
            setInvoiceFilters={setInvoiceFilters}
            invoicePage={invoicePage}
            setInvoicePage={setInvoicePage}
            invoicePageSize={invoicePageSize}
            setInvoicePageSize={setInvoicePageSize}
            clients={clients}
            matters={matters}
            language={language}
            t={t}
            setEditingInvoice={setEditingInvoice}
            setShowInvoiceForm={setShowInvoiceForm}
            setViewingInvoice={setViewingInvoice}
            showConfirm={showConfirm}
            showToast={showToast}
            hideConfirm={hideConfirm}
            refreshInvoices={refreshInvoices}
          />}
          {currentModule === 'reports' && <ReportsModule />}
          {currentModule === 'settings' && <SettingsModule />}
        </div>
      </div>

      {/* Modals */}
      {showClientForm && <ClientForm
          language={language}
          isRTL={isRTL}
          editingClient={editingClient}
          setEditingClient={setEditingClient}
          setShowClientForm={setShowClientForm}
          clientFormData={clientFormData}
          setClientFormData={setClientFormData}
          showToast={showToast}
          markFormDirty={markFormDirty}
          clearFormDirty={clearFormDirty}
          refreshClients={refreshClients}
          refreshCorporateEntities={refreshCorporateEntities}
          entityTypes={entityTypes}
          t={t}
        />}
      {showMatterForm && <MatterForm
          language={language}
          isRTL={isRTL}
          editingMatter={editingMatter}
          setEditingMatter={setEditingMatter}
          setShowMatterForm={setShowMatterForm}
          matterFormData={matterFormData}
          setMatterFormData={setMatterFormData}
          showToast={showToast}
          markFormDirty={markFormDirty}
          clearFormDirty={clearFormDirty}
          refreshMatters={refreshMatters}
          refreshClients={refreshClients}
          clients={clients}
          courtTypes={courtTypes}
          regions={regions}
          lawyers={lawyers}
          t={t}
        />}
      {showHearingForm && <HearingForm
          language={language}
          isRTL={isRTL}
          editingHearing={editingHearing}
          setEditingHearing={setEditingHearing}
          setShowHearingForm={setShowHearingForm}
          hearingFormData={hearingFormData}
          setHearingFormData={setHearingFormData}
          showToast={showToast}
          markFormDirty={markFormDirty}
          clearFormDirty={clearFormDirty}
          refreshHearings={refreshHearings}
          refreshJudgments={refreshJudgments}
          clients={clients}
          matters={matters}
          courtTypes={courtTypes}
          regions={regions}
          hearingPurposes={hearingPurposes}
          lawyers={lawyers}
          judgments={judgments}
          selectedMatter={selectedMatter}
          t={t}
          electronAPI={window.electronAPI}
        />}
      {showTaskForm && <TaskForm
          language={language}
          isRTL={isRTL}
          editingTask={editingTask}
          setEditingTask={setEditingTask}
          setShowTaskForm={setShowTaskForm}
          taskFormData={taskFormData}
          setTaskFormData={setTaskFormData}
          showToast={showToast}
          markFormDirty={markFormDirty}
          clearFormDirty={clearFormDirty}
          refreshTasks={refreshTasks}
          clients={clients}
          matters={matters}
          taskTypes={taskTypes}
          lawyers={lawyers}
          t={t}
        />}
      {showTimesheetForm && <TimesheetForm
          language={language}
          isRTL={isRTL}
          editingTimesheet={editingTimesheet}
          setEditingTimesheet={setEditingTimesheet}
          setShowTimesheetForm={setShowTimesheetForm}
          timesheetFormData={timesheetFormData}
          setTimesheetFormData={setTimesheetFormData}
          showToast={showToast}
          markFormDirty={markFormDirty}
          clearFormDirty={clearFormDirty}
          refreshTimesheets={refreshTimesheets}
          clients={clients}
          matters={matters}
          lawyers={lawyers}
          t={t}
        />}
      {showJudgmentForm && <JudgmentForm
          language={language}
          isRTL={isRTL}
          editingJudgment={editingJudgment}
          setEditingJudgment={setEditingJudgment}
          setShowJudgmentForm={setShowJudgmentForm}
          showToast={showToast}
          markFormDirty={markFormDirty}
          clearFormDirty={clearFormDirty}
          refreshJudgments={refreshJudgments}
          refreshDeadlines={refreshDeadlines}
          refreshHearings={refreshHearings}
          clients={clients}
          matters={matters}
          hearings={hearings}
          hearingPurposes={hearingPurposes}
          t={t}
        />}
      {showAppointmentForm && <AppointmentForm
          language={language}
          isRTL={isRTL}
          editingAppointment={editingAppointment}
          setEditingAppointment={setEditingAppointment}
          setShowAppointmentForm={setShowAppointmentForm}
          showToast={showToast}
          markFormDirty={markFormDirty}
          clearFormDirty={clearFormDirty}
          refreshAppointments={refreshAppointments}
          clients={clients}
          matters={matters}
          lawyers={lawyers}
          t={t}
        />}
      {showExpenseForm && <ExpenseForm
          language={language}
          isRTL={isRTL}
          editingExpense={editingExpense}
          setEditingExpense={setEditingExpense}
          setShowExpenseForm={setShowExpenseForm}
          showToast={showToast}
          markFormDirty={markFormDirty}
          clearFormDirty={clearFormDirty}
          refreshExpenses={refreshExpenses}
          refreshAdvances={refreshAdvances}
          clients={clients}
          matters={matters}
          expenseCategories={expenseCategories}
          lawyers={lawyers}
          advances={advances}
          t={t}
        />}
      {showAdvanceForm && <AdvanceForm
          language={language}
          isRTL={isRTL}
          editingAdvance={editingAdvance}
          setEditingAdvance={setEditingAdvance}
          setShowAdvanceForm={setShowAdvanceForm}
          showToast={showToast}
          markFormDirty={markFormDirty}
          clearFormDirty={clearFormDirty}
          refreshAdvances={refreshAdvances}
          clients={clients}
          matters={matters}
          lawyers={lawyers}
          t={t}
        />}
      {showDeadlineForm && <DeadlineForm
          language={language}
          isRTL={isRTL}
          editingDeadline={editingDeadline}
          setEditingDeadline={setEditingDeadline}
          setShowDeadlineForm={setShowDeadlineForm}
          deadlineFormData={deadlineFormData}
          setDeadlineFormData={setDeadlineFormData}
          showToast={showToast}
          markFormDirty={markFormDirty}
          clearFormDirty={clearFormDirty}
          refreshDeadlines={refreshDeadlines}
          clients={clients}
          matters={matters}
          judgments={judgments}
          t={t}
        />}
      {showInvoiceForm && <InvoiceForm
          language={language}
          isRTL={isRTL}
          editingInvoice={editingInvoice}
          setEditingInvoice={setEditingInvoice}
          setShowInvoiceForm={setShowInvoiceForm}
          showToast={showToast}
          markFormDirty={markFormDirty}
          clearFormDirty={clearFormDirty}
          refreshInvoices={refreshInvoices}
          refreshTimesheets={refreshTimesheets}
          refreshExpenses={refreshExpenses}
          refreshAdvances={refreshAdvances}
          clients={clients}
          matters={matters}
          timesheets={timesheets}
          expenses={expenses}
          advances={advances}
          firmInfo={firmInfo}
          t={t}
        />}
      {viewingInvoice && <InvoiceViewModal />}
      
      {/* Client Statement Modal (v44.3) */}
      {showClientStatement && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="flex justify-between items-center p-4 border-b bg-blue-600 text-white rounded-t-lg">
              <h2 className="text-lg font-semibold">
                {language === 'ar' ? 'كشف حساب العميل' : 'Client Statement'}
              </h2>
              <button onClick={() => { setShowClientStatement(false); setClientStatementData(null); }}
                className="p-1 hover:bg-blue-700 rounded">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            {/* Filters */}
            <div className="p-4 border-b bg-gray-50 space-y-3">
              {/* Client Selection Row */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {language === 'ar' ? 'العميل' : 'Client'} *
                  </label>
                  <select
                    value={clientStatementFilters.clientId}
                    onChange={(e) => {
                      const newClientId = e.target.value;
                      setClientStatementFilters(prev => ({ ...prev, clientId: newClientId }));
                      setClientStatementData(null);
                      // Auto-detect date range for this client
                      if (newClientId) {
                        const clientInvoices = invoices.filter(inv => String(inv.client_id) === String(newClientId));
                        const clientPayments = advances.filter(a => 
                          String(a.client_id) === String(newClientId) && 
                          ['client_retainer', 'fee_payment', 'fee_payment_cash', 'fee_payment_bank'].includes(a.advance_type)
                        );
                        
                        // Find earliest and latest dates
                        const allDates = [
                          ...clientInvoices.map(inv => inv.issue_date),
                          ...clientPayments.map(p => p.date_received)
                        ].filter(Boolean).sort();
                        
                        if (allDates.length > 0) {
                          // Set date range to cover all activity
                          const earliest = allDates[0];
                          const latest = allDates[allDates.length - 1] > new Date().toISOString().split('T')[0] 
                            ? new Date().toISOString().split('T')[0] 
                            : allDates[allDates.length - 1];
                          setClientStatementFilters(prev => ({
                            ...prev,
                            clientId: newClientId,
                            dateFrom: earliest,
                            dateTo: new Date().toISOString().split('T')[0]
                          }));
                        }
                      }
                    }}
                    className="w-full px-3 py-2 border rounded-md"
                  >
                    <option value="">{language === 'ar' ? '-- اختر العميل --' : '-- Select Client --'}</option>
                    {clients.map(c => (
                      <option key={c.client_id} value={c.client_id}>
                        {language === 'ar' && c.client_name_ar ? c.client_name_ar : c.client_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {language === 'ar' ? 'من تاريخ' : 'From Date'}
                  </label>
                  <input
                    type="date"
                    value={clientStatementFilters.dateFrom}
                    onChange={(e) => setClientStatementFilters(prev => ({ ...prev, dateFrom: e.target.value }))}
                    className="w-full px-3 py-2 border rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {language === 'ar' ? 'إلى تاريخ' : 'To Date'}
                  </label>
                  <input
                    type="date"
                    value={clientStatementFilters.dateTo}
                    onChange={(e) => setClientStatementFilters(prev => ({ ...prev, dateTo: e.target.value }))}
                    className="w-full px-3 py-2 border rounded-md"
                  />
                </div>
                <div className="flex items-end">
                  <button
                    onClick={() => generateClientStatement(
                      clientStatementFilters.clientId,
                      clientStatementFilters.dateFrom,
                      clientStatementFilters.dateTo
                    )}
                    disabled={!clientStatementFilters.clientId || clientStatementLoading}
                    className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    {clientStatementLoading 
                      ? (language === 'ar' ? 'جاري التحميل...' : 'Loading...') 
                      : (language === 'ar' ? 'إنشاء الكشف' : 'Generate Statement')}
                  </button>
                </div>
              </div>
              
              {/* Quick Period Presets */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-gray-500">{language === 'ar' ? 'فترات سريعة:' : 'Quick periods:'}</span>
                {[
                  { key: 'thisYear', label: language === 'ar' ? 'هذه السنة' : 'This Year', 
                    from: `${new Date().getFullYear()}-01-01`, to: new Date().toISOString().split('T')[0] },
                  { key: 'lastYear', label: language === 'ar' ? 'السنة الماضية' : 'Last Year', 
                    from: `${new Date().getFullYear() - 1}-01-01`, to: `${new Date().getFullYear() - 1}-12-31` },
                  { key: 'last6Months', label: language === 'ar' ? 'آخر 6 أشهر' : 'Last 6 Months', 
                    from: new Date(new Date().setMonth(new Date().getMonth() - 6)).toISOString().split('T')[0], 
                    to: new Date().toISOString().split('T')[0] },
                  { key: 'allTime', label: language === 'ar' ? 'كل الفترات' : 'All Time', 
                    from: '2020-01-01', to: new Date().toISOString().split('T')[0] }
                ].map(preset => (
                  <button
                    key={preset.key}
                    onClick={() => setClientStatementFilters(prev => ({ ...prev, dateFrom: preset.from, dateTo: preset.to }))}
                    className={`px-3 py-1 text-xs rounded-full border transition-colors ${
                      clientStatementFilters.dateFrom === preset.from && clientStatementFilters.dateTo === preset.to
                        ? 'bg-blue-100 border-blue-500 text-blue-700'
                        : 'bg-white border-gray-300 hover:border-blue-400 hover:bg-blue-50'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
              
              {/* Client Activity Summary (when client selected but not generated yet) */}
              {clientStatementFilters.clientId && !clientStatementData && (
                <div className="bg-blue-50 rounded-lg p-3 border border-blue-100">
                  {(() => {
                    const clientId = clientStatementFilters.clientId;
                    const clientInvoices = invoices.filter(inv => String(inv.client_id) === String(clientId));
                    const clientPayments = advances.filter(a => 
                      String(a.client_id) === String(clientId) && 
                      ['client_retainer', 'fee_payment', 'fee_payment_cash', 'fee_payment_bank'].includes(a.advance_type)
                    );
                    
                    const allDates = [
                      ...clientInvoices.map(inv => inv.issue_date),
                      ...clientPayments.map(p => p.date_received)
                    ].filter(Boolean).sort();
                    
                    const totalInvoiced = clientInvoices.reduce((sum, inv) => sum + (parseFloat(inv.total) || 0), 0);
                    const totalPaid = clientPayments.reduce((sum, p) => sum + (parseFloat(p.amount) || 0), 0);
                    
                    if (clientInvoices.length === 0 && clientPayments.length === 0) {
                      return (
                        <div className="text-sm text-blue-700">
                          <span className="font-medium">{language === 'ar' ? 'لا توجد بيانات' : 'No activity found'}</span>
                          <span className="text-blue-600 ml-2">
                            {language === 'ar' ? 'لا توجد فواتير أو مدفوعات لهذا العميل' : 'No invoices or payments for this client'}
                          </span>
                        </div>
                      );
                    }
                    
                    return (
                      <div className="flex flex-wrap gap-4 text-sm">
                        <div>
                          <span className="text-blue-600">{language === 'ar' ? 'الفواتير:' : 'Invoices:'}</span>
                          <span className="font-medium text-blue-800 ml-1">{clientInvoices.length}</span>
                          <span className="text-blue-600 ml-1">(${totalInvoiced.toFixed(2)})</span>
                        </div>
                        <div>
                          <span className="text-blue-600">{language === 'ar' ? 'المدفوعات:' : 'Payments:'}</span>
                          <span className="font-medium text-blue-800 ml-1">{clientPayments.length}</span>
                          <span className="text-blue-600 ml-1">(${totalPaid.toFixed(2)})</span>
                        </div>
                        {allDates.length > 0 && (
                          <>
                            <div>
                              <span className="text-blue-600">{language === 'ar' ? 'أول نشاط:' : 'First activity:'}</span>
                              <span className="font-medium text-blue-800 ml-1">
                                {new Date(allDates[0]).toLocaleDateString('en-GB')}
                              </span>
                            </div>
                            <div>
                              <span className="text-blue-600">{language === 'ar' ? 'آخر نشاط:' : 'Last activity:'}</span>
                              <span className="font-medium text-blue-800 ml-1">
                                {new Date(allDates[allDates.length - 1]).toLocaleDateString('en-GB')}
                              </span>
                            </div>
                          </>
                        )}
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
            
            {/* Content */}
            <div className="flex-1 overflow-auto p-4">
              {!clientStatementData ? (
                <div className="text-center py-12 text-gray-500">
                  {clientStatementFilters.clientId 
                    ? (language === 'ar' ? 'اضغط "إنشاء الكشف" لعرض البيانات' : 'Click "Generate Statement" to view data')
                    : (language === 'ar' ? 'اختر العميل أولاً' : 'Select a client first')}
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Client Info */}
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-800 mb-2">
                      {clientStatementData.client?.client_name}
                      {clientStatementData.client?.client_name_ar && ` / ${clientStatementData.client.client_name_ar}`}
                    </h3>
                    <div className="text-sm text-gray-600">
                      {clientStatementData.client?.email && <div>{clientStatementData.client.email}</div>}
                      {clientStatementData.client?.phone && <div>{clientStatementData.client.phone}</div>}
                    </div>
                  </div>
                  
                  {/* Summary Cards */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-blue-50 rounded-lg p-3 text-center">
                      <div className="text-xs text-blue-600 uppercase">{language === 'ar' ? 'رصيد افتتاحي' : 'Opening Balance'}</div>
                      <div className="text-lg font-bold text-blue-800">${clientStatementData.summary?.openingBalance?.toFixed(2) || '0.00'}</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3 text-center">
                      <div className="text-xs text-gray-600 uppercase">{language === 'ar' ? 'إجمالي الفواتير' : 'Total Invoiced'}</div>
                      <div className="text-lg font-bold text-gray-800">${clientStatementData.summary?.totalInvoiced?.toFixed(2) || '0.00'}</div>
                    </div>
                    <div className="bg-green-50 rounded-lg p-3 text-center">
                      <div className="text-xs text-green-600 uppercase">{language === 'ar' ? 'المدفوعات' : 'Payments'}</div>
                      <div className="text-lg font-bold text-green-800">${clientStatementData.summary?.totalPayments?.toFixed(2) || '0.00'}</div>
                    </div>
                    <div className="bg-red-50 rounded-lg p-3 text-center">
                      <div className="text-xs text-red-600 uppercase">{language === 'ar' ? 'الرصيد المستحق' : 'Balance Due'}</div>
                      <div className="text-lg font-bold text-red-800">${clientStatementData.summary?.closingBalance?.toFixed(2) || '0.00'}</div>
                    </div>
                  </div>
                  
                  {/* Invoices Table */}
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2">{language === 'ar' ? 'الفواتير' : 'Invoices'} ({clientStatementData.invoices?.length || 0})</h4>
                    {clientStatementData.invoices?.length > 0 ? (
                      <table className="w-full text-sm">
                        <thead className="bg-gray-100">
                          <tr>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'التاريخ' : 'Date'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'رقم الفاتورة' : 'Invoice #'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'القضية' : 'Matter'}</th>
                            <th className="px-3 py-2 text-right">{language === 'ar' ? 'المبلغ' : 'Amount'}</th>
                            <th className="px-3 py-2 text-center">{language === 'ar' ? 'الحالة' : 'Status'}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {clientStatementData.invoices.map(inv => (
                            <tr key={inv.invoice_id} className="hover:bg-gray-50">
                              <td className="px-3 py-2">{new Date(inv.issue_date).toLocaleDateString('en-GB')}</td>
                              <td className="px-3 py-2 font-medium">{inv.invoice_number}</td>
                              <td className="px-3 py-2">{inv.matter_name || '-'}</td>
                              <td className="px-3 py-2 text-right">{inv.currency} {parseFloat(inv.total).toFixed(2)}</td>
                              <td className="px-3 py-2 text-center">
                                <span className={`px-2 py-0.5 text-xs rounded-full ${
                                  inv.status === 'paid' ? 'bg-green-100 text-green-800' :
                                  inv.status === 'overdue' ? 'bg-red-100 text-red-800' :
                                  'bg-blue-100 text-blue-800'
                                }`}>
                                  {inv.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-4 text-gray-500 bg-gray-50 rounded">
                        {language === 'ar' ? 'لا توجد فواتير في هذه الفترة' : 'No invoices in this period'}
                      </div>
                    )}
                  </div>
                  
                  {/* Payments Table */}
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2">{language === 'ar' ? 'المدفوعات' : 'Payments'} ({clientStatementData.payments?.length || 0})</h4>
                    {clientStatementData.payments?.length > 0 ? (
                      <table className="w-full text-sm">
                        <thead className="bg-gray-100">
                          <tr>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'التاريخ' : 'Date'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'المرجع' : 'Reference'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'النوع' : 'Type'}</th>
                            <th className="px-3 py-2 text-right">{language === 'ar' ? 'المبلغ' : 'Amount'}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {clientStatementData.payments.map(p => (
                            <tr key={p.advance_id} className="hover:bg-gray-50">
                              <td className="px-3 py-2">{new Date(p.date_received).toLocaleDateString('en-GB')}</td>
                              <td className="px-3 py-2">{p.reference_number || '-'}</td>
                              <td className="px-3 py-2">{p.payment_type_label}</td>
                              <td className="px-3 py-2 text-right text-green-600">+${parseFloat(p.amount).toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-4 text-gray-500 bg-gray-50 rounded">
                        {language === 'ar' ? 'لا توجد مدفوعات في هذه الفترة' : 'No payments in this period'}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
            
            {/* Footer with Export Buttons */}
            <div className="flex justify-between items-center p-4 border-t bg-gray-50 rounded-b-lg">
              <button
                onClick={() => { setShowClientStatement(false); setClientStatementData(null); }}
                className="px-4 py-2 border rounded-md hover:bg-gray-100"
              >
                {language === 'ar' ? 'إغلاق' : 'Close'}
              </button>
              {clientStatementData && (
                <div className="flex gap-2">
                  <button
                    onClick={() => exportClientStatement('excel')}
                    className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center gap-2"
                  >
                    <FileSpreadsheet className="w-4 h-4" />
                    {language === 'ar' ? 'تصدير Excel' : 'Export Excel'}
                  </button>
                  <button
                    onClick={() => exportClientStatement('pdf')}
                    className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 flex items-center gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    {language === 'ar' ? 'تصدير PDF' : 'Export PDF'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      {/* Case Status Report Modal (v44.3) */}
      {showCaseStatusReport && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="flex justify-between items-center p-4 border-b bg-indigo-600 text-white rounded-t-lg">
              <h2 className="text-lg font-semibold">
                {language === 'ar' ? 'تقرير حالة القضايا' : 'Case Status Report'}
              </h2>
              <button onClick={() => { setShowCaseStatusReport(false); setCaseStatusData(null); setCaseStatusClientId(''); }}
                className="p-1 hover:bg-indigo-700 rounded">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            {/* Client Selection */}
            <div className="p-4 border-b bg-gray-50">
              <div className="flex gap-3 items-end">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {language === 'ar' ? 'العميل' : 'Client'} *
                  </label>
                  <select
                    value={caseStatusClientId}
                    onChange={(e) => { setCaseStatusClientId(e.target.value); setCaseStatusData(null); }}
                    className="w-full px-3 py-2 border rounded-md"
                  >
                    <option value="">{language === 'ar' ? '-- اختر العميل --' : '-- Select Client --'}</option>
                    {clients.map(c => (
                      <option key={c.client_id} value={c.client_id}>
                        {language === 'ar' && c.client_name_ar ? c.client_name_ar : c.client_name}
                      </option>
                    ))}
                  </select>
                </div>
                <button
                  onClick={() => generateCaseStatusReport(caseStatusClientId)}
                  disabled={!caseStatusClientId || caseStatusLoading}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  {caseStatusLoading 
                    ? (language === 'ar' ? 'جاري التحميل...' : 'Loading...') 
                    : (language === 'ar' ? 'إنشاء التقرير' : 'Generate Report')}
                </button>
              </div>
              
              {/* Client Activity Preview */}
              {caseStatusClientId && !caseStatusData && (
                <div className="mt-3 bg-indigo-50 rounded-lg p-3 border border-indigo-100">
                  {(() => {
                    const clientId = caseStatusClientId;
                    const clientMatters = matters.filter(m => String(m.client_id) === String(clientId));
                    const activeMatters = clientMatters.filter(m => ['active', 'engaged', 'on_hold'].includes(m.status));
                    const clientHearings = hearings.filter(h => {
                      const matter = matters.find(m => m.matter_id === h.matter_id);
                      return matter && String(matter.client_id) === String(clientId);
                    });
                    const upcomingHearings = clientHearings.filter(h => new Date(h.hearing_date) >= new Date());
                    
                    return (
                      <div className="flex flex-wrap gap-4 text-sm">
                        <div>
                          <span className="text-indigo-600">{language === 'ar' ? 'القضايا النشطة:' : 'Active Matters:'}</span>
                          <span className="font-medium text-indigo-800 ml-1">{activeMatters.length}</span>
                        </div>
                        <div>
                          <span className="text-indigo-600">{language === 'ar' ? 'إجمالي القضايا:' : 'Total Matters:'}</span>
                          <span className="font-medium text-indigo-800 ml-1">{clientMatters.length}</span>
                        </div>
                        <div>
                          <span className="text-indigo-600">{language === 'ar' ? 'جلسات قادمة:' : 'Upcoming Hearings:'}</span>
                          <span className="font-medium text-indigo-800 ml-1">{upcomingHearings.length}</span>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
            
            {/* Content */}
            <div className="flex-1 overflow-auto p-4">
              {!caseStatusData ? (
                <div className="text-center py-12 text-gray-500">
                  {caseStatusClientId 
                    ? (language === 'ar' ? 'اضغط "إنشاء التقرير" لعرض البيانات' : 'Click "Generate Report" to view data')
                    : (language === 'ar' ? 'اختر العميل أولاً' : 'Select a client first')}
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Client Info */}
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-800 mb-2">
                      {caseStatusData.client?.client_name}
                      {caseStatusData.client?.client_name_ar && ` / ${caseStatusData.client.client_name_ar}`}
                    </h3>
                    <div className="text-sm text-gray-600">
                      {caseStatusData.client?.email && <span>{caseStatusData.client.email}</span>}
                      {caseStatusData.client?.phone && <span className="ml-3">{caseStatusData.client.phone}</span>}
                    </div>
                  </div>
                  
                  {/* Summary Cards */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-indigo-50 rounded-lg p-3 text-center">
                      <div className="text-xs text-indigo-600 uppercase">{language === 'ar' ? 'القضايا النشطة' : 'Active Matters'}</div>
                      <div className="text-2xl font-bold text-indigo-800">{caseStatusData.summary?.totalMatters || 0}</div>
                    </div>
                    <div className="bg-blue-50 rounded-lg p-3 text-center">
                      <div className="text-xs text-blue-600 uppercase">{language === 'ar' ? 'جلسات قادمة' : 'Upcoming Hearings'}</div>
                      <div className="text-2xl font-bold text-blue-800">{caseStatusData.summary?.upcomingHearingsCount || 0}</div>
                    </div>
                    <div className="bg-purple-50 rounded-lg p-3 text-center">
                      <div className="text-xs text-purple-600 uppercase">{language === 'ar' ? 'أحكام حديثة' : 'Recent Judgments'}</div>
                      <div className="text-2xl font-bold text-purple-800">{caseStatusData.summary?.recentJudgmentsCount || 0}</div>
                    </div>
                    <div className="bg-amber-50 rounded-lg p-3 text-center">
                      <div className="text-xs text-amber-600 uppercase">{language === 'ar' ? 'مواعيد نهائية' : 'Pending Deadlines'}</div>
                      <div className="text-2xl font-bold text-amber-800">{caseStatusData.summary?.upcomingDeadlinesCount || 0}</div>
                    </div>
                  </div>
                  
                  {/* Matters Table */}
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2 flex items-center gap-2">
                      <Briefcase className="w-4 h-4" />
                      {language === 'ar' ? 'القضايا النشطة' : 'Active Matters'} ({caseStatusData.matters?.length || 0})
                    </h4>
                    {caseStatusData.matters?.length > 0 ? (
                      <table className="w-full text-sm">
                        <thead className="bg-gray-100">
                          <tr>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'القضية' : 'Matter'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'رقم الملف' : 'Case #'}</th>
                            <th className="px-3 py-2 text-center">{language === 'ar' ? 'الحالة' : 'Status'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'المحامي' : 'Lawyer'}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {caseStatusData.matters.map(m => (
                            <tr key={m.matter_id} className="hover:bg-gray-50">
                              <td className="px-3 py-2 font-medium">{m.matter_name}</td>
                              <td className="px-3 py-2">{m.case_number || '-'}</td>
                              <td className="px-3 py-2 text-center">
                                <span className={`px-2 py-0.5 text-xs rounded-full ${
                                  m.status === 'active' ? 'bg-green-100 text-green-800' :
                                  m.status === 'engaged' ? 'bg-blue-100 text-blue-800' :
                                  'bg-yellow-100 text-yellow-800'
                                }`}>
                                  {m.status}
                                </span>
                              </td>
                              <td className="px-3 py-2">{m.lawyer_name || '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-4 text-gray-500 bg-gray-50 rounded">
                        {language === 'ar' ? 'لا توجد قضايا نشطة' : 'No active matters'}
                      </div>
                    )}
                  </div>
                  
                  {/* Hearings Table */}
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2 flex items-center gap-2">
                      <Gavel className="w-4 h-4" />
                      {language === 'ar' ? 'الجلسات القادمة (90 يوم)' : 'Upcoming Hearings (90 days)'} ({caseStatusData.hearings?.length || 0})
                    </h4>
                    {caseStatusData.hearings?.length > 0 ? (
                      <table className="w-full text-sm">
                        <thead className="bg-gray-100">
                          <tr>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'التاريخ' : 'Date'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'القضية' : 'Matter'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'الغرض' : 'Purpose'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'المحكمة' : 'Court'}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {caseStatusData.hearings.map(h => (
                            <tr key={h.hearing_id} className="hover:bg-gray-50">
                              <td className="px-3 py-2 font-medium">{new Date(h.hearing_date).toLocaleDateString('en-GB')}</td>
                              <td className="px-3 py-2">{h.matter_name}</td>
                              <td className="px-3 py-2">{h.purpose_name || h.purpose_custom || '-'}</td>
                              <td className="px-3 py-2">{h.court_name || '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-4 text-gray-500 bg-gray-50 rounded">
                        {language === 'ar' ? 'لا توجد جلسات قادمة' : 'No upcoming hearings'}
                      </div>
                    )}
                  </div>
                  
                  {/* Judgments Table */}
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2 flex items-center gap-2">
                      <Scale className="w-4 h-4" />
                      {language === 'ar' ? 'الأحكام الحديثة (12 شهر)' : 'Recent Judgments (12 months)'} ({caseStatusData.judgments?.length || 0})
                    </h4>
                    {caseStatusData.judgments?.length > 0 ? (
                      <table className="w-full text-sm">
                        <thead className="bg-gray-100">
                          <tr>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'التاريخ' : 'Date'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'القضية' : 'Matter'}</th>
                            <th className="px-3 py-2 text-center">{language === 'ar' ? 'النتيجة' : 'Outcome'}</th>
                            <th className="px-3 py-2 text-center">{language === 'ar' ? 'الحالة' : 'Status'}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {caseStatusData.judgments.map(j => (
                            <tr key={j.judgment_id} className="hover:bg-gray-50">
                              <td className="px-3 py-2">{new Date(j.judgment_date).toLocaleDateString('en-GB')}</td>
                              <td className="px-3 py-2">{j.matter_name}</td>
                              <td className="px-3 py-2 text-center">
                                <span className={`px-2 py-0.5 text-xs rounded-full ${
                                  j.outcome === 'favorable' ? 'bg-green-100 text-green-800' :
                                  j.outcome === 'unfavorable' ? 'bg-red-100 text-red-800' :
                                  'bg-yellow-100 text-yellow-800'
                                }`}>
                                  {j.outcome || '-'}
                                </span>
                              </td>
                              <td className="px-3 py-2 text-center">
                                <span className={`px-2 py-0.5 text-xs rounded-full ${
                                  j.status === 'final' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                                }`}>
                                  {j.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-4 text-gray-500 bg-gray-50 rounded">
                        {language === 'ar' ? 'لا توجد أحكام حديثة' : 'No recent judgments'}
                      </div>
                    )}
                  </div>
                  
                  {/* Deadlines Table */}
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4" />
                      {language === 'ar' ? 'المواعيد النهائية القادمة (60 يوم)' : 'Upcoming Deadlines (60 days)'} ({caseStatusData.deadlines?.length || 0})
                    </h4>
                    {caseStatusData.deadlines?.length > 0 ? (
                      <table className="w-full text-sm">
                        <thead className="bg-gray-100">
                          <tr>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'التاريخ' : 'Due Date'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'الوصف' : 'Description'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'القضية' : 'Matter'}</th>
                            <th className="px-3 py-2 text-center">{language === 'ar' ? 'الأيام المتبقية' : 'Days Left'}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {caseStatusData.deadlines.map(d => {
                            const daysRemaining = Math.ceil((new Date(d.deadline_date) - new Date()) / (1000 * 60 * 60 * 24));
                            return (
                              <tr key={d.deadline_id} className={`hover:bg-gray-50 ${daysRemaining <= 7 ? 'bg-red-50' : ''}`}>
                                <td className="px-3 py-2 font-medium">{new Date(d.deadline_date).toLocaleDateString('en-GB')}</td>
                                <td className="px-3 py-2">{d.title}</td>
                                <td className="px-3 py-2">{d.matter_name || '-'}</td>
                                <td className="px-3 py-2 text-center">
                                  <span className={`px-2 py-0.5 text-xs rounded-full ${
                                    daysRemaining <= 7 ? 'bg-red-100 text-red-800 font-bold' :
                                    daysRemaining <= 14 ? 'bg-yellow-100 text-yellow-800' :
                                    'bg-gray-100 text-gray-800'
                                  }`}>
                                    {daysRemaining} {language === 'ar' ? 'يوم' : 'days'}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-4 text-gray-500 bg-gray-50 rounded">
                        {language === 'ar' ? 'لا توجد مواعيد نهائية قادمة' : 'No upcoming deadlines'}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
            
            {/* Footer with Export Buttons */}
            <div className="flex justify-between items-center p-4 border-t bg-gray-50 rounded-b-lg">
              <button
                onClick={() => { setShowCaseStatusReport(false); setCaseStatusData(null); setCaseStatusClientId(''); }}
                className="px-4 py-2 border rounded-md hover:bg-gray-100"
              >
                {language === 'ar' ? 'إغلاق' : 'Close'}
              </button>
              {caseStatusData && (
                <div className="flex gap-2">
                  <button
                    onClick={() => exportCaseStatusReport('excel')}
                    className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center gap-2"
                  >
                    <FileSpreadsheet className="w-4 h-4" />
                    {language === 'ar' ? 'تصدير Excel' : 'Export Excel'}
                  </button>
                  <button
                    onClick={() => exportCaseStatusReport('pdf')}
                    className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 flex items-center gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    {language === 'ar' ? 'تصدير PDF' : 'Export PDF'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      {/* Client 360° Report Modal (v44.5) */}
      {showClient360Report && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="flex justify-between items-center p-4 border-b bg-emerald-600 text-white rounded-t-lg">
              <h2 className="text-lg font-semibold">
                {language === 'ar' ? 'تقرير 360° للعميل' : 'Client 360° Report'}
              </h2>
              <button onClick={() => { setShowClient360Report(false); setClient360Data(null); setClient360ClientId(''); }}
                className="p-1 hover:bg-emerald-700 rounded">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            {/* Client Selection */}
            <div className="p-4 border-b bg-gray-50">
              <div className="flex gap-3 items-end">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {language === 'ar' ? 'العميل' : 'Client'} *
                  </label>
                  <select
                    value={client360ClientId}
                    onChange={(e) => { setClient360ClientId(e.target.value); setClient360Data(null); }}
                    className="w-full px-3 py-2 border rounded-md"
                  >
                    <option value="">{language === 'ar' ? '-- اختر العميل --' : '-- Select Client --'}</option>
                    {clients.map(c => (
                      <option key={c.client_id} value={c.client_id}>
                        {language === 'ar' && c.client_name_ar ? c.client_name_ar : c.client_name}
                      </option>
                    ))}
                  </select>
                </div>
                <button
                  onClick={() => generateClient360Report(client360ClientId)}
                  disabled={!client360ClientId || client360Loading}
                  className="px-6 py-2 bg-emerald-600 text-white rounded-md hover:bg-emerald-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  {client360Loading 
                    ? (language === 'ar' ? 'جاري التحميل...' : 'Loading...') 
                    : (language === 'ar' ? 'إنشاء التقرير' : 'Generate Report')}
                </button>
              </div>
              
              {/* Client Activity Preview */}
              {client360ClientId && !client360Data && (
                <div className="mt-3 bg-emerald-50 rounded-lg p-3 border border-emerald-100">
                  {(() => {
                    const clientId = client360ClientId;
                    const clientMatters = matters.filter(m => String(m.client_id) === String(clientId));
                    const clientInvoices = invoices.filter(inv => String(inv.client_id) === String(clientId));
                    const clientTimesheets = timesheets.filter(ts => {
                      const matter = matters.find(m => m.matter_id === ts.matter_id);
                      return matter && String(matter.client_id) === String(clientId);
                    });
                    const clientExpenses = expenses.filter(exp => String(exp.client_id) === String(clientId));
                    
                    return (
                      <div className="flex flex-wrap gap-4 text-sm">
                        <div>
                          <span className="text-emerald-600">{language === 'ar' ? 'القضايا:' : 'Matters:'}</span>
                          <span className="font-medium text-emerald-800 ml-1">{clientMatters.length}</span>
                        </div>
                        <div>
                          <span className="text-emerald-600">{language === 'ar' ? 'الفواتير:' : 'Invoices:'}</span>
                          <span className="font-medium text-emerald-800 ml-1">{clientInvoices.length}</span>
                        </div>
                        <div>
                          <span className="text-emerald-600">{language === 'ar' ? 'سجلات الوقت:' : 'Timesheets:'}</span>
                          <span className="font-medium text-emerald-800 ml-1">{clientTimesheets.length}</span>
                        </div>
                        <div>
                          <span className="text-emerald-600">{language === 'ar' ? 'المصاريف:' : 'Expenses:'}</span>
                          <span className="font-medium text-emerald-800 ml-1">{clientExpenses.length}</span>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
            
            {/* Content */}
            <div className="flex-1 overflow-auto p-4">
              {!client360Data ? (
                <div className="text-center py-12 text-gray-500">
                  {client360ClientId 
                    ? (language === 'ar' ? 'اضغط "إنشاء التقرير" لعرض البيانات' : 'Click "Generate Report" to view data')
                    : (language === 'ar' ? 'اختر العميل أولاً' : 'Select a client first')}
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Client Info */}
                  <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg p-4 border border-emerald-200">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-bold text-xl text-emerald-900">
                          {client360Data.client?.client_name}
                          {client360Data.client?.client_name_arabic && (
                            <span className="mr-2" dir="rtl"> / {client360Data.client.client_name_arabic}</span>
                          )}
                        </h3>
                        <div className="text-sm text-emerald-700 mt-1 flex flex-wrap gap-3">
                          {client360Data.client?.email && (
                            <span className="flex items-center gap-1"><Mail className="w-4 h-4" />{client360Data.client.email}</span>
                          )}
                          {client360Data.client?.phone && (
                            <span className="flex items-center gap-1"><Phone className="w-4 h-4" />{client360Data.client.phone}</span>
                          )}
                          {client360Data.client?.client_type && (
                            <span className={`px-2 py-0.5 text-xs rounded-full ${
                              client360Data.client.client_type === 'legal_entity' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                            }`}>
                              {client360Data.client.client_type === 'legal_entity' ? 'Legal Entity' : 'Individual'}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right text-xs text-emerald-600">
                        <div>{language === 'ar' ? 'تاريخ التقرير' : 'Report Date'}</div>
                        <div className="font-medium">{new Date().toLocaleDateString('en-GB')}</div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Financial Summary Cards */}
                  <div>
                    <h4 className="font-medium text-gray-700 mb-2 flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      {language === 'ar' ? 'الملخص المالي' : 'Financial Summary'}
                    </h4>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                      <div className="bg-blue-50 rounded-lg p-3 text-center border border-blue-100">
                        <div className="text-xs text-blue-600 uppercase">{language === 'ar' ? 'إجمالي الفواتير' : 'Total Invoiced'}</div>
                        <div className="text-lg font-bold text-blue-800">${(client360Data.financial?.totalInvoiced || 0).toLocaleString()}</div>
                      </div>
                      <div className="bg-green-50 rounded-lg p-3 text-center border border-green-100">
                        <div className="text-xs text-green-600 uppercase">{language === 'ar' ? 'المحصل' : 'Collected'}</div>
                        <div className="text-lg font-bold text-green-800">${(client360Data.financial?.totalPaid || 0).toLocaleString()}</div>
                      </div>
                      <div className="bg-red-50 rounded-lg p-3 text-center border border-red-100">
                        <div className="text-xs text-red-600 uppercase">{language === 'ar' ? 'المستحق' : 'Outstanding'}</div>
                        <div className="text-lg font-bold text-red-800">${(client360Data.financial?.outstanding || 0).toLocaleString()}</div>
                      </div>
                      <div className="bg-purple-50 rounded-lg p-3 text-center border border-purple-100">
                        <div className="text-xs text-purple-600 uppercase">{language === 'ar' ? 'رصيد الأمانات' : 'Retainer Balance'}</div>
                        <div className="text-lg font-bold text-purple-800">${(client360Data.financial?.retainerBalance || 0).toLocaleString()}</div>
                      </div>
                      <div className="bg-amber-50 rounded-lg p-3 text-center border border-amber-100">
                        <div className="text-xs text-amber-600 uppercase">{language === 'ar' ? 'غير مفوتر' : 'Unbilled Time'}</div>
                        <div className="text-lg font-bold text-amber-800">${(client360Data.financial?.unbilledValue || 0).toLocaleString()}</div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Activity Summary Cards */}
                  <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
                    <div className="bg-gray-50 rounded-lg p-3 text-center border">
                      <div className="text-2xl font-bold text-gray-800">{client360Data.summary?.totalMatters || 0}</div>
                      <div className="text-xs text-gray-600">{language === 'ar' ? 'القضايا' : 'Matters'}</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3 text-center border">
                      <div className="text-2xl font-bold text-gray-800">{client360Data.summary?.totalHearings || 0}</div>
                      <div className="text-xs text-gray-600">{language === 'ar' ? 'الجلسات' : 'Hearings'}</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3 text-center border">
                      <div className="text-2xl font-bold text-gray-800">{client360Data.summary?.totalJudgments || 0}</div>
                      <div className="text-xs text-gray-600">{language === 'ar' ? 'الأحكام' : 'Judgments'}</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3 text-center border">
                      <div className="text-2xl font-bold text-gray-800">{client360Data.summary?.totalDeadlines || 0}</div>
                      <div className="text-xs text-gray-600">{language === 'ar' ? 'المواعيد' : 'Deadlines'}</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3 text-center border">
                      <div className="text-2xl font-bold text-gray-800">{client360Data.summary?.totalTimesheets || 0}</div>
                      <div className="text-xs text-gray-600">{language === 'ar' ? 'سجلات الوقت' : 'Timesheets'}</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3 text-center border">
                      <div className="text-2xl font-bold text-gray-800">{client360Data.summary?.totalExpenses || 0}</div>
                      <div className="text-xs text-gray-600">{language === 'ar' ? 'المصاريف' : 'Expenses'}</div>
                    </div>
                  </div>
                  
                  {/* Matters Table */}
                  <div className="bg-white border rounded-lg overflow-hidden">
                    <div className="bg-indigo-50 px-4 py-2 border-b flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-indigo-600" />
                      <span className="font-medium text-indigo-800">{language === 'ar' ? 'القضايا' : 'Matters'} ({client360Data.matters?.length || 0})</span>
                    </div>
                    {client360Data.matters?.length > 0 ? (
                      <table className="w-full text-sm">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'القضية' : 'Matter'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'رقم الملف' : 'Case #'}</th>
                            <th className="px-3 py-2 text-center">{language === 'ar' ? 'الحالة' : 'Status'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'النوع' : 'Type'}</th>
                            <th className="px-3 py-2 text-left">{language === 'ar' ? 'تاريخ الفتح' : 'Opened'}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {client360Data.matters.map(m => (
                            <tr key={m.matter_id} className="hover:bg-gray-50">
                              <td className="px-3 py-2 font-medium">{m.matter_name}</td>
                              <td className="px-3 py-2 text-gray-600">{m.case_number || '-'}</td>
                              <td className="px-3 py-2 text-center">
                                <span className={`px-2 py-0.5 text-xs rounded-full ${
                                  m.status === 'active' ? 'bg-green-100 text-green-800' :
                                  m.status === 'engaged' ? 'bg-blue-100 text-blue-800' :
                                  m.status === 'closed' ? 'bg-gray-100 text-gray-800' :
                                  'bg-yellow-100 text-yellow-800'
                                }`}>{m.status}</span>
                              </td>
                              <td className="px-3 py-2 text-gray-600">{m.matter_type || '-'}</td>
                              <td className="px-3 py-2 text-gray-600">{m.opening_date ? new Date(m.opening_date).toLocaleDateString('en-GB') : '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-4 text-gray-500">{language === 'ar' ? 'لا توجد قضايا' : 'No matters'}</div>
                    )}
                  </div>
                  
                  {/* Two-column layout for Hearings and Judgments */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {/* Hearings Table */}
                    <div className="bg-white border rounded-lg overflow-hidden">
                      <div className="bg-blue-50 px-4 py-2 border-b flex items-center gap-2">
                        <Gavel className="w-4 h-4 text-blue-600" />
                        <span className="font-medium text-blue-800">{language === 'ar' ? 'الجلسات' : 'Hearings'} ({client360Data.hearings?.length || 0})</span>
                      </div>
                      {client360Data.hearings?.length > 0 ? (
                        <div className="max-h-60 overflow-auto">
                          <table className="w-full text-sm">
                            <thead className="bg-gray-50 sticky top-0">
                              <tr>
                                <th className="px-3 py-2 text-left">{language === 'ar' ? 'التاريخ' : 'Date'}</th>
                                <th className="px-3 py-2 text-left">{language === 'ar' ? 'القضية' : 'Matter'}</th>
                                <th className="px-3 py-2 text-left">{language === 'ar' ? 'الغرض' : 'Purpose'}</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y">
                              {client360Data.hearings.slice(0, 10).map(h => (
                                <tr key={h.hearing_id} className="hover:bg-gray-50">
                                  <td className="px-3 py-2">{new Date(h.hearing_date).toLocaleDateString('en-GB')}</td>
                                  <td className="px-3 py-2">{h.matter_name}</td>
                                  <td className="px-3 py-2 text-gray-600">{h.purpose_name || '-'}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                          {client360Data.hearings.length > 10 && (
                            <div className="text-center py-2 text-xs text-gray-500 bg-gray-50">
                              +{client360Data.hearings.length - 10} {language === 'ar' ? 'جلسات أخرى' : 'more hearings'}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-center py-4 text-gray-500">{language === 'ar' ? 'لا توجد جلسات' : 'No hearings'}</div>
                      )}
                    </div>
                    
                    {/* Judgments Table */}
                    <div className="bg-white border rounded-lg overflow-hidden">
                      <div className="bg-purple-50 px-4 py-2 border-b flex items-center gap-2">
                        <Scale className="w-4 h-4 text-purple-600" />
                        <span className="font-medium text-purple-800">{language === 'ar' ? 'الأحكام' : 'Judgments'} ({client360Data.judgments?.length || 0})</span>
                      </div>
                      {client360Data.judgments?.length > 0 ? (
                        <div className="max-h-60 overflow-auto">
                          <table className="w-full text-sm">
                            <thead className="bg-gray-50 sticky top-0">
                              <tr>
                                <th className="px-3 py-2 text-left">{language === 'ar' ? 'التاريخ' : 'Date'}</th>
                                <th className="px-3 py-2 text-left">{language === 'ar' ? 'القضية' : 'Matter'}</th>
                                <th className="px-3 py-2 text-left">{language === 'ar' ? 'الملخص' : 'Summary'}</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y">
                              {client360Data.judgments.map(j => (
                                <tr key={j.judgment_id} className="hover:bg-gray-50">
                                  <td className="px-3 py-2">{j.judgment_date ? new Date(j.judgment_date).toLocaleDateString('en-GB') : '-'}</td>
                                  <td className="px-3 py-2">{j.matter_name}</td>
                                  <td className="px-3 py-2 text-gray-600 truncate max-w-[200px]" title={j.judgment_summary}>
                                    {j.judgment_summary?.substring(0, 50) || '-'}{j.judgment_summary?.length > 50 ? '...' : ''}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <div className="text-center py-4 text-gray-500">{language === 'ar' ? 'لا توجد أحكام' : 'No judgments'}</div>
                      )}
                    </div>
                  </div>
                  
                  {/* Two-column layout for Deadlines and Timesheets */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {/* Deadlines Table */}
                    <div className="bg-white border rounded-lg overflow-hidden">
                      <div className="bg-amber-50 px-4 py-2 border-b flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-amber-600" />
                        <span className="font-medium text-amber-800">{language === 'ar' ? 'المواعيد النهائية' : 'Deadlines'} ({client360Data.deadlines?.length || 0})</span>
                      </div>
                      {client360Data.deadlines?.length > 0 ? (
                        <div className="max-h-60 overflow-auto">
                          <table className="w-full text-sm">
                            <thead className="bg-gray-50 sticky top-0">
                              <tr>
                                <th className="px-3 py-2 text-left">{language === 'ar' ? 'التاريخ' : 'Due Date'}</th>
                                <th className="px-3 py-2 text-left">{language === 'ar' ? 'الوصف' : 'Title'}</th>
                                <th className="px-3 py-2 text-center">{language === 'ar' ? 'الحالة' : 'Status'}</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y">
                              {client360Data.deadlines.slice(0, 10).map(d => (
                                <tr key={d.deadline_id} className="hover:bg-gray-50">
                                  <td className="px-3 py-2">{new Date(d.deadline_date).toLocaleDateString('en-GB')}</td>
                                  <td className="px-3 py-2">{d.title}</td>
                                  <td className="px-3 py-2 text-center">
                                    <span className={`px-2 py-0.5 text-xs rounded-full ${
                                      d.status === 'completed' ? 'bg-green-100 text-green-800' :
                                      d.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                                      'bg-red-100 text-red-800'
                                    }`}>{d.status}</span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                          {client360Data.deadlines.length > 10 && (
                            <div className="text-center py-2 text-xs text-gray-500 bg-gray-50">
                              +{client360Data.deadlines.length - 10} {language === 'ar' ? 'مواعيد أخرى' : 'more deadlines'}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-center py-4 text-gray-500">{language === 'ar' ? 'لا توجد مواعيد' : 'No deadlines'}</div>
                      )}
                    </div>
                    
                    {/* Timesheets Table */}
                    <div className="bg-white border rounded-lg overflow-hidden">
                      <div className="bg-cyan-50 px-4 py-2 border-b flex items-center gap-2">
                        <Clock className="w-4 h-4 text-cyan-600" />
                        <span className="font-medium text-cyan-800">{language === 'ar' ? 'سجلات الوقت' : 'Timesheets'} ({client360Data.timesheets?.length || 0})</span>
                        {client360Data.timesheets?.length > 0 && (
                          <span className="text-xs text-cyan-600 ml-auto">
                            {(() => {
                              const totalMins = client360Data.timesheets.reduce((sum, ts) => sum + (ts.duration_minutes || 0), 0);
                              return `${Math.floor(totalMins / 60)}h ${totalMins % 60}m total`;
                            })()}
                          </span>
                        )}
                      </div>
                      {client360Data.timesheets?.length > 0 ? (
                        <div className="max-h-60 overflow-auto">
                          <table className="w-full text-sm">
                            <thead className="bg-gray-50 sticky top-0">
                              <tr>
                                <th className="px-3 py-2 text-left">{language === 'ar' ? 'التاريخ' : 'Date'}</th>
                                <th className="px-3 py-2 text-left">{language === 'ar' ? 'القضية' : 'Matter'}</th>
                                <th className="px-3 py-2 text-right">{language === 'ar' ? 'المدة' : 'Duration'}</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y">
                              {client360Data.timesheets.slice(0, 10).map(ts => (
                                <tr key={ts.timesheet_id} className="hover:bg-gray-50">
                                  <td className="px-3 py-2">{new Date(ts.work_date).toLocaleDateString('en-GB')}</td>
                                  <td className="px-3 py-2">{ts.matter_name}</td>
                                  <td className="px-3 py-2 text-right">{Math.floor(ts.duration_minutes / 60)}h {ts.duration_minutes % 60}m</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                          {client360Data.timesheets.length > 10 && (
                            <div className="text-center py-2 text-xs text-gray-500 bg-gray-50">
                              +{client360Data.timesheets.length - 10} {language === 'ar' ? 'سجلات أخرى' : 'more entries'}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-center py-4 text-gray-500">{language === 'ar' ? 'لا توجد سجلات وقت' : 'No timesheets'}</div>
                      )}
                    </div>
                  </div>
                  
                  {/* Expenses Table */}
                  <div className="bg-white border rounded-lg overflow-hidden">
                    <div className="bg-rose-50 px-4 py-2 border-b flex items-center gap-2">
                      <Receipt className="w-4 h-4 text-rose-600" />
                      <span className="font-medium text-rose-800">{language === 'ar' ? 'المصاريف' : 'Expenses'} ({client360Data.expenses?.length || 0})</span>
                      {client360Data.expenses?.length > 0 && (
                        <span className="text-xs text-rose-600 ml-auto">
                          ${client360Data.expenses.reduce((sum, e) => sum + (parseFloat(e.amount) || 0), 0).toLocaleString()} {language === 'ar' ? 'إجمالي' : 'total'}
                        </span>
                      )}
                    </div>
                    {client360Data.expenses?.length > 0 ? (
                      <div className="max-h-48 overflow-auto">
                        <table className="w-full text-sm">
                          <thead className="bg-gray-50 sticky top-0">
                            <tr>
                              <th className="px-3 py-2 text-left">{language === 'ar' ? 'التاريخ' : 'Date'}</th>
                              <th className="px-3 py-2 text-left">{language === 'ar' ? 'الفئة' : 'Category'}</th>
                              <th className="px-3 py-2 text-left">{language === 'ar' ? 'القضية' : 'Matter'}</th>
                              <th className="px-3 py-2 text-right">{language === 'ar' ? 'المبلغ' : 'Amount'}</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y">
                            {client360Data.expenses.slice(0, 10).map(e => (
                              <tr key={e.expense_id} className="hover:bg-gray-50">
                                <td className="px-3 py-2">{new Date(e.expense_date).toLocaleDateString('en-GB')}</td>
                                <td className="px-3 py-2">{e.category_name || e.category || '-'}</td>
                                <td className="px-3 py-2">{e.matter_name || '-'}</td>
                                <td className="px-3 py-2 text-right font-medium">${parseFloat(e.amount || 0).toFixed(2)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {client360Data.expenses.length > 10 && (
                          <div className="text-center py-2 text-xs text-gray-500 bg-gray-50">
                            +{client360Data.expenses.length - 10} {language === 'ar' ? 'مصاريف أخرى' : 'more expenses'}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-4 text-gray-500">{language === 'ar' ? 'لا توجد مصاريف' : 'No expenses'}</div>
                    )}
                  </div>
                </div>
              )}
            </div>
            
            {/* Footer with Export Buttons */}
            <div className="flex justify-between items-center p-4 border-t bg-gray-50 rounded-b-lg">
              <button
                onClick={() => { setShowClient360Report(false); setClient360Data(null); setClient360ClientId(''); }}
                className="px-4 py-2 border rounded-md hover:bg-gray-100"
              >
                {language === 'ar' ? 'إغلاق' : 'Close'}
              </button>
              {client360Data && (
                <div className="flex gap-2">
                  <button
                    onClick={() => exportClient360Report('excel')}
                    className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center gap-2"
                  >
                    <FileSpreadsheet className="w-4 h-4" />
                    {language === 'ar' ? 'تصدير Excel' : 'Export Excel'}
                  </button>
                  <button
                    onClick={() => exportClient360Report('pdf')}
                    className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 flex items-center gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    {language === 'ar' ? 'تصدير PDF' : 'Export PDF'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      {showLookupForm && <LookupForm
          language={language}
          isRTL={isRTL}
          showLookupForm={showLookupForm}
          setShowLookupForm={setShowLookupForm}
          lookupType={currentLookupType}
          editingLookup={editingLookup}
          setEditingLookup={setEditingLookup}
          showToast={showToast}
          refreshLookups={refreshLookups}
          t={t}
        />}
      
      {/* Time Tracking Timer Widget */}
      <TimerWidget />
      
      {/* Toast Notifications */}
      {toast && <Toast message={toast.message} type={toast.type} onClose={hideToast} />}
      
      {/* Confirmation Dialog */}
      <ConfirmDialog 
        isOpen={confirmDialog.isOpen}
        title={confirmDialog.title}
        message={confirmDialog.message}
        onConfirm={() => { confirmDialog.onConfirm?.(); }}
        onCancel={() => { hideConfirm(); setPendingNavigation(null); }}
        confirmText={
          confirmDialog.confirmText ? confirmDialog.confirmText
            : confirmDialog.title?.includes('Unsaved') || confirmDialog.title?.includes('غير محفوظة')
              ? (language === 'ar' ? 'متابعة' : 'Continue')
              : confirmDialog.title?.includes('Description') || confirmDialog.title?.includes('الوصف')
                ? (language === 'ar' ? 'حفظ على أي حال' : 'Save Anyway')
                : (language === 'ar' ? 'حذف' : 'Delete')
        }
        cancelText={language === 'ar' ? 'إلغاء' : 'Cancel'}
        danger={
          confirmDialog.danger !== undefined ? confirmDialog.danger
            : !confirmDialog.title?.includes('Unsaved') && 
              !confirmDialog.title?.includes('غير محفوظة') &&
              !confirmDialog.title?.includes('Description') &&
              !confirmDialog.title?.includes('الوصف')
        }
      />
      
      {/* Print Styles */}
      <PrintStyles />
    </div>
  );
};

export default App;

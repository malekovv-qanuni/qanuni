# PHASE 5: Testing & Debugging

**Objective:** Comprehensive testing of desktop and web modes, fix any issues found  
**Duration:** 1 hour  
**Prerequisites:** Phase 4 complete (web setup configured)  
**Next Phase:** PHASE6_FINAL_CHECKPOINT.md

---

## What We're Testing

1. **Desktop Mode** - Full regression (30 min)
2. **Web Mode** - Initial functionality test (30 min)
3. **Integration Tests** - Backend verification (5 min)
4. **Bug Fixes** - Fix any issues found (variable)

---

## PART 1: Desktop Mode Full Regression (30 min)

**Desktop mode MUST work perfectly. This is non-negotiable.**

### Start Desktop App

```bash
npm run dev
```

**Expected:** Electron window opens with Qanuni app

---

### Test Checklist - Go Through Systematically

**🏠 Dashboard**
- [ ] App loads without errors
- [ ] Stats cards show numbers (Total Clients, Active Matters, etc.)
- [ ] Today's hearings section displays
- [ ] Upcoming tasks section displays
- [ ] Recent activities section displays
- [ ] **Action:** Note exact numbers (e.g., "8 clients, 12 matters")

**👥 Clients Module**
- [ ] Click "Clients" in sidebar
- [ ] List loads with data
- [ ] Click "+ Add Client"
- [ ] Form opens correctly
- [ ] Fill form: Name "Test Client", Type "Individual", Email "test@example.com"
- [ ] Click Save
- [ ] Client appears in list
- [ ] Click on client row
- [ ] Client 360 view opens
- [ ] Can edit client (change name to "Test Client Updated")
- [ ] Changes saved
- [ ] Can delete client (soft delete - moves to trash)
- [ ] Client disappears from list

**📁 Matters Module**
- [ ] Click "Matters" in sidebar
- [ ] List loads with client names displayed
- [ ] Click "+ Add Matter"
- [ ] Form opens
- [ ] Client dropdown populated
- [ ] Court type dropdown populated
- [ ] Region dropdown populated
- [ ] Select client, fill matter name, select court/region
- [ ] Click Save
- [ ] Matter appears in list with client name
- [ ] Click matter row
- [ ] Matter details/timeline view opens
- [ ] Can view timeline
- [ ] Can add diary entry to timeline
- [ ] Diary entry appears in timeline
- [ ] Can edit matter
- [ ] Can close matter details

**⚖️ Hearings Module**
- [ ] Click "Hearings" in sidebar
- [ ] List loads
- [ ] Click "+ Add Hearing"
- [ ] Form opens
- [ ] Matter dropdown populated
- [ ] Select matter
- [ ] **VERIFY:** Court type and region auto-fill from matter
- [ ] Date picker works
- [ ] Time picker works
- [ ] Fill form and save
- [ ] Hearing appears in list

**✓ Tasks Module**
- [ ] Click "Tasks" in sidebar
- [ ] List loads
- [ ] Click "+ Add Task"
- [ ] Form opens
- [ ] Fill form (title, assigned to, due date)
- [ ] Save task
- [ ] Task appears in list
- [ ] Can mark task complete (status change)
- [ ] Status updates in list

**⏱️ Timesheets Module**
- [ ] Click "Timesheets" in sidebar
- [ ] List loads (or shows empty state)
- [ ] Filter by matter dropdown works
- [ ] Click "+ Add Timesheet"
- [ ] Form opens
- [ ] Matter dropdown populated
- [ ] Date picker works
- [ ] Hours field accepts decimal (e.g., 2.5)
- [ ] Description field works
- [ ] Save timesheet
- [ ] Timesheet appears in list/filtered view

**💰 Expenses Module**
- [ ] Click "Expenses" in sidebar
- [ ] List loads
- [ ] Click "+ Add Expense"
- [ ] Form opens
- [ ] Matter dropdown populated
- [ ] Amount field works
- [ ] Date picker works
- [ ] Category dropdown populated
- [ ] Save expense
- [ ] Expense appears in list

**💵 Advances Module**
- [ ] Click "Advances" in sidebar
- [ ] List loads with balances
- [ ] Click "+ Add Advance"
- [ ] Form opens
- [ ] Client dropdown populated
- [ ] Amount field works
- [ ] Save advance
- [ ] Advance appears in list with full balance

**📄 Invoices Module**
- [ ] Click "Invoices" in sidebar
- [ ] List loads
- [ ] Click "+ Create Invoice"
- [ ] **Step 1: Select Client**
  - [ ] Client dropdown works
  - [ ] Select client, click Next
- [ ] **Step 2: Select Items**
  - [ ] Matter dropdown loads (client's matters)
  - [ ] Select matter
  - [ ] Unbilled timesheets load
  - [ ] Unbilled expenses load
  - [ ] Can select items
  - [ ] Click Next
- [ ] **Step 3: Review**
  - [ ] Selected items display
  - [ ] Totals calculate correctly
  - [ ] Invoice date field works
  - [ ] Due date field works
  - [ ] Click Save Invoice
- [ ] Invoice appears in list

**⚖️ Judgments Module**
- [ ] Click "Judgments" in sidebar
- [ ] List loads
- [ ] Click "+ Add Judgment"
- [ ] Form works
- [ ] Can save judgment

**📅 Deadlines Module**
- [ ] Click "Deadlines" in sidebar
- [ ] List loads
- [ ] Can add deadline

**📅 Calendar Module**
- [ ] Click "Calendar" in sidebar
- [ ] Calendar displays
- [ ] Can switch between month/week/day views
- [ ] Hearings appear on calendar
- [ ] Appointments appear on calendar

**🏢 Companies Module (Corporate Secretary)**
- [ ] Click "Companies" in sidebar
- [ ] List loads (legal entity clients)
- [ ] Click on entity
- [ ] Entity details page opens
- [ ] Tabs visible: Overview, Shareholders, Directors, etc.
- [ ] Click "+ Add Shareholder"
- [ ] Form opens
- [ ] Can save shareholder
- [ ] Shareholder appears in list

**⚙️ Settings Module**
- [ ] Click "Settings" in sidebar
- [ ] Module loads
- [ ] **Firm Info tab:**
  - [ ] Firm info displays
  - [ ] Can edit firm name
  - [ ] Save works
- [ ] **Lawyers tab:**
  - [ ] Lawyers list loads
  - [ ] Click "+ Add Lawyer"
  - [ ] Form opens correctly (not expense categories form!)
  - [ ] Can save lawyer
- [ ] **Lookup Tables tab:**
  - [ ] Court types list loads
  - [ ] Can add court type
  - [ ] Icon field shows 📋 correctly (not corrupted)
  - [ ] Can edit lookup value
  - [ ] Can delete lookup value

**📊 Reports Module**
- [ ] Click "Reports" in sidebar
- [ ] Module loads
- [ ] Can select report type
- [ ] Report generates
- [ ] Data displays

---

### Desktop Integration Tests

```bash
node test-integration.js
```

**Expected output:**
```
✅ All tests passed (117/117)
```

**If any test fails:**
- Note which test failed
- Document the error message
- Fix issue before proceeding to web mode

---

### Desktop Mode: Document Baseline

**Create a baseline document:**

**In a text file, write:**
```
DESKTOP MODE BASELINE - Session 3 Phase 5
Date: [today's date]
Version: v48.2-phase5-testing

Counts:
- Clients: [X]
- Matters: [X]
- Hearings: [X]
- Tasks: [X]
- Timesheets: [X]
- Expenses: [X]
- Invoices: [X]

Integration Tests: 117/117 PASSED

All modules tested: ✓
All CRUD operations tested: ✓
All forms open correctly: ✓
All lists load correctly: ✓

Bugs found: [list any bugs]
- Bug 1: [description]
- Bug 2: [description]

Status: DESKTOP MODE VERIFIED CLEAN
```

**This baseline helps us know if web mode breaks anything.**

---

## PART 2: Web Mode Initial Test (30 min)

**Now test web version at localhost:3000**

### Start Web Mode

```bash
npm run dev:web
```

**Wait for both servers to start:**
- API server: http://localhost:3001
- React dev: http://localhost:3000

**Browser should open automatically at localhost:3000**

---

### Web Mode Test Checklist

**🌐 App Loads**
- [ ] Browser shows Qanuni interface (not blank page)
- [ ] No white screen of death
- [ ] Sidebar visible
- [ ] Header visible
- [ ] Language toggle works (switch EN ↔ AR)

**Console Check:**
- [ ] Open browser DevTools (F12)
- [ ] Go to Console tab
- [ ] **Expected:** Some warnings/errors OK at this stage
- [ ] **Bad sign:** Red errors about "Cannot read property..."
- [ ] **Document any errors you see**

**Network Check:**
- [ ] Go to Network tab in DevTools
- [ ] Refresh page (Ctrl+R)
- [ ] Look for calls to `http://localhost:3001/api/...`
- [ ] **Expected:** You see API calls listed (even if some fail)
- [ ] Click on an API call
- [ ] Check Response tab - should show JSON data
- [ ] **If you see 404 errors:** API routes missing (bad)
- [ ] **If you see CORS errors:** Need to add CORS to API server

**🏠 Dashboard:**
- [ ] Navigate to Dashboard (if not already there)
- [ ] Stats cards display
- [ ] Numbers show (might be same as desktop, might be different)
- [ ] **Don't worry about accuracy - just check they display**

**👥 Clients - Basic CRUD Test:**
- [ ] Click "Clients" in sidebar
- [ ] List loads
- [ ] Click "+ Add Client"
- [ ] Form opens
- [ ] Fill form: Name "Web Test Client", Type "Individual"
- [ ] Click Save
- [ ] **Check Network tab:** See POST request to /api/clients
- [ ] **Check Response:** { success: true, clientId: "CLT-..." }
- [ ] Client appears in list
- [ ] Click client row
- [ ] Client 360 view opens (or details modal)
- [ ] Can edit client
- [ ] Changes save
- [ ] **If any of this fails, document the error**

**📁 Matters - Basic Test:**
- [ ] Click "Matters" in sidebar
- [ ] List loads
- [ ] Client names display in list (not "undefined")
- [ ] Click "+ Add Matter"
- [ ] Form opens
- [ ] Client dropdown populated
- [ ] Select client
- [ ] Court/region dropdowns populated
- [ ] Fill form and save
- [ ] Matter appears in list
- [ ] **If fails, document error**

**📄 Invoice Wizard Test:**
- [ ] Navigate to Invoices
- [ ] Click "+ Create Invoice"
- [ ] Step 1: Client dropdown works
- [ ] Select client, click Next
- [ ] Step 2: Matter dropdown works, select matter
- [ ] Unbilled items load (timesheets/expenses)
- [ ] Can select items, click Next
- [ ] Step 3: Review shows items
- [ ] Can save invoice
- [ ] **If fails, document at which step and what error**

**🔍 Search/Filter Test:**
- [ ] Go to Clients list
- [ ] Use search box
- [ ] Type client name
- [ ] List filters correctly
- [ ] Clear search
- [ ] List shows all clients again

**📱 Navigation Test:**
- [ ] Click through all modules in sidebar
- [ ] Each module loads (even if empty)
- [ ] No crashes
- [ ] Can navigate back and forth

**⚠️ Electron-Only Features (Expected to Fail):**
- [ ] Try to export Excel (Clients list → Export button)
- [ ] **Expected:** Error message: "Excel export requires the desktop app..."
- [ ] Try to create backup (Settings → Backup)
- [ ] **Expected:** Error message: "Database backup requires the desktop app..."
- [ ] **This is correct behavior - document that errors show**

---

### Web Mode: Known Issues (Expected)

**These are EXPECTED and OK for now:**

1. **Excel/PDF Export buttons:** Show error about requiring desktop app ✓
2. **Backup/Restore:** Not available in web mode ✓
3. **Import from Excel:** Not available in web mode ✓
4. **Some styling issues:** Layout might look different ✓
5. **Authentication:** No login yet (deferred to Session 4) ✓

**These are PROBLEMS (need fixing):**

1. ❌ Blank page (app doesn't load at all)
2. ❌ "Cannot read property of undefined" errors
3. ❌ Lists don't load (empty when they should have data)
4. ❌ Forms don't submit (no network request)
5. ❌ Data shows as "undefined" in lists
6. ❌ Dropdowns don't populate
7. ❌ CORS errors blocking API calls

---

### Document Web Mode Results

**Create another baseline document:**

```
WEB MODE INITIAL TEST - Session 3 Phase 5
Date: [today's date]
URL: http://localhost:3000
API: http://localhost:3001

Basic Functionality:
- App loads: [YES/NO]
- Dashboard displays: [YES/NO]
- Can add client: [YES/NO]
- Can add matter: [YES/NO]
- Can create invoice: [YES/NO]
- Lists load data: [YES/NO]
- Navigation works: [YES/NO]

API Calls Working:
- GET /api/clients: [YES/NO]
- POST /api/clients: [YES/NO]
- GET /api/matters: [YES/NO]
- GET /api/dashboard-stats: [YES/NO]

Known Issues Found:
1. [Issue description]
2. [Issue description]

Status: [WORKING / NEEDS FIXES]
```

---

## PART 3: Bug Fixes (If Needed)

**If you found issues in web mode, fix them before Phase 6.**

### Common Fixes

**Fix 1: CORS Error**
- **File:** server/api-server.js
- **Add at top:** `const cors = require('cors');`
- **Add after `const app = express();`:** `app.use(cors());`

**Fix 2: Method Not Found**
- **Check:** api-client.js has the method
- **Check:** Method name matches exactly
- **Fix:** Add missing method or fix typo

**Fix 3: Undefined Data in Lists**
- **Check:** API response format
- **Check:** Component expects correct field names
- **Fix:** Ensure API returns same format as IPC did

**Fix 4: Empty Dropdown**
- **Check:** useEffect loading data on mount
- **Check:** API call succeeds in Network tab
- **Fix:** Verify state updates correctly

---

## PART 4: Re-test After Fixes

**After fixing any bugs:**

1. **Test desktop again:**
   ```bash
   npm run dev
   ```
   - Quick smoke test (Dashboard, Clients, Matters)
   - Verify no regressions introduced

2. **Test web again:**
   ```bash
   npm run dev:web
   ```
   - Re-test the specific features that were broken
   - Verify fixes worked

3. **Integration tests:**
   ```bash
   node test-integration.js
   ```
   - Must still pass 117/117

---

## ✅ Success Criteria

- [ ] Desktop mode: Full regression passed (all modules work)
- [ ] Desktop mode: Integration tests 117/117
- [ ] Desktop mode: Baseline documented
- [ ] Web mode: App loads at localhost:3000
- [ ] Web mode: Dashboard displays stats
- [ ] Web mode: Can add client (basic CRUD works)
- [ ] Web mode: Can add matter
- [ ] Web mode: Lists load data
- [ ] Web mode: Navigation between modules works
- [ ] Web mode: Electron-only features show appropriate errors
- [ ] Web mode: Issues documented (if any)
- [ ] Bug fixes: All critical issues resolved
- [ ] Both modes verified working

---

## 📊 Phase 5 Summary

**Time spent:** ~1 hour (30 min desktop, 30 min web)

**Desktop mode:** Fully verified, 0 regressions

**Web mode:** Initial functionality confirmed

**Issues found:** [X issues]
**Issues fixed:** [X issues]

**Status:** Ready for Phase 6 (final checkpoint)

---

## Next Phase

**File:** PHASE6_FINAL_CHECKPOINT.md

**What we'll do:**
- Final verification (desktop + web)
- Git commit (all changes)
- Tag release (v48.2-session3-web-frontend)
- Update documentation (CLAUDE.md)
- Create completion report

**Duration:** 15 minutes

---

*Phase 5 complete - Ready for Phase 6*

# PHASE 2: Update App.js

**Objective:** Replace all `window.electronAPI.*` calls in App.js with `apiClient.*`  
**Duration:** 1 hour  
**Prerequisites:** Phase 1 complete (api-client.js exists)  
**Next Phase:** PHASE3_UPDATE_COMPONENTS.md

---

## What We're Doing

App.js currently has ~60-80 direct calls to `window.electronAPI`. We need to:
1. Import apiClient
2. Replace all window.electronAPI calls
3. Test desktop mode (must stay functional)
4. Git checkpoint

---

## Step 1: Add Import Statement

**File:** `C:\Projects\qanuni\src\App.js`

**Action:** Add this line at the TOP of the file (after existing imports, around line 1-10):

```javascript
import apiClient from './api-client';
```

**What it should look like:**
```javascript
import React, { useState, useEffect } from 'react';
import './index.css';
import apiClient from './api-client';  // <-- ADD THIS LINE

// ... rest of file
```

---

## Step 2: Find and Replace All IPC Calls

**Use VS Code Find & Replace:**
- Press `Ctrl+H` (Windows) or `Cmd+H` (Mac)
- Make sure you're editing App.js

**Settings:**
- **Find:** `window\.electronAPI\.`
- **Replace:** `apiClient.`
- **Options:** 
  - ✅ Match Case
  - ✅ Use Regular Expression (icon: `.*`)
  - ⬜ Match Whole Word (leave unchecked)

**Click "Replace All"**

**Expected:** 60-80 replacements

---

## Step 3: Verify No window.electronAPI Remains

**In VS Code:**
- Press `Ctrl+F` (Find)
- Search for: `window.electronAPI`
- **Expected result:** 0 matches found

**In PowerShell:**
```powershell
Select-String -Path "C:\Projects\qanuni\src\App.js" -Pattern "window\.electronAPI"
```

**Expected output:** No results (empty)

---

## Step 4: Save File

Make sure App.js is saved (Ctrl+S)

---

## Step 5: Test Desktop Mode (CRITICAL)

Desktop mode MUST still work perfectly. This is a refactor, not a feature change.

**Start app:**
```bash
npm run dev
```

**Test checklist:**

**App Loads:**
- [ ] App opens without crash
- [ ] No console errors in DevTools
- [ ] Dashboard visible

**Dashboard:**
- [ ] Stats cards show numbers (not zeros)
- [ ] Today's hearings display
- [ ] Upcoming tasks display

**Clients:**
- [ ] List loads
- [ ] Can click "+ Add Client"
- [ ] Form opens
- [ ] Can fill form and save
- [ ] Client appears in list

**Matters:**
- [ ] List loads with client names
- [ ] Can click "+ Add Matter"
- [ ] Client dropdown works
- [ ] Court/region dropdowns work
- [ ] Can save matter

**Settings:**
- [ ] Module loads
- [ ] Firm info tab works
- [ ] Lawyers tab works

**If ANY test fails:**
1. Check browser console (F12) for errors
2. Check what method is failing
3. Verify that method exists in api-client.js
4. Fix issue before proceeding

---

## Step 6: Git Checkpoint

```bash
git add src/App.js
git commit -m "Phase 2: App.js uses apiClient (~60-80 IPC calls replaced)"
```

---

## ✅ Success Criteria

- [ ] Import line added to App.js
- [ ] All window.electronAPI calls replaced with apiClient
- [ ] Search for "window.electronAPI" in App.js returns 0 results
- [ ] Desktop app (npm run dev) works perfectly
- [ ] Dashboard loads stats
- [ ] Can add client
- [ ] Can add matter
- [ ] Settings module works
- [ ] Git committed successfully

---

## 🐛 Common Issues & Fixes

**Issue 1: "apiClient is not defined"**
- **Cause:** Import statement missing or incorrect
- **Fix:** Verify line 1-10 has: `import apiClient from './api-client';`

**Issue 2: "Cannot read property 'getClients' of undefined"**
- **Cause:** api-client.js not created or has syntax error
- **Fix:** Verify api-client.js exists and has no syntax errors

**Issue 3: Empty lists showing**
- **Cause:** API call is failing silently
- **Fix:** Open browser console (F12), check for errors
- **Check:** Is the method name correct? Did you type it exactly?

**Issue 4: "Unexpected token" error**
- **Cause:** Syntax error from find/replace
- **Fix:** Check around the error line for malformed code

---

## 📊 Phase 2 Summary

**What changed:**
- App.js: Added import, ~60-80 replacements
- Desktop mode: Still fully functional (verified)

**What's next:**
- Phase 3: Update all component files (forms, lists, modules)
- Same pattern: import apiClient, replace window.electronAPI

**Time spent:** ~15-20 min actual work, ~40 min testing

---

## Next Phase

**File:** PHASE3_UPDATE_COMPONENTS.md

**What we'll do:**
- Update 13 forms
- Update 11 lists
- Update 5+ modules
- Same find/replace pattern
- Test desktop mode again

---

*Phase 2 complete - Ready for Phase 3*

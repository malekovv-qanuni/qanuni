# Session 3: Web Frontend - Phase Index

**Version:** v48.2-session3-web-frontend  
**Date:** February 11, 2026  
**Estimated Duration:** 4-5 hours total  
**Current Phase:** Ready to begin Phase 1

---

## 📋 Overview

Transform Qanuni from Electron-only to dual-mode (Electron + Web) by creating an API client abstraction layer that routes calls to IPC (desktop) or REST (web) based on environment detection.

**Goal:** React app runs in browser at localhost:3000 while maintaining 100% backward compatibility with desktop Electron app.

---

## 🗂️ Phase Files

### PHASE 1: Create API Client Layer
**File:** `PHASE1_CREATE_API_CLIENT.md`  
**Duration:** 1 hour  
**Deliverable:** src/api-client.js (856 lines, 156 methods)

**What you'll do:**
- Create new file: src/api-client.js
- Copy complete code from instruction file
- Implement environment detection (isElectron)
- Add 137 dual-mode methods (IPC + REST)
- Add 19 Electron-only stubs with helpful errors
- Git checkpoint

**Success:** File created, no syntax errors, git committed

---

### PHASE 2: Update App.js
**File:** `PHASE2_UPDATE_APP.md`  
**Duration:** 1 hour  
**Deliverable:** App.js uses apiClient instead of window.electronAPI

**What you'll do:**
- Add import: `import apiClient from './api-client'`
- Find & Replace: `window.electronAPI.` → `apiClient.`
- Test desktop mode (must work perfectly)
- Git checkpoint

**Success:** ~60-80 replacements, desktop mode works, git committed

---

### PHASE 3: Update All Components
**File:** `PHASE3_UPDATE_COMPONENTS.md`  
**Duration:** 1 hour (3 batches)  
**Deliverable:** 30+ component files updated

**What you'll do:**
- **Batch 1:** 13 forms (add import, replace calls)
- **Batch 2:** 11 lists (add import, replace calls)
- **Batch 3:** 6 modules/corporate (add import, replace calls)
- Test desktop mode fully
- Git checkpoint

**Success:** All components updated, desktop mode works, 117/117 tests pass

---

### PHASE 4: Web Development Setup
**File:** `PHASE4_WEB_SETUP.md`  
**Duration:** 30 minutes  
**Deliverable:** React app configured to run standalone

**What you'll do:**
- Install react-scripts and concurrently
- Create public/index.html (HTML entry point)
- Create src/index.js (React DOM mount)
- Create .env.development (API URL config)
- Update package.json scripts (add web commands)
- Test web mode (initial smoke test)
- Git checkpoint

**Success:** localhost:3000 loads, both modes work, git committed

---

### PHASE 5: Testing & Debugging
**File:** `PHASE5_TESTING.md`  
**Duration:** 1 hour  
**Deliverable:** Both modes verified, bugs fixed

**What you'll do:**
- **Desktop:** Full regression test (all 11 modules)
- **Desktop:** Integration tests (117/117 must pass)
- **Web:** Initial functionality test
- **Web:** Basic CRUD operations (clients, matters, invoices)
- Fix any bugs found
- Document baselines for both modes

**Success:** Desktop verified clean, web operational, issues documented/fixed

---

### PHASE 6: Final Checkpoint & Documentation
**File:** `PHASE6_FINAL_CHECKPOINT.md`  
**Duration:** 15 minutes  
**Deliverable:** Git tagged, documentation updated

**What you'll do:**
- Final verification (quick smoke test both modes)
- Review git status (all changes)
- Comprehensive git commit (full session summary)
- Tag release (v48.2-session3-web-frontend)
- Push to GitHub
- Update CLAUDE.md (web version section)
- Create SESSION_3_COMPLETE.md

**Success:** All committed, tagged, pushed, documented

---

## 🎯 Execution Strategy

### Option 1: All Phases in One Session (4-5 hours)
Run all 6 phases sequentially. Take breaks between phases.

**Timeline:**
- Phase 1: 1 hour
- Phase 2: 1 hour
- Phase 3: 1 hour
- **BREAK** (15 min)
- Phase 4: 30 min
- Phase 5: 1 hour
- **BREAK** (15 min)
- Phase 6: 15 min

### Option 2: Split Across Multiple Sessions
**Session A (2 hours):** Phases 1-2  
**Session B (2 hours):** Phases 3-4  
**Session C (1.5 hours):** Phases 5-6

### Option 3: Daily Progress (Recommended)
**Day 1:** Phases 1-2 (2 hours)  
**Day 2:** Phase 3 (1 hour)  
**Day 3:** Phases 4-5 (1.5 hours)  
**Day 4:** Phase 6 + Session 4 start (15 min + ongoing)

---

## 📁 File Navigation

**Instruction Files (Read These):**
1. `PHASE1_CREATE_API_CLIENT.md` - Start here
2. `PHASE2_UPDATE_APP.md`
3. `PHASE3_UPDATE_COMPONENTS.md`
4. `PHASE4_WEB_SETUP.md`
5. `PHASE5_TESTING.md`
6. `PHASE6_FINAL_CHECKPOINT.md`

**Context Files (Reference):**
- `SESSION_3_WEB_FRONTEND_PLAN.md` - Strategic overview
- `SESSION_2_COMPLETE.md` - REST API context
- `API_ENDPOINTS.md` - Endpoint reference
- `PATTERNS.md` - Code conventions
- `CLAUDE.md` - Project overview

---

## ✅ Success Criteria (Overall)

**Desktop Mode:**
- [ ] All modules work perfectly
- [ ] Zero regressions introduced
- [ ] Integration tests: 117/117 passing
- [ ] Fully backward compatible

**Web Mode:**
- [ ] App loads at localhost:3000
- [ ] Dashboard displays stats
- [ ] CRUD operations work (clients, matters, etc.)
- [ ] Navigation between modules functional
- [ ] API calls successful

**Code Quality:**
- [ ] No window.electronAPI calls in components (all use apiClient)
- [ ] All files properly imported
- [ ] No syntax errors
- [ ] No console errors in desktop mode

**Documentation:**
- [ ] Git commits comprehensive
- [ ] Tagged: v48.2-session3-web-frontend
- [ ] CLAUDE.md updated
- [ ] SESSION_3_COMPLETE.md created

---

## 🐛 Known Issues Checklist

**After each phase, verify:**
- [ ] No syntax errors
- [ ] Desktop mode works
- [ ] Git committed successfully
- [ ] Ready for next phase

**Common issues across all phases:**
1. **Import path wrong:** Check `../../api-client` vs `../api-client`
2. **Typo in method name:** Verify exact method exists in api-client.js
3. **Desktop regression:** Test after each phase
4. **Git conflicts:** Commit frequently

---

## 📊 Progress Tracking

**Use this checklist as you work:**

- [ ] **Phase 1:** api-client.js created ✓
- [ ] **Phase 2:** App.js updated ✓
- [ ] **Phase 3:** All components updated ✓
- [ ] **Phase 4:** Web setup configured ✓
- [ ] **Phase 5:** Testing complete ✓
- [ ] **Phase 6:** Documentation done ✓

**Session 3 Status:** [ ] Complete

---

## 🚀 Getting Started

### For Claude Code Chat:

**Copy this instruction to Code Chat:**

```
Session 3: Web Frontend Implementation

I need to execute Phase 1 from the Session 3 Web Frontend plan.

Context:
- Session 2 COMPLETE: REST API operational (21 modules, 137 endpoints)
- Desktop app fully functional (Electron with IPC)
- Goal: Enable React app to run in browser

Current Phase: PHASE 1
File: PHASE1_CREATE_API_CLIENT.md

Task: Create src/api-client.js with 156 dual-mode methods
- Environment detection (Electron vs Browser)
- 137 data methods (IPC + REST dual-mode)
- 19 Electron-only stubs with errors

Please read PHASE1_CREATE_API_CLIENT.md and execute the instructions.
After completion, I'll provide PHASE2_UPDATE_APP.md for the next step.
```

### For Manual Execution:

1. Open `PHASE1_CREATE_API_CLIENT.md`
2. Follow step-by-step instructions
3. Test as you go
4. Git commit at end of phase
5. Move to Phase 2

---

## 🔄 Between Phases

**After completing each phase:**

1. **Verify success criteria met**
2. **Git committed**
3. **Desktop mode still works**
4. **Take a 5-minute break**
5. **Move to next phase**

**If something breaks:**
- Stop immediately
- Review what changed in last phase
- Check git diff to see exact changes
- Fix issue before proceeding
- Re-test desktop mode
- Then continue

---

## 📞 Support

**If stuck on any phase:**

1. **Re-read the phase instructions carefully**
2. **Check the "Common Issues & Fixes" section**
3. **Review git diff** to see what actually changed
4. **Test in isolation** (just that one component)
5. **Document the issue** with exact error message
6. **Move on and note issue** if not critical

---

## 🎯 Final Destination

**After Phase 6 completion, you'll have:**

✅ Dual-mode Qanuni app (Electron + Web)  
✅ 156 API client methods with auto-detection  
✅ Desktop mode: Zero regressions, fully functional  
✅ Web mode: React app at localhost:3000  
✅ 137 REST API endpoints operational  
✅ Comprehensive documentation  
✅ Git tagged: v48.2-session3-web-frontend  

**Ready for Session 4:** Automated browser testing, bug discovery, and final Phase 3c completion.

---

*Session 3 Index - Start with PHASE1_CREATE_API_CLIENT.md*

# PHASE 4: Web Development Setup

**Objective:** Configure React app to run standalone in browser  
**Duration:** 30 minutes  
**Prerequisites:** Phase 3 complete (all components updated)  
**Next Phase:** PHASE5_TESTING.md

---

## What We're Building

Enable React app to run in browser at `localhost:3000` by:
1. Installing dependencies (react-scripts, concurrently)
2. Creating web entry point (public/index.html, src/index.js)
3. Configuring environment (.env.development)
4. Adding npm scripts for web mode

---

## Step 1: Install Dependencies

```bash
cd C:\Projects\qanuni
npm install react-scripts --save-dev
npm install concurrently --save-dev
```

**Wait for installation to complete** (~30-60 seconds)

**Verify installation:**
```bash
npm list react-scripts concurrently
```

**Expected:** Both packages listed with version numbers

---

## Step 2: Create public/index.html

### 2.1: Create public directory

```bash
mkdir public
```

### 2.2: Create index.html file

**File:** `C:\Projects\qanuni\public\index.html`

**Complete file content:**

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta name="description" content="Qanuni - Legal Practice Management System" />
    <title>Qanuni - Legal ERP</title>
  </head>
  <body>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div id="root"></div>
  </body>
</html>
```

**Verify file created:**
```powershell
Test-Path C:\Projects\qanuni\public\index.html
```

**Expected:** True

---

## Step 3: Create src/index.js

**File:** `C:\Projects\qanuni\src\index.js`

**Complete file content:**

```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

**Verify file created:**
```powershell
Test-Path C:\Projects\qanuni\src\index.js
```

**Expected:** True

---

## Step 4: Create .env.development

**File:** `C:\Projects\qanuni\.env.development`

**Content:**
```
REACT_APP_API_URL=http://localhost:3001
```

**This file tells the web version where to find the API server.**

**Verify file created:**
```powershell
Test-Path C:\Projects\qanuni\.env.development
```

**Expected:** True

---

## Step 5: Update package.json Scripts

**File:** `C:\Projects\qanuni\package.json`

**Find the "scripts" section** (around line 5-15)

**Replace the entire scripts section with:**

```json
  "scripts": {
    "dev": "electron .",
    "dev:test": "electron . --test-db",
    "api": "node server/api-server.js",
    "web": "react-scripts start",
    "dev:web": "concurrently \"npm run api\" \"npm run web\"",
    "build:web": "react-scripts build",
    "test": "node test-integration.js",
    "dist": "electron-builder",
    "dist:clean": "electron-builder --dir"
  },
```

**What each script does:**
- `dev` - Desktop Electron app (unchanged)
- `dev:test` - Desktop with test DB (unchanged)
- `api` - **NEW:** Start API server only
- `web` - **NEW:** Start React dev server only
- `dev:web` - **NEW:** Start both API + React (for web development)
- `build:web` - **NEW:** Build React for production
- `test` - Integration tests (unchanged)
- `dist` - Desktop build (unchanged)
- `dist:clean` - Desktop build clean (unchanged)

**Save file (Ctrl+S)**

---

## Step 6: Test Web Mode (Initial Test)

### 6.1: Start API + React

```bash
npm run dev:web
```

**What should happen:**

**Terminal 1 (API server):**
```
> qanuni@1.0.0 api
> node server/api-server.js

🚀 Qanuni API: http://localhost:3001
```

**Terminal 2 (React dev server):**
```
> qanuni@1.0.0 web
> react-scripts start

webpack compiled successfully
Compiled successfully!

You can now view qanuni in the browser.

  Local:            http://localhost:3000
  On Your Network:  http://192.168.x.x:3000
```

**Browser should automatically open at:** `http://localhost:3000`

### 6.2: What to Expect

**✅ Good signs:**
- Browser loads a page (not blank)
- You see the Qanuni interface
- Sidebar visible
- Dashboard or some module visible

**⚠️ Expected issues at this point:**
- Console errors about data loading (normal)
- Some features might not work yet
- Errors about missing data (normal)

**❌ Bad signs (needs fixing):**
- Blank white screen
- "Cannot GET /" error
- Browser doesn't open at all
- Both terminals show errors

### 6.3: Quick Smoke Test

If app loaded in browser:

1. **Check API is responding:**
   - Open browser console (F12)
   - Go to Network tab
   - Refresh page
   - Look for calls to `http://localhost:3001/api/...`
   - **Good:** You see API calls listed
   - **Bad:** You see no API calls

2. **Check Dashboard:**
   - Navigate to Dashboard (if not already there)
   - Check if stats cards show numbers
   - **Don't worry if they're wrong or zero - just check they display**

3. **Stop the servers:**
   - Press `Ctrl+C` in terminal to stop

---

## Step 7: Test Desktop Mode Still Works

**IMPORTANT:** Desktop mode must still work after all these changes.

```bash
npm run dev
```

**Quick test:**
- [ ] App loads in Electron window
- [ ] Dashboard shows stats
- [ ] Can navigate to Clients
- [ ] Clients list loads

**If desktop mode broken:**
1. Check what error you see
2. Verify package.json scripts section correct
3. Verify src/index.js doesn't conflict with Electron
4. Check main.js hasn't been modified

**Stop desktop app:** Close Electron window or Ctrl+C

---

## Step 8: Git Checkpoint

```bash
git add public/ src/index.js .env.development package.json
git status
# Review what's being committed
git commit -m "Phase 4: Web development setup (React standalone config)"
```

---

## ✅ Success Criteria

- [ ] Dependencies installed (react-scripts, concurrently)
- [ ] public/index.html created
- [ ] src/index.js created
- [ ] .env.development created
- [ ] package.json scripts updated
- [ ] `npm run dev:web` starts both servers
- [ ] Browser opens at localhost:3000
- [ ] App loads in browser (even if errors present)
- [ ] Desktop mode (npm run dev) still works
- [ ] Git committed successfully

---

## 🐛 Common Issues & Fixes

**Issue 1: "react-scripts: command not found"**
- **Cause:** react-scripts not installed
- **Fix:** Run `npm install react-scripts --save-dev` again
- **Verify:** Check node_modules folder has react-scripts

**Issue 2: "Cannot find module 'react-scripts'"**
- **Cause:** Installation failed or incomplete
- **Fix:** Delete node_modules, run `npm install`

**Issue 3: Port 3000 already in use**
- **Symptoms:** "Something is already running on port 3000"
- **Fix:** Close other apps using port 3000, or change port in package.json

**Issue 4: API server won't start**
- **Check:** Does server/api-server.js exist?
- **Check:** Was Session 2 completed? (REST API must exist)
- **Fix:** Verify server directory and api-server.js file present

**Issue 5: Blank page in browser**
- **Check:** Browser console (F12) for errors
- **Check:** Is public/index.html correct?
- **Check:** Is src/index.js correct?
- **Fix:** Verify root div ID is "root" in both files

**Issue 6: Desktop mode broken**
- **Symptoms:** Electron won't start or shows errors
- **Cause:** package.json or index.js conflict
- **Fix:** Verify Electron still uses main.js as entry point
- **Check:** `"main": "main.js"` in package.json

---

## 📊 Phase 4 Summary

**Files created:**
- public/index.html (HTML entry point for web)
- src/index.js (React DOM mount for web)
- .env.development (API URL config)

**Files modified:**
- package.json (added web scripts)

**Dependencies installed:**
- react-scripts (React dev server)
- concurrently (run multiple commands)

**Commands available:**
- `npm run dev` - Desktop Electron app
- `npm run dev:web` - Web version (API + React)
- `npm run api` - API server only
- `npm run web` - React dev server only

**Next:** Phase 5 - Comprehensive testing (desktop + web)

---

## Next Phase

**File:** PHASE5_TESTING.md

**What we'll do:**
- Full desktop mode regression test
- Web mode functionality test
- Integration tests
- Document any issues found

**Duration:** 1 hour

---

*Phase 4 complete - Ready for Phase 5*

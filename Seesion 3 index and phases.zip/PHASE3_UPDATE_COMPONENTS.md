# PHASE 3: Update All Components

**Objective:** Replace all `window.electronAPI.*` calls in 30+ component files  
**Duration:** 1 hour (3 batches: forms, lists, modules)  
**Prerequisites:** Phase 2 complete (App.js updated)  
**Next Phase:** PHASE4_WEB_SETUP.md

---

## What We're Doing

Update all components to use apiClient instead of window.electronAPI:
- **Batch 1:** 13 forms (30 min)
- **Batch 2:** 11 lists (20 min)
- **Batch 3:** Modules + corporate (10 min)

**Same pattern for each file:**
1. Add import: `import apiClient from '../../api-client';`
2. Find & Replace: `window\.electronAPI\.` → `apiClient.`
3. Save file

---

## BATCH 1: Forms (30 min)

### Files to Update (13 files)

**Location:** `C:\Projects\qanuni\src\components\forms\`

1. ClientForm.js
2. MatterForm.js
3. HearingForm.js
4. TaskForm.js
5. TimesheetForm.js
6. ExpenseForm.js
7. AdvanceForm.js
8. InvoiceForm.js
9. JudgmentForm.js
10. DeadlineForm.js
11. AppointmentForm.js
12. LookupForm.js
13. LawyerForm.js

### Step-by-Step for EACH File

**1. Open file in VS Code**

**2. Add import at top (after existing imports, before component function):**

```javascript
import apiClient from '../../api-client';
```

**What it should look like:**
```javascript
import React, { useState, useEffect } from 'react';
import FormField from '../common/FormField';
import apiClient from '../../api-client';  // <-- ADD THIS

const ClientForm = ({ ...props }) => {
  // component code
```

**3. Find & Replace in THIS file only:**
- Press `Ctrl+H`
- **Find:** `window\.electronAPI\.`
- **Replace:** `apiClient.`
- **Options:** ✅ Use Regular Expression
- Click "Replace All" (but only affects current file)

**4. Save file (Ctrl+S)**

**5. Repeat for next file**

### Verification After All 13 Forms

**Check no window.electronAPI remains:**
```powershell
Get-ChildItem "C:\Projects\qanuni\src\components\forms\*.js" | 
  Select-String -Pattern "window\.electronAPI"
```

**Expected:** No results (empty)

**Count imports added:**
```powershell
Get-ChildItem "C:\Projects\qanuni\src\components\forms\*.js" | 
  Select-String -Pattern "import apiClient" | 
  Measure-Object | Select-Object -ExpandProperty Count
```

**Expected:** 13 (one per file)

---

## BATCH 2: Lists (20 min)

### Files to Update (11 files)

**Location:** `C:\Projects\qanuni\src\components\lists\`

1. ClientsList.js
2. MattersList.js
3. HearingsList.js
4. TasksList.js
5. TimesheetsList.js
6. ExpensesList.js
7. AdvancesList.js
8. InvoicesList.js
9. JudgmentsList.js
10. DeadlinesList.js
11. AppointmentsList.js

### Same Process

**For EACH file:**
1. Open file
2. Add import: `import apiClient from '../../api-client';`
3. Find & Replace: `window\.electronAPI\.` → `apiClient.`
4. Save file

### Verification After All 11 Lists

```powershell
Get-ChildItem "C:\Projects\qanuni\src\components\lists\*.js" | 
  Select-String -Pattern "window\.electronAPI"
```

**Expected:** No results

```powershell
Get-ChildItem "C:\Projects\qanuni\src\components\lists\*.js" | 
  Select-String -Pattern "import apiClient" | 
  Measure-Object | Select-Object -ExpandProperty Count
```

**Expected:** 11

---

## BATCH 3: Modules & Corporate (10 min)

### Files to Update

**Modules (src/components/modules/):**
1. Dashboard.js
2. Calendar.js
3. SettingsModule.js
4. Reports.js

**Corporate (src/components/corporate/):**
5. EntitiesList.js
6. EntityForm.js

### Same Process

**For EACH file:**
1. Open file
2. Add import: `import apiClient from '../../api-client';`
   - **Note:** Path might be different for modules
   - **Dashboard, Calendar, Settings, Reports:** Use `'../../api-client'`
   - **EntitiesList, EntityForm:** Use `'../../api-client'`
3. Find & Replace: `window\.electronAPI\.` → `apiClient.`
4. Save file

### Verification After All 6 Files

```powershell
Get-ChildItem "C:\Projects\qanuni\src\components\modules\*.js" | 
  Select-String -Pattern "window\.electronAPI"

Get-ChildItem "C:\Projects\qanuni\src\components\corporate\*.js" | 
  Select-String -Pattern "window\.electronAPI"
```

**Expected for both:** No results

---

## Final Verification (All Components)

**Check entire components directory:**
```powershell
Get-ChildItem "C:\Projects\qanuni\src\components" -Recurse -Filter "*.js" | 
  Select-String -Pattern "window\.electronAPI"
```

**Expected:** No results (0 matches)

---

## Test Desktop Mode (IMPORTANT)

After all 30+ files updated, test desktop app thoroughly.

```bash
npm run dev
```

### Full Test Checklist

**Dashboard:**
- [ ] Loads without errors
- [ ] Stats show correct numbers
- [ ] Today's hearings display
- [ ] Upcoming tasks display

**Clients:**
- [ ] List loads
- [ ] Add client form opens
- [ ] Can create client
- [ ] Can edit client
- [ ] Can delete client (soft)
- [ ] Client 360 view works

**Matters:**
- [ ] List loads with client names
- [ ] Add matter form opens
- [ ] Dropdowns populate (client, court, region)
- [ ] Can create matter
- [ ] Can edit matter
- [ ] Matter timeline shows diary entries

**Hearings:**
- [ ] List loads
- [ ] Add hearing form opens
- [ ] Matter dropdown works
- [ ] Court/region inherit from matter
- [ ] Can create hearing
- [ ] Can edit hearing

**Tasks:**
- [ ] List loads
- [ ] Add task form opens
- [ ] Can create task
- [ ] Can edit task
- [ ] Can update status

**Timesheets:**
- [ ] Can view timesheets for a matter
- [ ] Add timesheet form works
- [ ] Can create timesheet
- [ ] Can edit timesheet

**Expenses:**
- [ ] List loads
- [ ] Add expense form opens
- [ ] Can create expense
- [ ] Can edit expense

**Advances:**
- [ ] List loads
- [ ] Add advance form opens
- [ ] Can create advance

**Invoices:**
- [ ] List loads
- [ ] Invoice wizard opens
- [ ] Step 1: Select client (dropdown works)
- [ ] Step 2: Select items (timesheets/expenses load)
- [ ] Step 3: Review (totals calculate)
- [ ] Can save invoice

**Judgments:**
- [ ] List loads
- [ ] Add judgment form opens
- [ ] Can create judgment

**Deadlines:**
- [ ] List loads
- [ ] Add deadline form opens
- [ ] Can create deadline

**Appointments:**
- [ ] List loads
- [ ] Add appointment form opens
- [ ] Can create appointment

**Settings:**
- [ ] Module loads
- [ ] Firm info tab works
- [ ] Can edit firm info
- [ ] Lawyers tab works
- [ ] Can add lawyer
- [ ] Lookup tables tab works
- [ ] Can add court type

**Companies (Corporate):**
- [ ] Entities list loads
- [ ] Can view entity details
- [ ] Can add shareholder
- [ ] Can add director

**Reports:**
- [ ] Module loads
- [ ] Can generate a report
- [ ] Report data displays

---

## Integration Tests

```bash
node test-integration.js
```

**Must show:** ✅ All tests passed (117/117)

**If any tests fail:**
1. Check which handler is failing
2. Verify that method exists in api-client.js
3. Check method name matches exactly
4. Fix issue and re-run tests

---

## Git Checkpoint

```bash
git add src/components/
git commit -m "Phase 3: All components use apiClient (30+ files updated)"
```

---

## ✅ Success Criteria

- [ ] All 13 forms updated (import added, calls replaced)
- [ ] All 11 lists updated (import added, calls replaced)
- [ ] All 6 modules/corporate files updated
- [ ] Total: 30+ files modified
- [ ] Search for "window.electronAPI" in components/ returns 0 results
- [ ] Desktop app works perfectly (all modules tested)
- [ ] Integration tests pass (117/117)
- [ ] Git committed successfully

---

## 🐛 Common Issues & Fixes

**Issue 1: Import path wrong**
- **Symptoms:** "Cannot find module './api-client'"
- **Fix:** Check path depth
  - Forms/Lists: `'../../api-client'`
  - Modules/Corporate: `'../../api-client'`
  - Common: `'../../api-client'`

**Issue 2: Some calls not replaced**
- **Symptoms:** Still seeing "window.electronAPI is not defined"
- **Fix:** Search for `window.electron` (without API) - might be typo
- **Fix:** Manually check the file, do find/replace again

**Issue 3: Form doesn't submit**
- **Symptoms:** Click save, nothing happens
- **Fix:** Check browser console for errors
- **Fix:** Verify the specific method name in api-client.js

**Issue 4: List shows "Loading..." forever**
- **Symptoms:** Component stuck in loading state
- **Fix:** Check if data loading useEffect calls the right method
- **Fix:** Verify method exists in api-client.js

---

## 📊 Phase 3 Summary

**Files modified:** 30+
- 13 forms
- 11 lists
- 4 modules
- 2 corporate files

**Changes per file:**
- Added 1 import statement
- Replaced 1-10 window.electronAPI calls (varies by component)

**Total replacements:** ~100-150 across all files

**Desktop mode:** Fully functional, 0 regressions

**Next:** Phase 4 - Web development setup

---

## Next Phase

**File:** PHASE4_WEB_SETUP.md

**What we'll do:**
- Install react-scripts and concurrently
- Create public/index.html
- Create src/index.js
- Update package.json scripts
- Test web mode (initial)

**Duration:** 30 min

---

*Phase 3 complete - Ready for Phase 4*

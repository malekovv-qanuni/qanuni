import React from 'react';
import { Plus } from 'lucide-react';

/**
 * HearingsList Component
 * Displays list of hearings, excluding Judgment Pronouncement hearings
 * (those appear in Judgments module instead)
 * 
 * Extracted from App.js v42.0.6
 */
const HearingsList = ({
  hearings,
  matters,
  clients,
  hearingPurposes,
  language,
  t,
  formatDate,
  setShowHearingForm,
  setEditingHearing,
  showConfirm,
  showToast,
  hideConfirm,
  refreshHearings,
  electronAPI
}) => {
  // Find the "Judgment Pronouncement" purpose ID
  const judgmentPronouncementPurpose = hearingPurposes.find(p => p.name_en === 'Judgment Pronouncement');
  
  // Filter out hearings with "Judgment Pronouncement" purpose - they appear in Judgments instead
  const filteredHearings = hearings.filter(h => {
    if (judgmentPronouncementPurpose && h.purpose_id === judgmentPronouncementPurpose.purpose_id) {
      return false; // Hide from Hearings list
    }
    if (h.purpose_custom === 'Judgment Pronouncement') {
      return false; // Also check custom purpose text
    }
    return true;
  });

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t[language].hearings}</h2>
        <button onClick={() => setShowHearingForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          <Plus className="w-5 h-5" /> {t[language].addHearing}
        </button>
      </div>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].hearingDate}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].client}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].matter}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].purpose}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].judge}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredHearings.length === 0 ? (
              <tr><td colSpan="6" className="px-6 py-8 text-center text-gray-500">{t[language].noData}</td></tr>
            ) : (
              filteredHearings.map(hearing => {
                const matter = matters.find(m => m.matter_id === hearing.matter_id);
                const client = matter ? clients.find(c => c.client_id === matter.client_id) : null;
                const purpose = hearingPurposes.find(p => p.purpose_id === hearing.purpose_id);
                return (
                  <tr key={hearing.hearing_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="font-medium">{formatDate(hearing.hearing_date)}</div>
                      <div className="text-sm text-gray-500">{hearing.hearing_time}</div>
                    </td>
                    <td className="px-6 py-4 text-sm">{client?.client_name || 'N/A'}</td>
                    <td className="px-6 py-4 text-sm">{matter?.matter_name || 'N/A'}</td>
                    <td className="px-6 py-4 text-sm">{language === 'ar' ? purpose?.name_ar : purpose?.name_en || hearing.purpose_custom}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">{hearing.judge || '--'}</td>
                    <td className="px-6 py-4 text-sm">
                      <button onClick={() => { setEditingHearing(hearing); setShowHearingForm(true); }}
                        className="text-blue-600 hover:text-blue-900 mr-3">{t[language].edit}</button>
                      <button onClick={() => {
                        showConfirm(
                          language === 'ar' ? 'حذف الجلسة' : 'Delete Hearing',
                          language === 'ar' ? 'هل أنت متأكد من حذف هذه الجلسة؟' : 'Are you sure you want to delete this hearing?',
                          async () => {
                            await electronAPI.deleteHearing(hearing.hearing_id);
                            await refreshHearings();
                            showToast(language === 'ar' ? 'تم حذف الجلسة' : 'Hearing deleted');
                            hideConfirm();
                          }
                        );
                      }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default HearingsList;

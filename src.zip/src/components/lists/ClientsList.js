import React from 'react';
import { Plus, Search, Edit3, Trash2 } from 'lucide-react';
import { EmptyState } from '../common';

/**
 * ClientsList Component
 * Displays a searchable list of clients with edit/delete actions
 * 
 * Extracted from App.js v42.0.5 to fix search focus bug
 * (Inner function components cause remount on parent state change)
 */
const ClientsList = ({
  clients,
  clientSearch,
  setClientSearch,
  language,
  t,
  setShowClientForm,
  setEditingClient,
  showConfirm,
  showToast,
  hideConfirm,
  refreshClients,
  electronAPI
}) => {
  // Filter clients based on search
  const filteredClients = clientSearch.trim() === '' 
    ? clients 
    : clients.filter(c => 
        (c.client_name || '').toLowerCase().includes(clientSearch.toLowerCase()) ||
        (c.client_name_arabic || '').includes(clientSearch) ||
        (c.email || '').toLowerCase().includes(clientSearch.toLowerCase()) ||
        (c.phone || '').includes(clientSearch) ||
        (c.mobile || '').includes(clientSearch)
      );

  // Show empty state when no clients exist
  if (clients.length === 0) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">{t[language].clients}</h2>
        </div>
        <div className="bg-white rounded-lg shadow">
          <EmptyState
            type="clients"
            title={t[language].emptyClients}
            description={t[language].emptyClientsDesc}
            actionLabel={t[language].addClient}
            onAction={() => setShowClientForm(true)}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t[language].clients}</h2>
        <button onClick={() => setShowClientForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          <Plus className="w-5 h-5" /> {t[language].addClient}
        </button>
      </div>
      
      {/* Search Bar */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            value={clientSearch}
            onChange={(e) => setClientSearch(e.target.value)}
            placeholder={t[language].searchClients || 'Search clients...'}
            className="w-full pl-10 pr-4 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        {clientSearch && (
          <p className="text-sm text-gray-500 mt-2">
            {t[language].showingOf || 'Showing'} {filteredClients.length} {t[language].of || 'of'} {clients.length} {t[language].clients}
          </p>
        )}
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].clientName}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].clientType}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].email}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].phone}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredClients.length === 0 ? (
              <tr><td colSpan="5" className="px-6 py-8 text-center text-gray-500">{t[language].noData}</td></tr>
            ) : (
              filteredClients.map(client => (
                <tr key={client.client_id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="font-medium">{client.client_name}</div>
                    {client.client_name_arabic && <div className="text-sm text-gray-500" dir="rtl">{client.client_name_arabic}</div>}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs rounded-full ${client.client_type === 'legal_entity' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}>
                      {client.client_type === 'legal_entity' ? t[language].legalEntity : t[language].individual}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{client.email}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{client.phone || client.mobile}</td>
                  <td className="px-6 py-4 text-sm">
                    <button onClick={() => { setEditingClient(client); setShowClientForm(true); }}
                      className="text-blue-600 hover:text-blue-900 mr-3">{t[language].edit}</button>
                    <button onClick={() => {
                      showConfirm(
                        language === 'ar' ? 'حذف العميل' : 'Delete Client',
                        language === 'ar' ? 'هل أنت متأكد من حذف هذا العميل؟' : 'Are you sure you want to delete this client?',
                        async () => {
                          await electronAPI.deleteClient(client.client_id);
                          await refreshClients();
                          showToast(language === 'ar' ? 'تم حذف العميل' : 'Client deleted');
                          hideConfirm();
                        }
                      );
                    }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ClientsList;

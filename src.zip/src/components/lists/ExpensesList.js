import React from 'react';
import { Plus } from 'lucide-react';

/**
 * ExpensesList Component
 * Displays expenses with filters, summary cards, and pagination
 * 
 * Extracted from App.js v42.7
 */

// Utility function
const formatDate = (dateStr) => {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleDateString('en-GB');
};

const ExpensesList = ({
  expenses,
  expenseFilters,
  setExpenseFilters,
  expensePage,
  setExpensePage,
  expensePageSize,
  setExpensePageSize,
  clients,
  matters,
  lawyers,
  expenseCategories,
  language,
  t,
  setEditingExpense,
  setShowExpenseForm,
  showConfirm,
  showToast,
  hideConfirm,
  refreshExpenses
}) => {
  const electronAPI = window.electronAPI;
  // Filter expenses
  const filteredExpenses = expenses.filter(exp => {
    if (expenseFilters.clientId && exp.client_id !== expenseFilters.clientId) return false;
    if (expenseFilters.matterId && exp.matter_id !== expenseFilters.matterId) return false;
    if (expenseFilters.paidBy === 'firm' && exp.paid_by_firm !== 1) return false;
    if (expenseFilters.paidBy && expenseFilters.paidBy !== 'firm' && exp.paid_by_lawyer_id !== expenseFilters.paidBy) return false;
    if (expenseFilters.status && exp.status !== expenseFilters.status) return false;
    if (expenseFilters.billable === 'yes' && !exp.billable) return false;
    if (expenseFilters.billable === 'no' && exp.billable) return false;
    if (expenseFilters.dateFrom && exp.date < expenseFilters.dateFrom) return false;
    if (expenseFilters.dateTo && exp.date > expenseFilters.dateTo) return false;
    return true;
  });

  // Pagination
  const totalPages = Math.ceil(filteredExpenses.length / expensePageSize);
  const startIdx = (expensePage - 1) * expensePageSize;
  const paginatedExpenses = filteredExpenses.slice(startIdx, startIdx + expensePageSize);

  // Calculate totals
  const expenseTotals = filteredExpenses.reduce((acc, exp) => {
    const amount = parseFloat(exp.amount) || 0;
    acc.total += amount;
    if (exp.billable) acc.billable += amount;
    else acc.nonBillable += amount;
    return acc;
  }, { total: 0, billable: 0, nonBillable: 0 });

  // Filter matters by selected client
  const filteredMatters = expenseFilters.clientId 
    ? matters.filter(m => m.client_id === expenseFilters.clientId)
    : [];

  const handleFilterChange = (field, value) => {
    setExpenseFilters(prev => {
      const newFilters = { ...prev, [field]: value };
      if (field === 'clientId') newFilters.matterId = '';
      return newFilters;
    });
    setExpensePage(1);
  };

  const clearFilters = () => {
    setExpenseFilters({ clientId: '', matterId: '', paidBy: '', status: '', billable: '', dateFrom: '', dateTo: '' });
    setExpensePage(1);
  };

  const hasActiveFilters = Object.values(expenseFilters).some(v => v !== '');

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t[language].expenses}</h2>
        <button onClick={() => setShowExpenseForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          <Plus className="w-5 h-5" /> {t[language].addExpense}
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].total || 'Total'}</div>
          <div className="text-2xl font-bold text-gray-800">${expenseTotals.total.toFixed(2)}</div>
          <div className="text-xs text-gray-400">{filteredExpenses.length} {language === 'ar' ? 'مصروف' : 'expenses'}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].billable || 'Billable'}</div>
          <div className="text-2xl font-bold text-green-600">${expenseTotals.billable.toFixed(2)}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].nonBillable || 'Non-billable'}</div>
          <div className="text-2xl font-bold text-gray-500">${expenseTotals.nonBillable.toFixed(2)}</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
          <select value={expenseFilters.clientId}
            onChange={(e) => handleFilterChange('clientId', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].allClients || 'All Clients'}</option>
            {clients.map(c => (
              <option key={c.client_id} value={c.client_id}>{c.client_name}</option>
            ))}
          </select>
          
          <select value={expenseFilters.matterId}
            onChange={(e) => handleFilterChange('matterId', e.target.value)}
            disabled={!expenseFilters.clientId}
            className="px-3 py-2 border rounded-md text-sm disabled:bg-gray-100">
            <option value="">{t[language].allMatters || 'All Matters'}</option>
            {filteredMatters.map(m => (
              <option key={m.matter_id} value={m.matter_id}>{m.matter_name}</option>
            ))}
          </select>
          
          <select value={expenseFilters.paidBy}
            onChange={(e) => handleFilterChange('paidBy', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].paidBy || 'Paid By'}: {t[language].all || 'All'}</option>
            <option value="firm">{t[language].firm || 'Firm'}</option>
            {lawyers.map(l => (
              <option key={l.lawyer_id} value={l.lawyer_id}>{l.full_name || l.name}</option>
            ))}
          </select>
          
          <select value={expenseFilters.status}
            onChange={(e) => handleFilterChange('status', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].allStatuses || 'All Statuses'}</option>
            <option value="pending">{t[language].pending || 'Pending'}</option>
            <option value="approved">{t[language].approved || 'Approved'}</option>
            <option value="billed">{t[language].billed || 'Billed'}</option>
          </select>
          
          <select value={expenseFilters.billable}
            onChange={(e) => handleFilterChange('billable', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].billable || 'Billable'}: {t[language].all || 'All'}</option>
            <option value="yes">{t[language].billable || 'Billable'}</option>
            <option value="no">{t[language].nonBillable || 'Non-billable'}</option>
          </select>
          
          <input type="date" value={expenseFilters.dateFrom}
            onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm" />
          
          <input type="date" value={expenseFilters.dateTo}
            onChange={(e) => handleFilterChange('dateTo', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm" />
          
          {hasActiveFilters && (
            <button onClick={clearFilters}
              className="px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-md border border-red-200">
              {t[language].clearFilters || 'Clear'}
            </button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].date}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].client}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].category}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].description}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].amount}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].paidBy || 'Paid By'}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].status}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {paginatedExpenses.length === 0 ? (
              <tr><td colSpan="8" className="px-6 py-8 text-center text-gray-500">
                {hasActiveFilters ? (language === 'ar' ? 'لا توجد نتائج للفلترة' : 'No results match filters') : t[language].noData}
              </td></tr>
            ) : (
              paginatedExpenses.map(exp => {
                const client = clients.find(c => c.client_id === exp.client_id);
                const category = expenseCategories.find(c => c.category_id === exp.category_id);
                return (
                  <tr key={exp.expense_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm">{formatDate(exp.date)}</td>
                    <td className="px-6 py-4 text-sm">{client?.client_name || '--'}</td>
                    <td className="px-6 py-4 text-sm">{language === 'ar' ? category?.name_ar : category?.name_en}</td>
                    <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">{exp.description}</td>
                    <td className="px-6 py-4 text-sm font-medium">
                      <span className={exp.billable ? 'text-green-700' : 'text-gray-500'}>
                        {exp.currency} {parseFloat(exp.amount).toFixed(2)}
                      </span>
                      {exp.billable && <span className="ml-1 text-xs text-green-600">●</span>}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      {exp.paid_by_firm === 1
                        ? (t[language].firm || 'Firm')
                        : exp.paid_by_lawyer_id
                          ? (lawyers.find(l => l.lawyer_id === exp.paid_by_lawyer_id)?.full_name || '--')
                          : '--'}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        exp.status === 'approved' ? 'bg-green-100 text-green-800' :
                        exp.status === 'billed' ? 'bg-blue-100 text-blue-800' :
                        exp.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-gray-100 text-gray-800'}`}>
                        {t[language][exp.status] || exp.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <button onClick={() => { setEditingExpense(exp); setShowExpenseForm(true); }}
                        className="text-blue-600 hover:text-blue-900 mr-3">{t[language].edit}</button>
                      <button onClick={() => {
                        showConfirm(
                          language === 'ar' ? 'حذف المصروف' : 'Delete Expense',
                          language === 'ar' ? 'هل أنت متأكد من حذف هذا المصروف؟' : 'Are you sure you want to delete this expense?',
                          async () => {
                            await electronAPI.deleteExpense(exp.expense_id);
                            await refreshExpenses();
                            showToast(language === 'ar' ? 'تم حذف المصروف' : 'Expense deleted');
                            hideConfirm();
                          }
                        );
                      }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {filteredExpenses.length > 0 && (
        <div className="flex items-center justify-between bg-white rounded-lg shadow px-4 py-3">
          <div className="text-sm text-gray-600">
            {t[language].showingOf || 'Showing'} {startIdx + 1}-{Math.min(startIdx + expensePageSize, filteredExpenses.length)} {t[language].of || 'of'} {filteredExpenses.length}
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">{t[language].show || 'Show'}:</span>
              <select value={expensePageSize}
                onChange={(e) => { setExpensePageSize(Number(e.target.value)); setExpensePage(1); }}
                className="px-2 py-1 border rounded text-sm">
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setExpensePage(p => Math.max(1, p - 1))}
                disabled={expensePage === 1}
                className="px-3 py-1 border rounded text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50">
                {t[language].prev || 'Prev'}
              </button>
              <span className="text-sm text-gray-600">
                {t[language].page || 'Page'} {expensePage} {t[language].of || 'of'} {totalPages || 1}
              </span>
              <button onClick={() => setExpensePage(p => Math.min(totalPages, p + 1))}
                disabled={expensePage >= totalPages}
                className="px-3 py-1 border rounded text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50">
                {t[language].next || 'Next'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpensesList;

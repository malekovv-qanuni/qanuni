import React, { useState, useMemo } from 'react';
import { Plus, ChevronDown, ChevronRight } from 'lucide-react';

/**
 * TasksList Component - v43.3
 * Table layout with columns matching TaskForm fields
 * 
 * Columns (matching form order):
 * Client | Matter | Title | Task Type | Due Date | Assigned To | Status | Actions
 * 
 * Features:
 * - Summary cards (Total, Overdue, Due Today, Upcoming)
 * - Inline column filters
 * - Collapsible grouped sections
 * - Pagination
 */

const formatDate = (dateStr) => {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleDateString('en-GB');
};

const TasksList = ({
  tasks,
  taskStatusFilter,
  setTaskStatusFilter,
  taskPriorityFilter,
  setTaskPriorityFilter,
  taskFilters,
  setTaskFilters,
  taskPage,
  setTaskPage,
  taskPageSize,
  setTaskPageSize,
  clients,
  matters,
  lawyers,
  taskTypes,
  language,
  t,
  setEditingTask,
  setShowTaskForm,
  showConfirm,
  showToast,
  hideConfirm,
  refreshTasks
}) => {
  const electronAPI = window.electronAPI;
  const today = new Date().toISOString().split('T')[0];
  const [collapsedSections, setCollapsedSections] = useState({});
  const [titleSearch, setTitleSearch] = useState('');
  
  // Filter matters by selected client
  const taskFilteredMatters = taskFilters.clientId 
    ? matters.filter(m => String(m.client_id) === String(taskFilters.clientId))
    : [];

  // Get client for a task (via matter)
  const getTaskClient = (task) => {
    const matter = matters.find(m => m.matter_id === task.matter_id);
    if (!matter) return null;
    return clients.find(c => c.client_id === matter.client_id);
  };

  // Apply all filters
  const filteredTasks = useMemo(() => {
    return tasks.filter(task => {
      if (taskStatusFilter !== 'all' && task.status !== taskStatusFilter) return false;
      if (taskPriorityFilter !== 'all' && task.priority !== taskPriorityFilter) return false;
      if (taskFilters.clientId) {
        const matter = matters.find(m => m.matter_id === task.matter_id);
        if (!matter || String(matter.client_id) !== String(taskFilters.clientId)) return false;
      }
      if (taskFilters.matterId && String(task.matter_id) !== String(taskFilters.matterId)) return false;
      if (taskFilters.lawyerId && String(task.assigned_to) !== String(taskFilters.lawyerId)) return false;
      if (taskFilters.taskTypeId && String(task.task_type_id) !== String(taskFilters.taskTypeId)) return false;
      if (taskFilters.dateFrom && task.due_date && task.due_date < taskFilters.dateFrom) return false;
      if (taskFilters.dateTo && task.due_date && task.due_date > taskFilters.dateTo) return false;
      if (titleSearch && !task.title?.toLowerCase().includes(titleSearch.toLowerCase())) return false;
      return true;
    });
  }, [tasks, taskStatusFilter, taskPriorityFilter, taskFilters, titleSearch, matters]);

  // Group tasks by status/date
  const groupedTasks = useMemo(() => {
    const overdue = filteredTasks.filter(t => t.status !== 'done' && t.status !== 'cancelled' && t.due_date && t.due_date < today);
    const dueToday = filteredTasks.filter(t => t.status !== 'done' && t.status !== 'cancelled' && t.due_date === today);
    const upcoming = filteredTasks.filter(t => t.status !== 'done' && t.status !== 'cancelled' && t.due_date && t.due_date > today);
    const noDueDate = filteredTasks.filter(t => t.status !== 'done' && t.status !== 'cancelled' && !t.due_date);
    const completed = filteredTasks.filter(t => t.status === 'done');
    const cancelled = filteredTasks.filter(t => t.status === 'cancelled');
    return { overdue, dueToday, upcoming, noDueDate, completed, cancelled };
  }, [filteredTasks, today]);

  // Counts for summary cards
  const counts = {
    total: tasks.length,
    filtered: filteredTasks.length,
    overdue: tasks.filter(t => t.status !== 'done' && t.status !== 'cancelled' && t.due_date && t.due_date < today).length,
    dueToday: tasks.filter(t => t.status !== 'done' && t.status !== 'cancelled' && t.due_date === today).length,
    upcoming: tasks.filter(t => t.status !== 'done' && t.status !== 'cancelled' && t.due_date && t.due_date > today).length,
    completed: tasks.filter(t => t.status === 'done').length
  };

  const handleTaskFilterChange = (field, value) => {
    setTaskFilters(prev => {
      const newFilters = { ...prev, [field]: value };
      if (field === 'clientId') newFilters.matterId = '';
      return newFilters;
    });
    if (setTaskPage) setTaskPage(1);
  };

  const clearAllTaskFilters = () => {
    setTaskStatusFilter('all');
    setTaskPriorityFilter('all');
    setTaskFilters({ clientId: '', matterId: '', lawyerId: '', taskTypeId: '', dateFrom: '', dateTo: '' });
    setTitleSearch('');
    if (setTaskPage) setTaskPage(1);
  };

  const hasActiveFilters = taskStatusFilter !== 'all' || taskPriorityFilter !== 'all' || 
    titleSearch !== '' || Object.values(taskFilters).some(v => v !== '');

  const toggleSection = (section) => {
    setCollapsedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const getStatusBadge = (status) => {
    const config = {
      done: { bg: 'bg-green-100', text: 'text-green-800', label: t[language].done || 'Done' },
      in_progress: { bg: 'bg-blue-100', text: 'text-blue-800', label: t[language].inProgress || 'In Progress' },
      review: { bg: 'bg-purple-100', text: 'text-purple-800', label: t[language].review || 'Review' },
      assigned: { bg: 'bg-gray-100', text: 'text-gray-800', label: t[language].assigned || 'Assigned' },
      cancelled: { bg: 'bg-red-100', text: 'text-red-800', label: t[language].cancelled || 'Cancelled' }
    };
    const c = config[status] || config.assigned;
    return <span className={`px-2 py-1 text-xs rounded-full ${c.bg} ${c.text}`}>{c.label}</span>;
  };

  const getPriorityDot = (priority) => {
    const colors = { high: 'bg-red-500', medium: 'bg-yellow-500', low: 'bg-green-500' };
    return <span className={`w-2 h-2 rounded-full inline-block ${colors[priority] || colors.medium}`}></span>;
  };

  // Table Header Row
  const TableHeader = () => (
    <thead className="bg-gray-50 border-b">
      <tr>
        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
          {t[language].client || 'Client'}
        </th>
        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
          {t[language].matter || 'Matter'}
        </th>
        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
          {t[language].taskTitle || 'Title'}
        </th>
        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
          {t[language].taskType || 'Type'}
        </th>
        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
          {t[language].dueDate || 'Due Date'}
        </th>
        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
          {t[language].assignedTo || 'Assigned To'}
        </th>
        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
          {t[language].status || 'Status'}
        </th>
        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
          {t[language].actions || 'Actions'}
        </th>
      </tr>
    </thead>
  );

  // Task Row
  const TaskRow = ({ task }) => {
    const matter = matters.find(m => m.matter_id === task.matter_id);
    const client = getTaskClient(task);
    const taskType = taskTypes.find(tt => tt.task_type_id === task.task_type_id);
    const isOverdue = task.status !== 'done' && task.status !== 'cancelled' && task.due_date && task.due_date < today;

    return (
      <tr className={`hover:bg-gray-50 ${isOverdue ? 'bg-red-50' : ''}`}>
        <td className="px-4 py-3 text-sm">
          {client?.client_name || <span className="text-gray-400">--</span>}
        </td>
        <td className="px-4 py-3 text-sm">
          {matter?.matter_name || <span className="text-gray-400">--</span>}
        </td>
        <td className="px-4 py-3">
          <div className="flex items-center gap-2">
            {getPriorityDot(task.priority)}
            <div>
              <div className="font-medium text-sm">{task.title}</div>
              <div className="text-xs text-gray-400">{task.task_number}</div>
            </div>
          </div>
        </td>
        <td className="px-4 py-3 text-sm">
          {language === 'ar' ? (taskType?.name_ar || taskType?.name_en || '--') : (taskType?.name_en || '--')}
        </td>
        <td className="px-4 py-3 text-sm">
          <span className={isOverdue ? 'text-red-600 font-medium' : ''}>
            {formatDate(task.due_date) || <span className="text-gray-400">--</span>}
          </span>
        </td>
        <td className="px-4 py-3 text-sm">
          {task.assigned_lawyer_name || <span className="text-gray-400">--</span>}
        </td>
        <td className="px-4 py-3">
          {getStatusBadge(task.status)}
        </td>
        <td className="px-4 py-3 text-sm">
          <button onClick={() => { setEditingTask(task); setShowTaskForm(true); }}
            className="text-blue-600 hover:text-blue-900 mr-3">{t[language].edit}</button>
          <button onClick={() => {
            showConfirm(
              language === 'ar' ? 'حذف المهمة' : 'Delete Task',
              language === 'ar' ? 'هل أنت متأكد من حذف هذه المهمة؟' : 'Are you sure you want to delete this task?',
              async () => {
                await electronAPI.deleteTask(task.task_id);
                await refreshTasks();
                showToast(language === 'ar' ? 'تم حذف المهمة' : 'Task deleted');
                hideConfirm();
              }
            );
          }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
        </td>
      </tr>
    );
  };

  // Section Component
  const TaskSection = ({ id, title, tasks: sectionTasks, bgColor, textColor, borderColor }) => {
    if (sectionTasks.length === 0) return null;
    const isCollapsed = collapsedSections[id];

    return (
      <div className="bg-white rounded-lg shadow overflow-hidden mb-4">
        <button 
          onClick={() => toggleSection(id)}
          className={`w-full flex items-center justify-between px-4 py-3 ${bgColor} border-b ${borderColor}`}>
          <div className="flex items-center gap-2">
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            <h3 className={`font-semibold ${textColor}`}>{title} ({sectionTasks.length})</h3>
          </div>
          <span className="text-xs text-gray-500">
            {isCollapsed ? (language === 'ar' ? 'عرض' : 'Show') : (language === 'ar' ? 'إخفاء' : 'Hide')}
          </span>
        </button>
        {!isCollapsed && (
          <table className="w-full">
            <TableHeader />
            <tbody className="divide-y divide-gray-200">
              {sectionTasks.map(task => <TaskRow key={task.task_id} task={task} />)}
            </tbody>
          </table>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t[language].tasks}</h2>
        <button onClick={() => setShowTaskForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          <Plus className="w-5 h-5" /> {t[language].addTask}
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-5 gap-4">
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].total || 'Total'}</div>
          <div className="text-2xl font-bold text-gray-800">{counts.filtered}</div>
          <div className="text-xs text-gray-400">{counts.total} {language === 'ar' ? 'إجمالي' : 'total'}</div>
        </div>
        <div className={`bg-white rounded-lg shadow p-4 cursor-pointer hover:shadow-md transition ${taskStatusFilter === 'overdue' ? 'ring-2 ring-red-500' : ''}`}
          onClick={() => setTaskStatusFilter(taskStatusFilter === 'overdue' ? 'all' : 'overdue')}>
          <div className="text-sm text-gray-500">{t[language].overdue || 'Overdue'}</div>
          <div className="text-2xl font-bold text-red-600">{counts.overdue}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].dueToday || 'Due Today'}</div>
          <div className="text-2xl font-bold text-orange-600">{counts.dueToday}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].upcoming || 'Upcoming'}</div>
          <div className="text-2xl font-bold text-blue-600">{counts.upcoming}</div>
        </div>
        <div className={`bg-white rounded-lg shadow p-4 cursor-pointer hover:shadow-md transition ${taskStatusFilter === 'done' ? 'ring-2 ring-green-500' : ''}`}
          onClick={() => setTaskStatusFilter(taskStatusFilter === 'done' ? 'all' : 'done')}>
          <div className="text-sm text-gray-500">{t[language].completed || 'Completed'}</div>
          <div className="text-2xl font-bold text-green-600">{counts.completed}</div>
        </div>
      </div>

      {/* Filter Bar - Matching Column Order */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-9 gap-3 items-end">
          {/* Client */}
          <select value={taskFilters.clientId}
            onChange={(e) => handleTaskFilterChange('clientId', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].allClients || 'All Clients'}</option>
            {clients.map(c => <option key={c.client_id} value={c.client_id}>{c.client_name}</option>)}
          </select>
          
          {/* Matter */}
          <select value={taskFilters.matterId}
            onChange={(e) => handleTaskFilterChange('matterId', e.target.value)}
            disabled={!taskFilters.clientId}
            className="px-3 py-2 border rounded-md text-sm disabled:bg-gray-100">
            <option value="">{t[language].allMatters || 'All Matters'}</option>
            {taskFilteredMatters.map(m => <option key={m.matter_id} value={m.matter_id}>{m.matter_name}</option>)}
          </select>
          
          {/* Title Search */}
          <input type="text" value={titleSearch}
            onChange={(e) => setTitleSearch(e.target.value)}
            placeholder={t[language].searchTitle || 'Search title...'}
            className="px-3 py-2 border rounded-md text-sm" />
          
          {/* Task Type */}
          <select value={taskFilters.taskTypeId || ''}
            onChange={(e) => handleTaskFilterChange('taskTypeId', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].allTypes || 'All Types'}</option>
            {taskTypes.map(tt => (
              <option key={tt.task_type_id} value={tt.task_type_id}>
                {language === 'ar' ? (tt.name_ar || tt.name_en) : tt.name_en}
              </option>
            ))}
          </select>
          
          {/* Date From */}
          <input type="date" value={taskFilters.dateFrom}
            onChange={(e) => handleTaskFilterChange('dateFrom', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm"
            title={t[language].from || 'From'} />
          
          {/* Date To */}
          <input type="date" value={taskFilters.dateTo}
            onChange={(e) => handleTaskFilterChange('dateTo', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm"
            title={t[language].to || 'To'} />
          
          {/* Assigned To */}
          <select value={taskFilters.lawyerId}
            onChange={(e) => handleTaskFilterChange('lawyerId', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].allLawyers || 'All Lawyers'}</option>
            {lawyers.map(l => <option key={l.lawyer_id} value={l.lawyer_id}>{l.full_name || l.name}</option>)}
          </select>
          
          {/* Status */}
          <select value={taskStatusFilter}
            onChange={(e) => setTaskStatusFilter(e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="all">{t[language].allStatuses || 'All Statuses'}</option>
            <option value="assigned">{t[language].assigned || 'Assigned'}</option>
            <option value="in_progress">{t[language].inProgress || 'In Progress'}</option>
            <option value="review">{t[language].review || 'Review'}</option>
            <option value="done">{t[language].done || 'Done'}</option>
            <option value="cancelled">{t[language].cancelled || 'Cancelled'}</option>
          </select>
          
          {/* Clear Filters */}
          {hasActiveFilters && (
            <button onClick={clearAllTaskFilters}
              className="px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-md border border-red-200">
              {t[language].clearFilters || 'Clear'}
            </button>
          )}
        </div>
        
        {/* Priority Filter - Secondary Row */}
        <div className="mt-3 flex items-center gap-4">
          <span className="text-sm text-gray-500">{t[language].priority || 'Priority'}:</span>
          <div className="flex gap-2">
            {['all', 'high', 'medium', 'low'].map(p => (
              <button key={p}
                onClick={() => setTaskPriorityFilter(p)}
                className={`px-3 py-1 text-xs rounded-full border transition ${
                  taskPriorityFilter === p 
                    ? p === 'high' ? 'bg-red-100 border-red-300 text-red-700'
                      : p === 'medium' ? 'bg-yellow-100 border-yellow-300 text-yellow-700'
                      : p === 'low' ? 'bg-green-100 border-green-300 text-green-700'
                      : 'bg-gray-200 border-gray-300 text-gray-700'
                    : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                }`}>
                {p === 'all' ? (t[language].all || 'All') : (t[language][p] || p)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Task Sections */}
      {filteredTasks.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-8 text-center text-gray-500">
          {hasActiveFilters 
            ? (language === 'ar' ? 'لا توجد نتائج للفلترة' : 'No results match filters') 
            : (t[language].noData || 'No tasks')}
        </div>
      ) : (
        <>
          <TaskSection 
            id="overdue" 
            title={t[language].overdue || 'Overdue'} 
            tasks={groupedTasks.overdue}
            bgColor="bg-red-50" 
            textColor="text-red-800" 
            borderColor="border-red-100" 
          />
          
          <TaskSection 
            id="dueToday" 
            title={t[language].dueToday || 'Due Today'} 
            tasks={groupedTasks.dueToday}
            bgColor="bg-orange-50" 
            textColor="text-orange-800" 
            borderColor="border-orange-100" 
          />
          
          <TaskSection 
            id="upcoming" 
            title={t[language].upcoming || 'Upcoming'} 
            tasks={[...groupedTasks.upcoming, ...groupedTasks.noDueDate]}
            bgColor="bg-blue-50" 
            textColor="text-blue-800" 
            borderColor="border-blue-100" 
          />
          
          <TaskSection 
            id="completed" 
            title={t[language].completed || 'Completed'} 
            tasks={groupedTasks.completed}
            bgColor="bg-green-50" 
            textColor="text-green-800" 
            borderColor="border-green-100" 
          />
          
          {groupedTasks.cancelled.length > 0 && (
            <TaskSection 
              id="cancelled" 
              title={t[language].cancelled || 'Cancelled'} 
              tasks={groupedTasks.cancelled}
              bgColor="bg-gray-50" 
              textColor="text-gray-800" 
              borderColor="border-gray-200" 
            />
          )}
        </>
      )}

      {/* Results Summary */}
      <div className="text-sm text-gray-500 text-center">
        {language === 'ar' ? 'عرض' : 'Showing'} {filteredTasks.length} {language === 'ar' ? 'من' : 'of'} {counts.total} {language === 'ar' ? 'مهمة' : 'tasks'}
      </div>
    </div>
  );
};

export default TasksList;

import React from 'react';
import { Plus } from 'lucide-react';

/**
 * TimesheetsList Component
 * Displays timesheets with filters, summary cards, and pagination
 * 
 * Extracted from App.js v42.7
 */

// Utility function
const formatDate = (dateStr) => {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleDateString('en-GB');
};

const TimesheetsList = ({
  timesheets,
  timesheetFilters,
  setTimesheetFilters,
  timesheetPage,
  setTimesheetPage,
  timesheetPageSize,
  setTimesheetPageSize,
  clients,
  matters,
  lawyers,
  language,
  t,
  setEditingTimesheet,
  setShowTimesheetForm,
  showConfirm,
  showToast,
  hideConfirm,
  refreshTimesheets
}) => {
  const electronAPI = window.electronAPI;
  // Filter timesheets
  const filteredTimesheets = timesheets.filter(ts => {
    if (timesheetFilters.clientId && ts.client_id !== timesheetFilters.clientId) return false;
    if (timesheetFilters.matterId && ts.matter_id !== timesheetFilters.matterId) return false;
    if (timesheetFilters.lawyerId && ts.lawyer_id !== timesheetFilters.lawyerId) return false;
    if (timesheetFilters.billable === 'yes' && !ts.billable) return false;
    if (timesheetFilters.billable === 'no' && ts.billable) return false;
    if (timesheetFilters.dateFrom && ts.date < timesheetFilters.dateFrom) return false;
    if (timesheetFilters.dateTo && ts.date > timesheetFilters.dateTo) return false;
    return true;
  });

  // Pagination
  const totalPages = Math.ceil(filteredTimesheets.length / timesheetPageSize);
  const startIdx = (timesheetPage - 1) * timesheetPageSize;
  const paginatedTimesheets = filteredTimesheets.slice(startIdx, startIdx + timesheetPageSize);

  // Calculate totals for filtered timesheets (in hours)
  const timesheetTotals = filteredTimesheets.reduce((acc, ts) => {
    const hours = (ts.minutes || 0) / 60;
    acc.total += hours;
    if (ts.billable) acc.billable += hours;
    else acc.nonBillable += hours;
    return acc;
  }, { total: 0, billable: 0, nonBillable: 0 });

  // Filter matters by selected client
  const filteredMatters = timesheetFilters.clientId 
    ? matters.filter(m => m.client_id === timesheetFilters.clientId)
    : [];

  const handleFilterChange = (field, value) => {
    setTimesheetFilters(prev => {
      const newFilters = { ...prev, [field]: value };
      if (field === 'clientId') newFilters.matterId = '';
      return newFilters;
    });
    setTimesheetPage(1);
  };

  const clearFilters = () => {
    setTimesheetFilters({ clientId: '', matterId: '', lawyerId: '', billable: '', dateFrom: '', dateTo: '' });
    setTimesheetPage(1);
  };

  const hasActiveFilters = Object.values(timesheetFilters).some(v => v !== '');

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t[language].timesheets}</h2>
        <button onClick={() => { setEditingTimesheet(null); setShowTimesheetForm(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          <Plus className="w-5 h-5" /> {t[language].addTimesheet}
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].totalHours || 'Total Hours'}</div>
          <div className="text-2xl font-bold text-gray-800">{timesheetTotals.total.toFixed(1)}h</div>
          <div className="text-xs text-gray-400">{filteredTimesheets.length} {language === 'ar' ? 'سجل' : 'entries'}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].billableHours || 'Billable Hours'}</div>
          <div className="text-2xl font-bold text-green-600">{timesheetTotals.billable.toFixed(1)}h</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].nonBillableHours || 'Non-billable Hours'}</div>
          <div className="text-2xl font-bold text-gray-500">{timesheetTotals.nonBillable.toFixed(1)}h</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
          <select value={timesheetFilters.clientId}
            onChange={(e) => handleFilterChange('clientId', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].allClients || 'All Clients'}</option>
            {clients.map(c => (
              <option key={c.client_id} value={c.client_id}>{c.client_name}</option>
            ))}
          </select>
          
          <select value={timesheetFilters.matterId}
            onChange={(e) => handleFilterChange('matterId', e.target.value)}
            disabled={!timesheetFilters.clientId}
            className="px-3 py-2 border rounded-md text-sm disabled:bg-gray-100">
            <option value="">{t[language].allMatters || 'All Matters'}</option>
            {filteredMatters.map(m => (
              <option key={m.matter_id} value={m.matter_id}>{m.matter_name}</option>
            ))}
          </select>
          
          <select value={timesheetFilters.lawyerId}
            onChange={(e) => handleFilterChange('lawyerId', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].allLawyers || 'All Lawyers'}</option>
            {lawyers.map(l => (
              <option key={l.lawyer_id} value={l.lawyer_id}>{l.full_name || l.name}</option>
            ))}
          </select>
          
          <select value={timesheetFilters.billable}
            onChange={(e) => handleFilterChange('billable', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].billable || 'Billable'}: {t[language].all || 'All'}</option>
            <option value="yes">{t[language].billable || 'Billable'}</option>
            <option value="no">{t[language].nonBillable || 'Non-billable'}</option>
          </select>
          
          <input type="date" value={timesheetFilters.dateFrom}
            onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm" />
          
          <input type="date" value={timesheetFilters.dateTo}
            onChange={(e) => handleFilterChange('dateTo', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm" />
          
          {hasActiveFilters && (
            <button onClick={clearFilters}
              className="px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-md border border-red-200">
              {t[language].clearFilters || 'Clear'}
            </button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].date}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].lawyer}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].client}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].matter}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].hours}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].billable}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].amount}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {paginatedTimesheets.length === 0 ? (
              <tr><td colSpan="8" className="px-6 py-8 text-center text-gray-500">
                {hasActiveFilters ? (language === 'ar' ? 'لا توجد نتائج للفلترة' : 'No results match filters') : t[language].noData}
              </td></tr>
            ) : (
              paginatedTimesheets.map(ts => {
                const client = clients.find(c => c.client_id === ts.client_id);
                const matter = matters.find(m => m.matter_id === ts.matter_id);
                const lawyer = lawyers.find(l => l.lawyer_id === ts.lawyer_id);
                const hours = (ts.minutes / 60).toFixed(2);
                const amount = ts.rate_per_hour ? (hours * ts.rate_per_hour).toFixed(2) : '0.00';
                return (
                  <tr key={ts.timesheet_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm">{formatDate(ts.date)}</td>
                    <td className="px-6 py-4 text-sm">{lawyer?.full_name || ts.lawyer_name || '--'}</td>
                    <td className="px-6 py-4 text-sm">{client?.client_name || 'N/A'}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">{matter?.matter_name || '--'}</td>
                    <td className="px-6 py-4 text-sm">{hours}h</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 text-xs rounded-full ${ts.billable ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                        {ts.billable ? t[language].billable : t[language].nonBillable}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm font-medium">${amount}</td>
                    <td className="px-6 py-4 text-sm">
                      {ts.status !== 'billed' && (
                        <>
                          <button onClick={() => { setEditingTimesheet(ts); setShowTimesheetForm(true); }}
                            className="text-blue-600 hover:text-blue-900 mr-3">{t[language].edit}</button>
                          <button onClick={() => {
                            showConfirm(
                              language === 'ar' ? 'حذف سجل الوقت' : 'Delete Timesheet',
                              language === 'ar' ? 'هل أنت متأكد من حذف هذا السجل؟' : 'Are you sure you want to delete this timesheet?',
                              async () => {
                                await electronAPI.deleteTimesheet(ts.timesheet_id);
                                await refreshTimesheets();
                                showToast(language === 'ar' ? 'تم حذف سجل الوقت' : 'Timesheet deleted');
                                hideConfirm();
                              }
                            );
                          }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
                        </>
                      )}
                      {ts.status === 'billed' && <span className="text-gray-400">Billed</span>}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {filteredTimesheets.length > 0 && (
        <div className="flex items-center justify-between bg-white rounded-lg shadow px-4 py-3">
          <div className="text-sm text-gray-600">
            {t[language].showingOf || 'Showing'} {startIdx + 1}-{Math.min(startIdx + timesheetPageSize, filteredTimesheets.length)} {t[language].of || 'of'} {filteredTimesheets.length}
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">{t[language].show || 'Show'}:</span>
              <select value={timesheetPageSize}
                onChange={(e) => { setTimesheetPageSize(Number(e.target.value)); setTimesheetPage(1); }}
                className="px-2 py-1 border rounded text-sm">
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setTimesheetPage(p => Math.max(1, p - 1))}
                disabled={timesheetPage === 1}
                className="px-3 py-1 border rounded text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50">
                {t[language].prev || 'Prev'}
              </button>
              <span className="text-sm text-gray-600">
                {t[language].page || 'Page'} {timesheetPage} {t[language].of || 'of'} {totalPages || 1}
              </span>
              <button onClick={() => setTimesheetPage(p => Math.min(totalPages, p + 1))}
                disabled={timesheetPage >= totalPages}
                className="px-3 py-1 border rounded text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50">
                {t[language].next || 'Next'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TimesheetsList;

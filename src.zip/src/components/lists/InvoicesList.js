import React from 'react';
import { Plus } from 'lucide-react';
import { EmptyState } from '../common';

/**
 * InvoicesList Component
 * Displays invoices with filters, summary cards, and pagination
 * 
 * Extracted from App.js v42.8
 */

const formatDate = (dateStr) => {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleDateString('en-GB');
};

const InvoicesList = ({
  invoices,
  invoiceFilters,
  setInvoiceFilters,
  invoicePage,
  setInvoicePage,
  invoicePageSize,
  setInvoicePageSize,
  clients,
  matters,
  language,
  t,
  setEditingInvoice,
  setShowInvoiceForm,
  setViewingInvoice,
  showConfirm,
  showToast,
  hideConfirm,
  refreshInvoices
}) => {
  // Filter invoices
  const filteredInvoices = invoices.filter(inv => {
    if (invoiceFilters.clientId && String(inv.client_id) !== String(invoiceFilters.clientId)) return false;
    if (invoiceFilters.matterId && String(inv.matter_id) !== String(invoiceFilters.matterId)) return false;
    if (invoiceFilters.status && inv.status !== invoiceFilters.status) return false;
    const dateField = invoiceFilters.dateType === 'due' ? inv.due_date : inv.issue_date;
    if (invoiceFilters.dateFrom && dateField && dateField < invoiceFilters.dateFrom) return false;
    if (invoiceFilters.dateTo && dateField && dateField > invoiceFilters.dateTo) return false;
    return true;
  });

  // Pagination
  const totalPages = Math.ceil(filteredInvoices.length / invoicePageSize);
  const startIdx = (invoicePage - 1) * invoicePageSize;
  const paginatedInvoices = filteredInvoices.slice(startIdx, startIdx + invoicePageSize);

  // Calculate totals
  const invoiceTotals = filteredInvoices.reduce((acc, inv) => {
    const amount = parseFloat(inv.total) || 0;
    acc.total += amount;
    if (inv.status === 'paid') acc.paid += amount;
    else if (inv.status !== 'cancelled' && inv.status !== 'draft') acc.outstanding += amount;
    if (inv.status === 'overdue') acc.overdueCount++;
    return acc;
  }, { total: 0, paid: 0, outstanding: 0, overdueCount: 0 });

  // Filter matters by selected client
  const invoiceFilteredMatters = invoiceFilters.clientId 
    ? matters.filter(m => String(m.client_id) === String(invoiceFilters.clientId))
    : [];

  const handleFilterChange = (field, value) => {
    setInvoiceFilters(prev => {
      const newFilters = { ...prev, [field]: value };
      if (field === 'clientId') newFilters.matterId = '';
      return newFilters;
    });
    setInvoicePage(1);
  };

  const clearFilters = () => {
    setInvoiceFilters({ clientId: '', matterId: '', status: '', dateType: 'issue', dateFrom: '', dateTo: '' });
    setInvoicePage(1);
  };

  const hasActiveFilters = invoiceFilters.clientId || invoiceFilters.matterId || 
    invoiceFilters.status || invoiceFilters.dateFrom || invoiceFilters.dateTo;

  // Show empty state when no invoices exist
  if (invoices.length === 0) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">{t[language].invoices}</h2>
        </div>
        <div className="bg-white rounded-lg shadow">
          <EmptyState
            type="invoices"
            title={t[language].emptyInvoices}
            description={t[language].emptyInvoicesDesc}
            actionLabel={t[language].createInvoice}
            onAction={() => setShowInvoiceForm(true)}
          />
        </div>
      </div>
    );
  }

  const statusColors = {
    draft: 'bg-gray-100 text-gray-800',
    sent: 'bg-blue-100 text-blue-800',
    viewed: 'bg-purple-100 text-purple-800',
    partial: 'bg-yellow-100 text-yellow-800',
    paid: 'bg-green-100 text-green-800',
    overdue: 'bg-red-100 text-red-800',
    cancelled: 'bg-gray-100 text-gray-800'
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t[language].invoices}</h2>
        <button onClick={() => setShowInvoiceForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          <Plus className="w-5 h-5" /> {t[language].createInvoice}
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].totalInvoiced || 'Total Invoiced'}</div>
          <div className="text-2xl font-bold text-gray-800">${invoiceTotals.total.toFixed(2)}</div>
          <div className="text-xs text-gray-400">{filteredInvoices.length} {language === 'ar' ? 'فاتورة' : 'invoices'}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].paid || 'Paid'}</div>
          <div className="text-2xl font-bold text-green-600">${invoiceTotals.paid.toFixed(2)}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].outstanding || 'Outstanding'}</div>
          <div className="text-2xl font-bold text-blue-600">${invoiceTotals.outstanding.toFixed(2)}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-500">{t[language].overdue || 'Overdue'}</div>
          <div className="text-2xl font-bold text-red-600">{invoiceTotals.overdueCount}</div>
          <div className="text-xs text-gray-400">{language === 'ar' ? 'فواتير متأخرة' : 'overdue invoices'}</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
          <select value={invoiceFilters.clientId}
            onChange={(e) => handleFilterChange('clientId', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].allClients || 'All Clients'}</option>
            {clients.map(c => (
              <option key={c.client_id} value={c.client_id}>{c.client_name}</option>
            ))}
          </select>
          
          <select value={invoiceFilters.matterId}
            onChange={(e) => handleFilterChange('matterId', e.target.value)}
            disabled={!invoiceFilters.clientId}
            className="px-3 py-2 border rounded-md text-sm disabled:bg-gray-100">
            <option value="">{t[language].allMatters || 'All Matters'}</option>
            {invoiceFilteredMatters.map(m => (
              <option key={m.matter_id} value={m.matter_id}>{m.matter_name}</option>
            ))}
          </select>
          
          <select value={invoiceFilters.status}
            onChange={(e) => handleFilterChange('status', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].allStatuses || 'All Statuses'}</option>
            <option value="draft">{t[language].draft || 'Draft'}</option>
            <option value="sent">{t[language].sent || 'Sent'}</option>
            <option value="viewed">{t[language].viewed || 'Viewed'}</option>
            <option value="partial">{t[language].partial || 'Partial'}</option>
            <option value="paid">{t[language].paid || 'Paid'}</option>
            <option value="overdue">{t[language].overdue || 'Overdue'}</option>
            <option value="cancelled">{t[language].cancelled || 'Cancelled'}</option>
          </select>
          
          <select value={invoiceFilters.dateType}
            onChange={(e) => handleFilterChange('dateType', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="issue">{t[language].issueDate || 'Issue Date'}</option>
            <option value="due">{t[language].dueDate || 'Due Date'}</option>
          </select>
          
          <input type="date" value={invoiceFilters.dateFrom}
            onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm"
            title={invoiceFilters.dateType === 'due' ? 'Due Date From' : 'Issue Date From'} />
          
          <input type="date" value={invoiceFilters.dateTo}
            onChange={(e) => handleFilterChange('dateTo', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm"
            title={invoiceFilters.dateType === 'due' ? 'Due Date To' : 'Issue Date To'} />
          
          {hasActiveFilters && (
            <button onClick={clearFilters}
              className="px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-md border border-red-200">
              {t[language].clearFilters || 'Clear'}
            </button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].invoiceNumber}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].client}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].issueDate}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].dueDate}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].total}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].status}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {paginatedInvoices.length === 0 ? (
              <tr><td colSpan="7" className="px-6 py-8 text-center text-gray-500">
                {hasActiveFilters ? (language === 'ar' ? 'لا توجد نتائج للفلترة' : 'No results match filters') : t[language].noData}
              </td></tr>
            ) : (
              paginatedInvoices.map(inv => {
                const client = clients.find(c => c.client_id === inv.client_id);
                return (
                  <tr key={inv.invoice_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-medium">{inv.invoice_number}</td>
                    <td className="px-6 py-4 text-sm">{client?.client_name || 'N/A'}</td>
                    <td className="px-6 py-4 text-sm">{formatDate(inv.issue_date)}</td>
                    <td className="px-6 py-4 text-sm">{inv.due_date ? formatDate(inv.due_date) : '--'}</td>
                    <td className="px-6 py-4 text-sm font-medium">{inv.currency} {parseFloat(inv.total).toFixed(2)}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 text-xs rounded-full ${statusColors[inv.status] || 'bg-gray-100'}`}>
                        {t[language][inv.status] || inv.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <button onClick={() => setViewingInvoice(inv)}
                        className="text-purple-600 hover:text-purple-900 mr-3">{t[language].viewInvoice}</button>
                      {inv.status === 'draft' && (
                        <>
                          <button onClick={() => { setEditingInvoice(inv); setShowInvoiceForm(true); }}
                            className="text-blue-600 hover:text-blue-900 mr-3">{t[language].edit}</button>
                          <button onClick={async () => {
                            await window.electronAPI.updateInvoiceStatus(inv.invoice_id, 'sent');
                            await refreshInvoices();
                            showToast(language === 'ar' ? 'تم وضع علامة مرسلة' : 'Invoice marked as sent');
                          }} className="text-green-600 hover:text-green-900 mr-3">{t[language].markAsSent}</button>
                        </>
                      )}
                      {(inv.status === 'sent' || inv.status === 'viewed' || inv.status === 'partial') && (
                        <button onClick={async () => {
                          await window.electronAPI.updateInvoiceStatus(inv.invoice_id, 'paid');
                          await refreshInvoices();
                          showToast(language === 'ar' ? 'تم وضع علامة مدفوعة' : 'Invoice marked as paid');
                        }} className="text-green-600 hover:text-green-900 mr-3">{t[language].markAsPaid}</button>
                      )}
                      <button onClick={() => {
                        showConfirm(
                          language === 'ar' ? 'حذف الفاتورة' : 'Delete Invoice',
                          language === 'ar' ? 'هل أنت متأكد من حذف هذه الفاتورة؟' : 'Are you sure you want to delete this invoice?',
                          async () => {
                            await window.electronAPI.deleteInvoice(inv.invoice_id);
                            await refreshInvoices();
                            showToast(language === 'ar' ? 'تم حذف الفاتورة' : 'Invoice deleted');
                            hideConfirm();
                          }
                        );
                      }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {filteredInvoices.length > 0 && (
        <div className="flex items-center justify-between bg-white rounded-lg shadow px-4 py-3">
          <div className="text-sm text-gray-600">
            {t[language].showingOf || 'Showing'} {startIdx + 1}-{Math.min(startIdx + invoicePageSize, filteredInvoices.length)} {t[language].of || 'of'} {filteredInvoices.length}
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">{t[language].show || 'Show'}:</span>
              <select value={invoicePageSize}
                onChange={(e) => { setInvoicePageSize(Number(e.target.value)); setInvoicePage(1); }}
                className="px-2 py-1 border rounded text-sm">
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setInvoicePage(p => Math.max(1, p - 1))}
                disabled={invoicePage === 1}
                className="px-3 py-1 border rounded text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50">
                {t[language].prev || 'Prev'}
              </button>
              <span className="text-sm text-gray-600">
                {t[language].page || 'Page'} {invoicePage} {t[language].of || 'of'} {totalPages || 1}
              </span>
              <button onClick={() => setInvoicePage(p => Math.min(totalPages, p + 1))}
                disabled={invoicePage >= totalPages}
                className="px-3 py-1 border rounded text-sm disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50">
                {t[language].next || 'Next'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InvoicesList;

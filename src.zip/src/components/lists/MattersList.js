import React from 'react';
import { Plus, Search } from 'lucide-react';
import { EmptyState } from '../common';

/**
 * MattersList Component
 * Displays a searchable list of matters with edit/delete actions
 * 
 * Extracted from App.js v42.0.5 to fix search focus bug
 * (Inner function components cause remount on parent state change)
 */
const MattersList = ({
  matters,
  clients,
  matterSearch,
  setMatterSearch,
  language,
  t,
  setShowMatterForm,
  setEditingMatter,
  showConfirm,
  showToast,
  hideConfirm,
  refreshMatters,
  electronAPI
}) => {
  // Filter matters based on search
  const filteredMatters = matterSearch.trim() === '' 
    ? matters 
    : matters.filter(m => {
        const client = clients.find(c => c.client_id === m.client_id);
        return (
          (m.matter_name || '').toLowerCase().includes(matterSearch.toLowerCase()) ||
          (m.matter_name_arabic || '').includes(matterSearch) ||
          (m.case_number || '').toLowerCase().includes(matterSearch.toLowerCase()) ||
          (client?.client_name || '').toLowerCase().includes(matterSearch.toLowerCase())
        );
      });

  // Show empty state when no matters exist
  if (matters.length === 0) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">{t[language].matters}</h2>
        </div>
        <div className="bg-white rounded-lg shadow">
          <EmptyState
            type="matters"
            title={t[language].emptyMatters}
            description={t[language].emptyMattersDesc}
            actionLabel={t[language].addMatter}
            onAction={() => setShowMatterForm(true)}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{t[language].matters}</h2>
        <button onClick={() => setShowMatterForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          <Plus className="w-5 h-5" /> {t[language].addMatter}
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            value={matterSearch}
            onChange={(e) => setMatterSearch(e.target.value)}
            placeholder={t[language].searchMatters || 'Search matters...'}
            className="w-full pl-10 pr-4 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        {matterSearch && (
          <p className="text-sm text-gray-500 mt-2">
            {t[language].showingOf || 'Showing'} {filteredMatters.length} {t[language].of || 'of'} {matters.length} {t[language].matters}
          </p>
        )}
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].matterName}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].client}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].matterType}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t[language].status}</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredMatters.length === 0 ? (
              <tr><td colSpan="5" className="px-6 py-8 text-center text-gray-500">{t[language].noData}</td></tr>
            ) : (
              filteredMatters.map(matter => {
                const client = clients.find(c => c.client_id === matter.client_id);
                return (
                  <tr key={matter.matter_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 font-medium">{matter.matter_name}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">{client?.client_name || 'N/A'}</td>
                    <td className="px-6 py-4 text-sm">{matter.matter_type}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        matter.status === 'active' ? 'bg-green-100 text-green-800' :
                        matter.status === 'closed' ? 'bg-gray-100 text-gray-800' :
                        matter.status === 'on_hold' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>{matter.status}</span>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <button onClick={() => { setEditingMatter(matter); setShowMatterForm(true); }}
                        className="text-blue-600 hover:text-blue-900 mr-3">{t[language].edit}</button>
                      <button onClick={() => {
                        showConfirm(
                          language === 'ar' ? 'حذف القضية' : 'Delete Matter',
                          language === 'ar' ? 'هل أنت متأكد من حذف هذه القضية؟' : 'Are you sure you want to delete this matter?',
                          async () => {
                            await electronAPI.deleteMatter(matter.matter_id);
                            await refreshMatters();
                            showToast(language === 'ar' ? 'تم حذف القضية' : 'Matter deleted');
                            hideConfirm();
                          }
                        );
                      }} className="text-red-600 hover:text-red-900">{t[language].delete}</button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MattersList;

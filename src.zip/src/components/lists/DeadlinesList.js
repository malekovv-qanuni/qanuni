import React, { useState, useMemo } from 'react';
import { CheckCircle, AlertTriangle, ExternalLink, Calendar, Clock, Gavel, FileText, ClipboardList, ChevronDown, ChevronRight } from 'lucide-react';
import { EmptyState } from '../common';

/**
 * DeadlinesList Component - v43.3
 * Pure read-only aggregated view with source grouping
 * 
 * v43.3 Changes:
 * - Added source type filter (All/Judgments/Tasks/Matters)
 * - Added grouped display with collapsible section headers
 * - Added color-coded source badges on each row
 * - Better visual distinction between source types
 */

const formatDate = (dateStr) => {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleDateString('en-GB');
};

const DeadlinesList = ({
  deadlines,
  deadlineFilters,
  setDeadlineFilters,
  deadlinePage,
  setDeadlinePage,
  deadlinePageSize,
  setDeadlinePageSize,
  clients,
  matters,
  judgments,
  tasks,
  language,
  t,
  onViewJudgment,
  onViewTask,
  onViewMatter
}) => {
  const [statusFilter, setStatusFilter] = useState('active');
  const [sourceFilter, setSourceFilter] = useState('all'); // 'all', 'judgment', 'task', 'matter'
  const [collapsedSections, setCollapsedSections] = useState({});
  
  const today = new Date().toISOString().split('T')[0];

  const getDaysUntil = (dateStr) => {
    const deadline = new Date(dateStr);
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    deadline.setHours(0, 0, 0, 0);
    return Math.ceil((deadline - now) / (1000 * 60 * 60 * 24));
  };

  const getWeekEnd = () => {
    const end = new Date();
    end.setDate(end.getDate() + 7);
    return end.toISOString().split('T')[0];
  };

  const weekEnd = getWeekEnd();

  // Determine source type
  const getSourceType = (deadline) => {
    if (deadline.judgment_id) return 'judgment';
    if (deadline.task_id) return 'task';
    return 'matter';
  };

  // Source info with styling
  const sourceConfig = {
    judgment: {
      icon: Gavel,
      label: language === 'ar' ? 'حكم' : 'Judgment',
      labelFull: language === 'ar' ? 'من الأحكام' : 'From Judgments',
      bgColor: 'bg-purple-100',
      textColor: 'text-purple-700',
      borderColor: 'border-purple-300'
    },
    task: {
      icon: ClipboardList,
      label: language === 'ar' ? 'مهمة' : 'Task',
      labelFull: language === 'ar' ? 'من المهام' : 'From Tasks',
      bgColor: 'bg-blue-100',
      textColor: 'text-blue-700',
      borderColor: 'border-blue-300'
    },
    matter: {
      icon: FileText,
      label: language === 'ar' ? 'ملف' : 'Matter',
      labelFull: language === 'ar' ? 'من الملفات' : 'From Matters',
      bgColor: 'bg-green-100',
      textColor: 'text-green-700',
      borderColor: 'border-green-300'
    }
  };

  const getSourceInfo = (deadline) => {
    const sourceType = getSourceType(deadline);
    const config = sourceConfig[sourceType];
    
    if (sourceType === 'judgment') {
      const judgment = judgments?.find(j => j.judgment_id === deadline.judgment_id);
      return { ...config, source: judgment, title: judgment?.judgment_type || deadline.title, 
               onClick: () => judgment && onViewJudgment?.(judgment) };
    }
    if (sourceType === 'task') {
      const task = tasks?.find(t => t.task_id === deadline.task_id);
      return { ...config, source: task, title: task?.title || deadline.title,
               onClick: () => task && onViewTask?.(task) };
    }
    const matter = matters?.find(m => m.matter_id === deadline.matter_id);
    return { ...config, source: matter, title: matter?.matter_name || deadline.title,
             onClick: () => matter && onViewMatter?.(matter) };
  };

  // Filter deadlines
  const filteredDeadlines = useMemo(() => {
    return deadlines
      .filter(d => {
        // Status filter
        if (statusFilter === 'active') return d.status !== 'completed';
        if (statusFilter === 'overdue') return d.status !== 'completed' && d.deadline_date < today;
        if (statusFilter === 'thisWeek') return d.status !== 'completed' && d.deadline_date >= today && d.deadline_date <= weekEnd;
        if (statusFilter === 'completed') return d.status === 'completed';
        return true;
      })
      .filter(d => {
        // Source filter
        if (sourceFilter === 'all') return true;
        return getSourceType(d) === sourceFilter;
      })
      .filter(d => {
        // Additional filters
        if (deadlineFilters.clientId && String(d.client_id) !== String(deadlineFilters.clientId)) return false;
        if (deadlineFilters.matterId && String(d.matter_id) !== String(deadlineFilters.matterId)) return false;
        if (deadlineFilters.priority && d.priority !== deadlineFilters.priority) return false;
        if (deadlineFilters.dateFrom && d.deadline_date < deadlineFilters.dateFrom) return false;
        if (deadlineFilters.dateTo && d.deadline_date > deadlineFilters.dateTo) return false;
        return true;
      })
      .sort((a, b) => {
        // Sort: overdue first, then by date
        const aOverdue = a.status !== 'completed' && a.deadline_date < today;
        const bOverdue = b.status !== 'completed' && b.deadline_date < today;
        if (aOverdue && !bOverdue) return -1;
        if (bOverdue && !aOverdue) return 1;
        return new Date(a.deadline_date) - new Date(b.deadline_date);
      });
  }, [deadlines, statusFilter, sourceFilter, deadlineFilters, today, weekEnd]);

  // Group by source type
  const groupedDeadlines = useMemo(() => {
    const groups = { judgment: [], task: [], matter: [] };
    filteredDeadlines.forEach(d => {
      groups[getSourceType(d)].push(d);
    });
    return groups;
  }, [filteredDeadlines]);

  // Counts
  const overdueCount = deadlines.filter(d => d.status !== 'completed' && d.deadline_date < today).length;
  const thisWeekCount = deadlines.filter(d => d.status !== 'completed' && d.deadline_date >= today && d.deadline_date <= weekEnd).length;
  const activeCount = deadlines.filter(d => d.status !== 'completed').length;
  const completedCount = deadlines.filter(d => d.status === 'completed').length;

  // Source counts
  const sourceCounts = {
    judgment: deadlines.filter(d => d.judgment_id).length,
    task: deadlines.filter(d => d.task_id).length,
    matter: deadlines.filter(d => !d.judgment_id && !d.task_id).length
  };

  const deadlineFilteredMatters = deadlineFilters.clientId 
    ? matters.filter(m => String(m.client_id) === String(deadlineFilters.clientId))
    : [];

  const handleFilterChange = (field, value) => {
    setDeadlineFilters(prev => {
      const newFilters = { ...prev, [field]: value };
      if (field === 'clientId') newFilters.matterId = '';
      return newFilters;
    });
    setDeadlinePage(1);
  };

  const clearFilters = () => {
    setDeadlineFilters({ clientId: '', matterId: '', priority: '', dateFrom: '', dateTo: '' });
    setSourceFilter('all');
    setDeadlinePage(1);
  };

  const hasActiveFilters = Object.values(deadlineFilters).some(v => v !== '') || sourceFilter !== 'all';

  const toggleSection = (section) => {
    setCollapsedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const getPriorityBadge = (priority) => {
    const config = { high: 'bg-red-500', medium: 'bg-yellow-500', low: 'bg-blue-500' };
    return <span className={`w-2 h-2 rounded-full ${config[priority] || config.medium}`}></span>;
  };

  const getStatusIcon = (deadline) => {
    const days = getDaysUntil(deadline.deadline_date);
    if (deadline.status === 'completed') return <CheckCircle className="w-5 h-5 text-green-500" />;
    if (days < 0) return <AlertTriangle className="w-5 h-5 text-red-500" />;
    if (days <= 7) return <Clock className="w-5 h-5 text-orange-500" />;
    return <Calendar className="w-5 h-5 text-gray-400" />;
  };

  const getDaysLabel = (deadline) => {
    const days = getDaysUntil(deadline.deadline_date);
    if (deadline.status === 'completed') return <span className="text-green-600">✓ {t[language].completed || 'Completed'}</span>;
    if (days < 0) return <span className="text-red-600 font-semibold">{Math.abs(days)} {t[language].daysOverdue || 'days overdue'}</span>;
    if (days === 0) return <span className="text-orange-600 font-semibold">{t[language].dueToday || 'Due today'}</span>;
    if (days <= 7) return <span className="text-yellow-600">{days} {t[language].daysRemaining || 'days'}</span>;
    return <span className="text-gray-600">{days} {t[language].days || 'days'}</span>;
  };

  // Render a single deadline row
  const renderDeadlineRow = (deadline) => {
    const matter = matters.find(m => m.matter_id === deadline.matter_id);
    const client = deadline.client_name || clients.find(c => c.client_id === deadline.client_id)?.client_name;
    const sourceInfo = getSourceInfo(deadline);
    const isOverdue = deadline.status !== 'completed' && deadline.deadline_date < today;
    const isCompleted = deadline.status === 'completed';
    const SourceIcon = sourceInfo.icon;

    return (
      <div 
        key={deadline.deadline_id} 
        className={`bg-white rounded-lg shadow-sm p-4 border-l-4 ${
          isCompleted ? 'border-green-500 opacity-70' :
          isOverdue ? 'border-red-500' :
          getDaysUntil(deadline.deadline_date) <= 7 ? 'border-orange-500' :
          'border-blue-500'
        }`}>
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            {getStatusIcon(deadline)}
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                {getPriorityBadge(deadline.priority)}
                <span className={`font-medium ${isCompleted ? 'line-through text-gray-500' : ''}`}>
                  {deadline.title || (language === 'ar' ? 'موعد نهائي' : 'Deadline')}
                </span>
                {/* Source Badge */}
                <span className={`text-xs px-2 py-0.5 rounded-full ${sourceInfo.bgColor} ${sourceInfo.textColor}`}>
                  {sourceInfo.label}
                </span>
              </div>
              <div className="text-sm text-gray-600 mt-1">
                {matter?.matter_name || deadline.matter_name || '-'} • {client || '-'}
              </div>
              
              {/* Source Link */}
              {sourceInfo.source && sourceInfo.onClick && (
                <button 
                  onClick={sourceInfo.onClick}
                  className={`text-xs mt-2 flex items-center gap-1 hover:underline ${sourceInfo.bgColor} ${sourceInfo.textColor} px-2 py-1 rounded border ${sourceInfo.borderColor}`}>
                  <SourceIcon className="w-3 h-3" />
                  {language === 'ar' ? 'عرض' : 'View'}: {sourceInfo.title}
                  <ExternalLink className="w-3 h-3 ml-1" />
                </button>
              )}
              
              {deadline.notes && <p className="text-xs text-gray-500 mt-1">{deadline.notes}</p>}
            </div>
          </div>
          
          <div className="text-right">
            <div className="font-medium">{formatDate(deadline.deadline_date)}</div>
            <div className="text-sm mt-1">{getDaysLabel(deadline)}</div>
          </div>
        </div>
      </div>
    );
  };

  // Render a section with header
  const renderSection = (sourceType, items) => {
    if (items.length === 0) return null;
    const config = sourceConfig[sourceType];
    const isCollapsed = collapsedSections[sourceType];
    const Icon = config.icon;

    return (
      <div key={sourceType} className="mb-6">
        {/* Section Header */}
        <button 
          onClick={() => toggleSection(sourceType)}
          className={`w-full flex items-center justify-between p-3 rounded-lg mb-2 ${config.bgColor} hover:opacity-90 transition`}>
          <div className="flex items-center gap-2">
            {isCollapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
            <Icon className={`w-5 h-5 ${config.textColor}`} />
            <span className={`font-semibold ${config.textColor}`}>
              {config.labelFull}
            </span>
            <span className={`text-sm px-2 py-0.5 rounded-full bg-white ${config.textColor}`}>
              {items.length}
            </span>
          </div>
          <span className="text-xs text-gray-500">
            {isCollapsed ? (language === 'ar' ? 'عرض' : 'Show') : (language === 'ar' ? 'إخفاء' : 'Hide')}
          </span>
        </button>
        
        {/* Section Content */}
        {!isCollapsed && (
          <div className="space-y-2 ml-2">
            {items.map(deadline => renderDeadlineRow(deadline))}
          </div>
        )}
      </div>
    );
  };

  // Empty state
  if (deadlines.length === 0) {
    return (
      <div>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">{t[language].deadlines}</h2>
        </div>
        <EmptyState
          type="tasks"
          title={t[language].emptyDeadlines || 'No Deadlines'}
          description={t[language].emptyDeadlinesDesc || 'Deadlines are automatically created from Judgments and Tasks'}
        />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">{t[language].deadlines}</h2>
          <p className="text-sm text-gray-500 mt-1">
            {language === 'ar' ? 'عرض مجمّع - انقر على المصدر للتعديل' : 'Aggregated view - click source to edit'}
          </p>
        </div>
      </div>

      {/* Summary Cards Row 1: Status */}
      <div className="grid grid-cols-4 gap-4">
        <div onClick={() => { setStatusFilter('overdue'); setDeadlinePage(1); }}
          className={`bg-white rounded-lg shadow p-4 cursor-pointer transition hover:shadow-md ${statusFilter === 'overdue' ? 'ring-2 ring-red-500' : ''}`}>
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            <span className="text-sm text-gray-500">{t[language].overdueDeadlines || 'Overdue'}</span>
          </div>
          <div className="text-2xl font-bold text-red-600 mt-1">{overdueCount}</div>
        </div>
        <div onClick={() => { setStatusFilter('thisWeek'); setDeadlinePage(1); }}
          className={`bg-white rounded-lg shadow p-4 cursor-pointer transition hover:shadow-md ${statusFilter === 'thisWeek' ? 'ring-2 ring-orange-500' : ''}`}>
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-orange-500" />
            <span className="text-sm text-gray-500">{t[language].thisWeek || 'This Week'}</span>
          </div>
          <div className="text-2xl font-bold text-orange-600 mt-1">{thisWeekCount}</div>
        </div>
        <div onClick={() => { setStatusFilter('active'); setDeadlinePage(1); }}
          className={`bg-white rounded-lg shadow p-4 cursor-pointer transition hover:shadow-md ${statusFilter === 'active' ? 'ring-2 ring-blue-500' : ''}`}>
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-500" />
            <span className="text-sm text-gray-500">{t[language].active || 'Active'}</span>
          </div>
          <div className="text-2xl font-bold text-blue-600 mt-1">{activeCount}</div>
        </div>
        <div onClick={() => { setStatusFilter('completed'); setDeadlinePage(1); }}
          className={`bg-white rounded-lg shadow p-4 cursor-pointer transition hover:shadow-md ${statusFilter === 'completed' ? 'ring-2 ring-green-500' : ''}`}>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-500" />
            <span className="text-sm text-gray-500">{t[language].completed || 'Completed'}</span>
          </div>
          <div className="text-2xl font-bold text-green-600 mt-1">{completedCount}</div>
        </div>
      </div>

      {/* Summary Cards Row 2: Source Type Filter */}
      <div className="grid grid-cols-4 gap-4">
        <div onClick={() => setSourceFilter('all')}
          className={`bg-white rounded-lg shadow p-3 cursor-pointer transition hover:shadow-md ${sourceFilter === 'all' ? 'ring-2 ring-gray-500' : ''}`}>
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-gray-700">{language === 'ar' ? 'الكل' : 'All Sources'}</span>
            <span className="text-lg font-bold text-gray-600">{deadlines.length}</span>
          </div>
        </div>
        <div onClick={() => setSourceFilter('judgment')}
          className={`${sourceConfig.judgment.bgColor} rounded-lg shadow p-3 cursor-pointer transition hover:shadow-md ${sourceFilter === 'judgment' ? 'ring-2 ring-purple-500' : ''}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gavel className={`w-4 h-4 ${sourceConfig.judgment.textColor}`} />
              <span className={`text-sm font-medium ${sourceConfig.judgment.textColor}`}>{sourceConfig.judgment.label}</span>
            </div>
            <span className={`text-lg font-bold ${sourceConfig.judgment.textColor}`}>{sourceCounts.judgment}</span>
          </div>
        </div>
        <div onClick={() => setSourceFilter('task')}
          className={`${sourceConfig.task.bgColor} rounded-lg shadow p-3 cursor-pointer transition hover:shadow-md ${sourceFilter === 'task' ? 'ring-2 ring-blue-500' : ''}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ClipboardList className={`w-4 h-4 ${sourceConfig.task.textColor}`} />
              <span className={`text-sm font-medium ${sourceConfig.task.textColor}`}>{sourceConfig.task.label}</span>
            </div>
            <span className={`text-lg font-bold ${sourceConfig.task.textColor}`}>{sourceCounts.task}</span>
          </div>
        </div>
        <div onClick={() => setSourceFilter('matter')}
          className={`${sourceConfig.matter.bgColor} rounded-lg shadow p-3 cursor-pointer transition hover:shadow-md ${sourceFilter === 'matter' ? 'ring-2 ring-green-500' : ''}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className={`w-4 h-4 ${sourceConfig.matter.textColor}`} />
              <span className={`text-sm font-medium ${sourceConfig.matter.textColor}`}>{sourceConfig.matter.label}</span>
            </div>
            <span className={`text-lg font-bold ${sourceConfig.matter.textColor}`}>{sourceCounts.matter}</span>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          <select value={deadlineFilters.clientId}
            onChange={(e) => handleFilterChange('clientId', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].allClients || 'All Clients'}</option>
            {clients.map(c => <option key={c.client_id} value={c.client_id}>{c.client_name}</option>)}
          </select>
          
          <select value={deadlineFilters.matterId}
            onChange={(e) => handleFilterChange('matterId', e.target.value)}
            disabled={!deadlineFilters.clientId}
            className="px-3 py-2 border rounded-md text-sm disabled:bg-gray-100">
            <option value="">{t[language].allMatters || 'All Matters'}</option>
            {deadlineFilteredMatters.map(m => <option key={m.matter_id} value={m.matter_id}>{m.matter_name}</option>)}
          </select>
          
          <select value={deadlineFilters.priority}
            onChange={(e) => handleFilterChange('priority', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm">
            <option value="">{t[language].allPriorities || 'All Priorities'}</option>
            <option value="high">{t[language].high || 'High'}</option>
            <option value="medium">{t[language].medium || 'Medium'}</option>
            <option value="low">{t[language].low || 'Low'}</option>
          </select>
          
          <input type="date" value={deadlineFilters.dateFrom}
            onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm" />
          
          <input type="date" value={deadlineFilters.dateTo}
            onChange={(e) => handleFilterChange('dateTo', e.target.value)}
            className="px-3 py-2 border rounded-md text-sm" />
          
          {hasActiveFilters && (
            <button onClick={clearFilters}
              className="px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-md border border-red-200">
              {t[language].clearFilters || 'Clear'}
            </button>
          )}
        </div>
      </div>

      {/* Grouped Deadlines List */}
      <div>
        {filteredDeadlines.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-8 text-center text-gray-500">
            {hasActiveFilters 
              ? (language === 'ar' ? 'لا توجد نتائج للفلترة' : 'No results match filters') 
              : (t[language].noData || 'No data')}
          </div>
        ) : sourceFilter === 'all' ? (
          // Grouped view when showing all
          <>
            {renderSection('judgment', groupedDeadlines.judgment)}
            {renderSection('task', groupedDeadlines.task)}
            {renderSection('matter', groupedDeadlines.matter)}
          </>
        ) : (
          // Flat view when filtering by source
          <div className="space-y-2">
            {filteredDeadlines.map(deadline => renderDeadlineRow(deadline))}
          </div>
        )}
      </div>

      {/* Results count */}
      <div className="text-sm text-gray-500 text-center">
        {language === 'ar' ? 'إجمالي' : 'Total'}: {filteredDeadlines.length} {language === 'ar' ? 'موعد نهائي' : 'deadlines'}
      </div>
    </div>
  );
};

export default DeadlinesList;

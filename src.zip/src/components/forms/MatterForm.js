/**
 * MatterForm Component (v42.0.4)
 * Matter/Case creation and editing form
 * Extracted from App.js for better maintainability
 */
import React, { useState, useEffect, useCallback } from 'react';
import { X } from 'lucide-react';
import FormField from '../common/FormField';

// Helper function for generating IDs
const generateID = (prefix) => {
  const year = new Date().getFullYear();
  const random = Math.random().toString(36).substr(2, 4).toUpperCase();
  return `${prefix}-${year}-${random}`;
};

const MatterForm = React.memo(({ language, isRTL, editingMatter, setEditingMatter, setShowMatterForm, matterFormData, setMatterFormData, showToast, markFormDirty, clearFormDirty, refreshMatters, refreshClients, clients, courtTypes, regions, lawyers, t }) => {
  const defaultFormData = {
    client_id: '', matter_name: '', matter_name_arabic: '', matter_type: 'litigation',
    custom_matter_type: '', status: 'active', custom_matter_number: '', case_number: '',
    court_type_id: '', court_type_custom: '', court_region_id: '', region_custom: '', judge_name: '',
    responsible_lawyer_id: '', opening_date: new Date().toISOString().split('T')[0], notes: ''
  };
  
  // Use App-level state to persist across re-renders
  const initialData = matterFormData || (editingMatter ? {...defaultFormData, ...editingMatter} : defaultFormData);
  const [formData, setFormDataLocal] = useState(initialData);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  // Wrapper to update both local and App-level state
  const setFormData = (updater) => {
    setFormDataLocal(prev => {
      const newData = typeof updater === 'function' ? updater(prev) : updater;
      setMatterFormData(newData);
      return newData;
    });
  };
  
  // Initialize App-level state on first render
  useEffect(() => {
    if (!matterFormData) {
      setMatterFormData(initialData);
    }
  }, []);

  const validateField = (name, value) => {
    switch (name) {
      case 'client_id':
        if (!value) return t[language].selectRequired;
        break;
      case 'matter_name':
        if (!value || !value.trim()) return t[language].required;
        break;
      case 'custom_matter_type':
        if (formData.matter_type === 'custom' && (!value || !value.trim())) return t[language].required;
        break;
    }
    return null;
  };

  const handleFieldChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    markFormDirty();
    if (touched[name]) setErrors(prev => ({ ...prev, [name]: validateField(name, value) }));
  };

  const handleBlur = (name) => {
    setTouched(prev => ({ ...prev, [name]: true }));
    setErrors(prev => ({ ...prev, [name]: validateField(name, formData[name]) }));
  };

  const validateAll = () => {
    const newErrors = {};
    const fieldsToValidate = ['client_id', 'matter_name'];
    if (formData.matter_type === 'custom') fieldsToValidate.push('custom_matter_type');
    fieldsToValidate.forEach(name => {
      const error = validateField(name, formData[name]);
      if (error) newErrors[name] = error;
    });
    setErrors(newErrors);
    setTouched(fieldsToValidate.reduce((acc, f) => ({ ...acc, [f]: true }), {}));
    return Object.keys(newErrors).length === 0;
  };

  const inputClass = (hasError) => `w-full px-3 py-2 border rounded-md ${hasError ? 'border-red-500 bg-red-50' : ''}`;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateAll()) {
      showToast(language === 'ar' ? 'يرجى تصحيح الأخطاء' : 'Please fix the errors', 'error');
      return;
    }
    try {
      const matterData = {
        ...formData,
        matter_id: formData.matter_id || generateID('MTR'),
        court_type_id: formData.court_type_id === 'custom' ? null : (formData.court_type_id || null),
        court_region_id: formData.court_region_id === 'custom' ? null : (formData.court_region_id || null),
        responsible_lawyer_id: formData.responsible_lawyer_id || null
      };

      if (editingMatter) {
        await window.electronAPI.updateMatter(matterData);
      } else {
        await window.electronAPI.addMatter(matterData);
      }
      clearFormDirty();
      await refreshMatters();
      showToast(editingMatter 
        ? (language === 'ar' ? 'تم تحديث القضية بنجاح' : 'Matter updated successfully')
        : (language === 'ar' ? 'تم إضافة القضية بنجاح' : 'Matter added successfully'));
      setShowMatterForm(false);
      setEditingMatter(null);
      setMatterFormData(null);
    } catch (error) {
      console.error('Error saving matter:', error);
      showToast(language === 'ar' ? 'خطأ في حفظ القضية' : 'Error saving matter', 'error');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className={`bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto ${isRTL ? 'rtl' : 'ltr'}`}>
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">{editingMatter ? t[language].edit : t[language].addMatter}</h2>
            <button onClick={() => { setShowMatterForm(false); setEditingMatter(null); setMatterFormData(null); clearFormDirty(); }}
              className="p-2 hover:bg-gray-100 rounded-full">
              <X className="w-5 h-5" />
            </button>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <FormField label={t[language].selectClient} required error={errors.client_id}>
              <select value={formData.client_id}
                onChange={(e) => handleFieldChange('client_id', e.target.value)}
                onBlur={() => handleBlur('client_id')}
                className={inputClass(errors.client_id)}>
                <option value="">{t[language].selectClient}</option>
                {clients.map(client => (
                  <option key={client.client_id} value={client.client_id}>{client.client_name}</option>
                ))}
              </select>
            </FormField>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField label={t[language].matterName} required error={errors.matter_name}>
                <input type="text" value={formData.matter_name}
                  onChange={(e) => handleFieldChange('matter_name', e.target.value)}
                  onBlur={() => handleBlur('matter_name')}
                  className={inputClass(errors.matter_name)} />
              </FormField>
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].matterType}</label>
                <select value={formData.matter_type?.startsWith('custom:') ? 'custom' : formData.matter_type}
                  onChange={(e) => { handleFieldChange('matter_type', e.target.value); setFormData(prev => ({...prev, custom_matter_type: ''})); }}
                  className="w-full px-3 py-2 border rounded-md">
                  <option value="litigation">{t[language].litigation}</option>
                  <option value="arbitration">{t[language].arbitration}</option>
                  <option value="advisory">{t[language].advisory}</option>
                  <option value="transactional">{t[language].transactional}</option>
                  <option value="custom">{t[language].custom}</option>
                </select>
              </div>
              {(formData.matter_type === 'custom' || formData.matter_type?.startsWith('custom:')) && (
                <FormField label={t[language].customType} required error={errors.custom_matter_type}>
                  <input type="text"
                    value={formData.custom_matter_type || formData.matter_type?.replace('custom:', '') || ''}
                    onChange={(e) => { handleFieldChange('custom_matter_type', e.target.value); setFormData(prev => ({...prev, matter_type: 'custom:' + e.target.value})); }}
                    onBlur={() => handleBlur('custom_matter_type')}
                    placeholder={language === 'ar' ? 'أدخل نوع القضية...' : 'Enter matter type...'}
                    className={inputClass(errors.custom_matter_type)} />
                </FormField>
              )}
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].status}</label>
                <select value={formData.status}
                  onChange={(e) => setFormData({...formData, status: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md">
                  <option value="consultation">{t[language].consultation}</option>
                  <option value="engaged">{t[language].engaged}</option>
                  <option value="active">{t[language].active}</option>
                  <option value="on_hold">{t[language].onHold}</option>
                  <option value="closed">{t[language].closed}</option>
                  <option value="archived">{t[language].archived}</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].caseNumber}</label>
                <input type="text" value={formData.case_number}
                  onChange={(e) => setFormData({...formData, case_number: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md" />
              </div>
              {/* Court Type with Custom Option */}
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].courtType}</label>
                <select value={formData.court_type_id}
                  onChange={(e) => setFormData({...formData, court_type_id: e.target.value, court_type_custom: ''})}
                  className="w-full px-3 py-2 border rounded-md">
                  <option value="">-- {t[language].select} --</option>
                  {courtTypes.map(ct => (
                    <option key={ct.court_type_id} value={ct.court_type_id}>
                      {language === 'ar' ? ct.name_ar : ct.name_en}
                    </option>
                  ))}
                  <option value="custom">{t[language].custom}</option>
                </select>
              </div>
              {formData.court_type_id === 'custom' && (
                <div>
                  <label className="block text-sm font-medium mb-1">{t[language].customType} *</label>
                  <input type="text" required value={formData.court_type_custom}
                    onChange={(e) => setFormData({...formData, court_type_custom: e.target.value})}
                    placeholder={language === 'ar' ? 'أدخل نوع المحكمة...' : 'Enter court type...'}
                    className="w-full px-3 py-2 border rounded-md" />
                </div>
              )}
              {/* Region with Custom Option */}
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].region}</label>
                <select value={formData.court_region_id}
                  onChange={(e) => setFormData({...formData, court_region_id: e.target.value, region_custom: ''})}
                  className="w-full px-3 py-2 border rounded-md">
                  <option value="">-- {t[language].select} --</option>
                  {regions.map(r => (
                    <option key={r.region_id} value={r.region_id}>
                      {language === 'ar' ? r.name_ar : r.name_en}
                    </option>
                  ))}
                  <option value="custom">{t[language].custom}</option>
                </select>
              </div>
              {formData.court_region_id === 'custom' && (
                <div>
                  <label className="block text-sm font-medium mb-1">{t[language].customRegion} *</label>
                  <input type="text" required value={formData.region_custom}
                    placeholder={language === 'ar' ? 'أدخل المنطقة...' : 'Enter region...'}
                    placeholder={language === 'ar' ? 'أدخل المنطقة...' : 'Enter region...'}
                    className="w-full px-3 py-2 border rounded-md" />
                </div>
              )}
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].judgeName}</label>
                <input type="text" value={formData.judge_name}
                  onChange={(e) => setFormData({...formData, judge_name: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].responsibleLawyer}</label>
                <select value={formData.responsible_lawyer_id || ''}
                  onChange={(e) => setFormData({...formData, responsible_lawyer_id: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md">
                  <option value="">-- {t[language].select} --</option>
                  {lawyers.map(lawyer => (
                    <option key={lawyer.lawyer_id} value={lawyer.lawyer_id}>
                      {language === 'ar' && lawyer.full_name_arabic ? lawyer.full_name_arabic : lawyer.full_name}
                      {lawyer.initials ? ` (${lawyer.initials})` : ''}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">{t[language].openingDate}</label>
                <input type="date" value={formData.opening_date}
                  onChange={(e) => setFormData({...formData, opening_date: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">{t[language].notes}</label>
              <textarea value={formData.notes} rows="3"
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                className="w-full px-3 py-2 border rounded-md" />
            </div>
            <div className="flex justify-end gap-3">
              <button type="button" onClick={() => { setShowMatterForm(false); setEditingMatter(null); setMatterFormData(null); clearFormDirty(); }}
                className="px-4 py-2 border rounded-md hover:bg-gray-50">{t[language].cancel}</button>
              <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                {t[language].save}</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
});

export default MatterForm;

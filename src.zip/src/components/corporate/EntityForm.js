/**
 * EntityForm Component (v42.0.2)
 * Corporate Entity management form with shareholders, directors, filings, and meetings
 * Extracted from App.js for better maintainability
 */
import React, { useState, useEffect, useCallback } from 'react';
import { Pencil, Trash2, Plus, X, Building2 } from 'lucide-react';

const EntityForm = React.memo(({ language, isRTL, editingEntity, setEditingEntity, setShowEntityForm, showToast, refreshCorporateEntities, entityTypes, t, activeTab, setActiveTab }) => {
  const [companyClients, setCompanyClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    client_id: '',
    registration_number: '',
    registration_date: '',
    registered_address: '',
    share_capital: '',
    share_capital_currency: 'USD',
    total_shares: '',
    fiscal_year_end: '',
    tax_id: '',
    commercial_register: '',
    status: 'active',
    notes: ''
  });

  // Shareholders state
  const [shareholders, setShareholders] = useState([]);
  const [loadingShareholders, setLoadingShareholders] = useState(false);
  const [showShareholderForm, setShowShareholderForm] = useState(false);
  const [editingShareholder, setEditingShareholder] = useState(null);
  const [shareholderForm, setShareholderForm] = useState({
    name: '', id_number: '', nationality: '', shares_owned: '', share_class: 'Ordinary', date_acquired: ''
  });

  // Directors state (v41.8)
  const [directors, setDirectors] = useState([]);
  const [loadingDirectors, setLoadingDirectors] = useState(false);
  const [showDirectorForm, setShowDirectorForm] = useState(false);
  const [editingDirector, setEditingDirector] = useState(null);
  const [directorForm, setDirectorForm] = useState({
    name: '', id_number: '', nationality: '', position: 'Director', date_appointed: '', date_resigned: '', is_signatory: false, notes: ''
  });

  // Filings state (v41.9)
  const [filings, setFilings] = useState([]);
  const [loadingFilings, setLoadingFilings] = useState(false);
  const [showFilingForm, setShowFilingForm] = useState(false);
  const [editingFiling, setEditingFiling] = useState(null);
  const [filingForm, setFilingForm] = useState({
    filing_type: 'renewal', filing_description: '', filing_date: '', filing_reference: '',
    next_due_date: '', reminder_days: 30, notes: '', status: 'completed'
  });

  // Meetings state (v41.9)
  const [meetings, setMeetings] = useState([]);
  const [loadingMeetings, setLoadingMeetings] = useState(false);
  const [showMeetingForm, setShowMeetingForm] = useState(false);
  const [editingMeeting, setEditingMeeting] = useState(null);
  const [meetingForm, setMeetingForm] = useState({
    meeting_type: 'board', meeting_description: '', meeting_date: '', meeting_notes: '',
    attendees: '', next_meeting_date: '', next_meeting_agenda: '', reminder_days: 14, status: 'held'
  });

  // Filing types
  const filingTypes = [
    { code: 'renewal', en: 'Annual Renewal', ar: 'التجديد السنوي' },
    { code: 'amendment', en: 'Amendment', ar: 'تعديل' },
    { code: 'capital_change', en: 'Capital Change', ar: 'تعديل رأس المال' },
    { code: 'director_change', en: 'Director Change', ar: 'تغيير المدراء' },
    { code: 'shareholder_change', en: 'Shareholder Change', ar: 'تغيير الشركاء' },
    { code: 'address_change', en: 'Address Change', ar: 'تغيير العنوان' },
    { code: 'name_change', en: 'Name Change', ar: 'تغيير الاسم' },
    { code: 'other', en: 'Other', ar: 'أخرى' }
  ];

  // Meeting types by entity type
  const getMeetingTypes = () => {
    const entityType = editingEntity?.entity_type || '';
    const allTypes = [
      { code: 'board', en: 'Board Meeting', ar: 'اجتماع مجلس الإدارة' },
      { code: 'ordinary_ga', en: 'Ordinary General Assembly', ar: 'الجمعية العمومية العادية' },
      { code: 'extraordinary_ga', en: 'Extraordinary General Assembly', ar: 'الجمعية العمومية غير العادية' },
      { code: 'partners', en: 'Partners Meeting', ar: 'اجتماع الشركاء' },
      { code: 'directors', en: 'Directors Meeting', ar: 'اجتماع المدراء' },
      { code: 'written_resolution', en: 'Written Resolution', ar: 'قرار خطي' },
      { code: 'owner_decision', en: 'Owner Decision', ar: 'قرار المالك' },
      { code: 'parent_directive', en: 'Parent Company Directive', ar: 'توجيه الشركة الأم' },
      { code: 'other', en: 'Other', ar: 'أخرى' }
    ];
    
    // Filter based on entity type
    const fullCorporate = ['SAL', 'HOLDING', 'OFFSHORE', 'LPS'];
    const directorsOnly = ['SARL', 'CIVIL'];
    const singleOwner = ['SINGLE_SARL', 'SINGLE_OFFSHORE', 'SOLE_PROP'];
    const partnership = ['PARTNERSHIP', 'LP', 'JV'];
    const foreign = ['BRANCH', 'REP_OFFICE'];
    
    if (fullCorporate.includes(entityType)) {
      return allTypes.filter(t => ['board', 'ordinary_ga', 'extraordinary_ga', 'other'].includes(t.code));
    } else if (directorsOnly.includes(entityType)) {
      return allTypes.filter(t => ['partners', 'directors', 'other'].includes(t.code));
    } else if (singleOwner.includes(entityType)) {
      return allTypes.filter(t => ['written_resolution', 'owner_decision', 'other'].includes(t.code));
    } else if (partnership.includes(entityType)) {
      return allTypes.filter(t => ['partners', 'other'].includes(t.code));
    } else if (foreign.includes(entityType)) {
      return allTypes.filter(t => ['parent_directive', 'other'].includes(t.code));
    } else if (entityType === 'NGO') {
      return allTypes.filter(t => ['board', 'ordinary_ga', 'extraordinary_ga', 'other'].includes(t.code));
    }
    return allTypes; // Show all if type unknown
  };

  useEffect(() => {
    loadCompanyClients();
    if (editingEntity) {
      setFormData({
        client_id: editingEntity.client_id,
        registration_number: editingEntity.registration_number || '',
        registration_date: editingEntity.registration_date || '',
        registered_address: editingEntity.registered_address || '',
        share_capital: editingEntity.share_capital || '',
        share_capital_currency: editingEntity.share_capital_currency || 'USD',
        total_shares: editingEntity.total_shares || '',
        fiscal_year_end: editingEntity.fiscal_year_end || '',
        tax_id: editingEntity.tax_id || '',
        commercial_register: editingEntity.commercial_register || '',
        status: editingEntity.status || 'active',
        notes: editingEntity.notes || ''
      });
      loadShareholders(editingEntity.client_id);
      loadDirectors(editingEntity.client_id);
      loadFilings(editingEntity.client_id);
      loadMeetings(editingEntity.client_id);
    }
  }, [editingEntity]);

  const loadCompanyClients = async () => {
    try {
      const clients = await window.electronAPI.getCompanyClientsWithoutEntity();
      setCompanyClients(clients || []);
    } catch (error) {
      console.error('Error loading company clients:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadShareholders = async (clientId) => {
    if (!clientId) return;
    setLoadingShareholders(true);
    try {
      const data = await window.electronAPI.getShareholders(clientId);
      setShareholders(data || []);
    } catch (error) {
      console.error('Error loading shareholders:', error);
    } finally {
      setLoadingShareholders(false);
    }
  };

  const getTotalShares = () => {
    return parseInt(formData.total_shares) || 0;
  };

  const getSharePercentage = (shares) => {
    const total = getTotalShares();
    if (total === 0) return '0.00';
    return ((shares / total) * 100).toFixed(2);
  };

  const handleShareholderSubmit = async () => {
    if (!shareholderForm.name) {
      showToast(language === 'ar' ? 'يرجى إدخال اسم المساهم' : 'Please enter shareholder name', 'error');
      return;
    }

    try {
      const clientId = editingEntity?.client_id || formData.client_id;
      if (editingShareholder) {
        await window.electronAPI.updateShareholder({
          ...shareholderForm,
          id: editingShareholder.id,
          shares_owned: parseInt(shareholderForm.shares_owned) || 0
        });
        showToast(language === 'ar' ? 'تم تحديث المساهم' : 'Shareholder updated', 'success');
      } else {
        await window.electronAPI.addShareholder({
          ...shareholderForm,
          client_id: clientId,
          shares_owned: parseInt(shareholderForm.shares_owned) || 0
        });
        showToast(language === 'ar' ? 'تم إضافة المساهم' : 'Shareholder added', 'success');
      }
      loadShareholders(clientId);
      setShowShareholderForm(false);
      setEditingShareholder(null);
      setShareholderForm({ name: '', id_number: '', nationality: '', shares_owned: '', share_class: 'Ordinary', date_acquired: '' });
    } catch (error) {
      showToast(language === 'ar' ? 'خطأ في الحفظ' : 'Error saving: ' + error.message, 'error');
    }
  };

  const handleDeleteShareholder = async (id) => {
    if (!confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذا المساهم؟' : 'Are you sure you want to delete this shareholder?')) return;
    try {
      await window.electronAPI.deleteShareholder(id);
      showToast(language === 'ar' ? 'تم حذف المساهم' : 'Shareholder deleted', 'success');
      loadShareholders(editingEntity?.client_id || formData.client_id);
    } catch (error) {
      showToast(language === 'ar' ? 'خطأ في الحذف' : 'Error deleting', 'error');
    }
  };

  const handleEditShareholder = (shareholder) => {
    setEditingShareholder(shareholder);
    setShareholderForm({
      name: shareholder.name || '',
      id_number: shareholder.id_number || '',
      nationality: shareholder.nationality || '',
      shares_owned: shareholder.shares_owned || '',
      share_class: shareholder.share_class || 'Ordinary',
      date_acquired: shareholder.date_acquired || ''
    });
    setShowShareholderForm(true);
  };

  // Directors functions (v41.8)
  const loadDirectors = async (clientId) => {
    if (!clientId) return;
    setLoadingDirectors(true);
    try {
      const data = await window.electronAPI.getDirectors(clientId);
      setDirectors(data || []);
    } catch (error) {
      console.error('Error loading directors:', error);
    } finally {
      setLoadingDirectors(false);
    }
  };

  const handleDirectorSubmit = async () => {
    if (!directorForm.name) {
      showToast(language === 'ar' ? 'يرجى إدخال اسم المدير' : 'Please enter director name', 'error');
      return;
    }

    const clientId = editingEntity?.client_id || formData.client_id;

    try {
      if (editingDirector) {
        await window.electronAPI.updateDirector({
          ...directorForm,
          id: editingDirector.id
        });
        showToast(language === 'ar' ? 'تم تحديث المدير' : 'Director updated', 'success');
      } else {
        await window.electronAPI.addDirector({
          ...directorForm,
          client_id: clientId
        });
        showToast(language === 'ar' ? 'تم إضافة المدير' : 'Director added', 'success');
      }
      loadDirectors(clientId);
      setShowDirectorForm(false);
      setEditingDirector(null);
      setDirectorForm({ name: '', id_number: '', nationality: '', position: 'Director', date_appointed: '', date_resigned: '', is_signatory: false, notes: '' });
    } catch (error) {
      showToast(language === 'ar' ? 'خطأ في الحفظ' : 'Error saving', 'error');
    }
  };

  const handleDeleteDirector = async (id) => {
    if (!confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذا المدير؟' : 'Are you sure you want to delete this director?')) return;
    try {
      await window.electronAPI.deleteDirector(id);
      showToast(language === 'ar' ? 'تم حذف المدير' : 'Director deleted', 'success');
      loadDirectors(editingEntity?.client_id || formData.client_id);
    } catch (error) {
      showToast(language === 'ar' ? 'خطأ في الحذف' : 'Error deleting', 'error');
    }
  };

  const handleEditDirector = (director) => {
    setEditingDirector(director);
    setDirectorForm({
      name: director.name || '',
      id_number: director.id_number || '',
      nationality: director.nationality || '',
      position: director.position || 'Director',
      date_appointed: director.date_appointed || '',
      date_resigned: director.date_resigned || '',
      is_signatory: !!director.is_signatory,
      notes: director.notes || ''
    });
    setShowDirectorForm(true);
  };

  const getActiveDirectors = () => directors.filter(d => !d.date_resigned);
  const getResignedDirectors = () => directors.filter(d => d.date_resigned);

  // Filings functions (v41.9)
  const loadFilings = async (clientId) => {
    if (!clientId) return;
    setLoadingFilings(true);
    try {
      const data = await window.electronAPI.getFilings(clientId);
      setFilings(data || []);
    } catch (error) {
      console.error('Error loading filings:', error);
    } finally {
      setLoadingFilings(false);
    }
  };

  const handleSaveFiling = async (e) => {
    e.preventDefault();
    const clientId = editingEntity?.client_id || formData.client_id;
    if (!clientId) return;
    
    if (filingForm.filing_type === 'other' && !filingForm.filing_description) {
      showToast(language === 'ar' ? 'الوصف مطلوب لنوع "أخرى"' : 'Description required for "Other" type', 'error');
      return;
    }

    try {
      if (editingFiling) {
        await window.electronAPI.updateFiling({ ...filingForm, id: editingFiling.id });
        showToast(language === 'ar' ? 'تم تحديث السجل' : 'Filing updated', 'success');
      } else {
        await window.electronAPI.addFiling({ ...filingForm, client_id: clientId });
        showToast(language === 'ar' ? 'تم إضافة السجل' : 'Filing added', 'success');
      }
      loadFilings(clientId);
      setShowFilingForm(false);
      setEditingFiling(null);
      setFilingForm({ filing_type: 'renewal', filing_description: '', filing_date: '', filing_reference: '', next_due_date: '', reminder_days: 30, notes: '', status: 'completed' });
    } catch (error) {
      showToast(language === 'ar' ? 'خطأ في الحفظ' : 'Error saving', 'error');
    }
  };

  const handleDeleteFiling = async (id) => {
    if (!confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذا السجل؟' : 'Are you sure you want to delete this filing?')) return;
    try {
      await window.electronAPI.deleteFiling(id);
      showToast(language === 'ar' ? 'تم حذف السجل' : 'Filing deleted', 'success');
      loadFilings(editingEntity?.client_id || formData.client_id);
    } catch (error) {
      showToast(language === 'ar' ? 'خطأ في الحذف' : 'Error deleting', 'error');
    }
  };

  const handleEditFiling = (filing) => {
    setEditingFiling(filing);
    setFilingForm({
      filing_type: filing.filing_type || 'renewal',
      filing_description: filing.filing_description || '',
      filing_date: filing.filing_date || '',
      filing_reference: filing.filing_reference || '',
      next_due_date: filing.next_due_date || '',
      reminder_days: filing.reminder_days || 30,
      notes: filing.notes || '',
      status: filing.status || 'completed'
    });
    setShowFilingForm(true);
  };

  // Meetings functions (v41.9)
  const loadMeetings = async (clientId) => {
    if (!clientId) return;
    setLoadingMeetings(true);
    try {
      const data = await window.electronAPI.getMeetings(clientId);
      setMeetings(data || []);
    } catch (error) {
      console.error('Error loading meetings:', error);
    } finally {
      setLoadingMeetings(false);
    }
  };

  const handleSaveMeeting = async (e) => {
    e.preventDefault();
    const clientId = editingEntity?.client_id || formData.client_id;
    if (!clientId) return;
    
    if (meetingForm.meeting_type === 'other' && !meetingForm.meeting_description) {
      showToast(language === 'ar' ? 'الوصف مطلوب لنوع "أخرى"' : 'Description required for "Other" type', 'error');
      return;
    }

    try {
      if (editingMeeting) {
        await window.electronAPI.updateMeeting({ ...meetingForm, id: editingMeeting.id });
        showToast(language === 'ar' ? 'تم تحديث الاجتماع' : 'Meeting updated', 'success');
      } else {
        await window.electronAPI.addMeeting({ ...meetingForm, client_id: clientId });
        showToast(language === 'ar' ? 'تم إضافة الاجتماع' : 'Meeting added', 'success');
      }
      loadMeetings(clientId);
      setShowMeetingForm(false);
      setEditingMeeting(null);
      setMeetingForm({ meeting_type: 'board', meeting_description: '', meeting_date: '', meeting_notes: '', attendees: '', next_meeting_date: '', next_meeting_agenda: '', reminder_days: 14, status: 'held' });
    } catch (error) {
      showToast(language === 'ar' ? 'خطأ في الحفظ' : 'Error saving', 'error');
    }
  };

  const handleDeleteMeeting = async (id) => {
    if (!confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذا الاجتماع؟' : 'Are you sure you want to delete this meeting?')) return;
    try {
      await window.electronAPI.deleteMeeting(id);
      showToast(language === 'ar' ? 'تم حذف الاجتماع' : 'Meeting deleted', 'success');
      loadMeetings(editingEntity?.client_id || formData.client_id);
    } catch (error) {
      showToast(language === 'ar' ? 'خطأ في الحذف' : 'Error deleting', 'error');
    }
  };

  const handleEditMeeting = (meeting) => {
    setEditingMeeting(meeting);
    setMeetingForm({
      meeting_type: meeting.meeting_type || 'board',
      meeting_description: meeting.meeting_description || '',
      meeting_date: meeting.meeting_date || '',
      meeting_notes: meeting.meeting_notes || '',
      attendees: meeting.attendees || '',
      next_meeting_date: meeting.next_meeting_date || '',
      next_meeting_agenda: meeting.next_meeting_agenda || '',
      reminder_days: meeting.reminder_days || 14,
      status: meeting.status || 'held'
    });
    setShowMeetingForm(true);
  };

  const getFilingTypeName = (code) => {
    const type = filingTypes.find(t => t.code === code);
    return type ? (language === 'ar' ? type.ar : type.en) : code;
  };

  const getMeetingTypeName = (code) => {
    const allTypes = [
      { code: 'board', en: 'Board Meeting', ar: 'اجتماع مجلس الإدارة' },
      { code: 'ordinary_ga', en: 'Ordinary GA', ar: 'ج.ع. عادية' },
      { code: 'extraordinary_ga', en: 'Extraordinary GA', ar: 'ج.ع. غير عادية' },
      { code: 'partners', en: 'Partners Meeting', ar: 'اجتماع الشركاء' },
      { code: 'directors', en: 'Directors Meeting', ar: 'اجتماع المدراء' },
      { code: 'written_resolution', en: 'Written Resolution', ar: 'قرار خطي' },
      { code: 'owner_decision', en: 'Owner Decision', ar: 'قرار المالك' },
      { code: 'parent_directive', en: 'Parent Directive', ar: 'توجيه الشركة الأم' },
      { code: 'other', en: 'Other', ar: 'أخرى' }
    ];
    const type = allTypes.find(t => t.code === code);
    return type ? (language === 'ar' ? type.ar : type.en) : code;
  };

  const getUpcomingItems = () => {
    const today = new Date().toISOString().split('T')[0];
    const upcoming = [];
    
    filings.forEach(f => {
      if (f.next_due_date && f.next_due_date >= today) {
        upcoming.push({ ...f, item_type: 'filing', due_date: f.next_due_date });
      }
    });
    
    meetings.forEach(m => {
      if (m.next_meeting_date && m.next_meeting_date >= today) {
        upcoming.push({ ...m, item_type: 'meeting', due_date: m.next_meeting_date });
      }
    });
    
    return upcoming.sort((a, b) => a.due_date.localeCompare(b.due_date));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.client_id) {
      showToast(language === 'ar' ? 'يرجى اختيار العميل' : 'Please select a client', 'error');
      return;
    }

    setSaving(true);
    try {
      const dataToSave = {
        ...formData,
        share_capital: formData.share_capital ? parseFloat(formData.share_capital) : null,
        total_shares: formData.total_shares ? parseInt(formData.total_shares) : null
      };

      const hasExistingRecord = editingEntity?.entity_id;

      if (hasExistingRecord) {
        await window.electronAPI.updateCorporateEntity(dataToSave);
        showToast(language === 'ar' ? 'تم التحديث بنجاح' : 'Corporate details updated', 'success');
      } else {
        await window.electronAPI.addCorporateEntity(dataToSave);
        showToast(language === 'ar' ? 'تم الإضافة بنجاح' : 'Corporate details added', 'success');
      }
      refreshCorporateEntities();
      setShowEntityForm(false);
      setEditingEntity(null);
      setActiveTab('details');
    } catch (error) {
      showToast(language === 'ar' ? 'خطأ في الحفظ' : 'Error saving: ' + error.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const currencies = ['USD', 'LBP', 'EUR', 'GBP', 'AED', 'SAR'];

  const tabClass = (tab) => `px-4 py-2 font-medium text-sm cursor-pointer border-b-2 transition-colors ${
    activeTab === tab
      ? 'border-blue-600 text-blue-600'
      : 'border-transparent text-gray-500 hover:text-gray-700'
  }`;

  // Get company name for modal title
  const companyName = editingEntity
    ? (language === 'ar' && editingEntity.client_name_arabic ? editingEntity.client_name_arabic : editingEntity.client_name)
    : '';

  // Get entity type display name (v41.9.1)
  const getEntityTypeName = () => {
    if (!editingEntity?.entity_type) return null;
    const entityType = entityTypes.find(et => et.code === editingEntity.entity_type);
    if (!entityType) return editingEntity.entity_type;
    return language === 'ar' ? entityType.name_ar : entityType.name;
  };

  // Company Context Banner for data tabs (v41.9.1)
  const CompanyContextBanner = () => {
    if (!editingEntity) return null;
    const entityTypeName = getEntityTypeName();
    return (
      <div className={`bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4 flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <Building2 className="text-blue-600" size={20} />
        <span className="font-semibold">{companyName}</span>
        {entityTypeName && <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-sm">{entityTypeName}</span>}
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Modal Header with company name */}
      <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <h2 className="text-xl font-semibold">
          {companyName || (editingEntity && !editingEntity.isNewForClient ? t[language].edit : (t[language].addCompany || 'Add Corporate Details'))}
        </h2>
        <button
          onClick={() => { setShowEntityForm(false); setEditingEntity(null); setActiveTab('details'); }}
          className="text-gray-500 hover:text-gray-700"
        >
          <X size={24} />
        </button>
      </div>

      {/* Tabs */}
      <div className={`flex border-b mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <button className={tabClass('details')} onClick={() => setActiveTab('details')}>
          {language === 'ar' ? 'التفاصيل' : 'Details'}
        </button>
        <button
          className={tabClass('shareholders')}
          onClick={() => setActiveTab('shareholders')}
          disabled={!editingEntity?.client_id && !formData.client_id}
        >
          {language === 'ar' ? 'المساهمون' : 'Shareholders'}
        </button>
        <button
          className={tabClass('directors')}
          onClick={() => setActiveTab('directors')}
          disabled={!editingEntity?.client_id && !formData.client_id}
        >
          {language === 'ar' ? 'أعضاء مجلس الإدارة' : 'Directors'}
        </button>
        <button
          className={tabClass('compliance')}
          onClick={() => setActiveTab('compliance')}
          disabled={!editingEntity?.client_id && !formData.client_id}
        >
          {language === 'ar' ? 'الامتثال' : 'Compliance'}
        </button>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        {/* Details Tab */}
        {activeTab === 'details' && (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Client Selection - only for brand new (no editingEntity at all) */}
            {!editingEntity && (
              <div>
                <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                  {t[language].client} *
                </label>
                {loading ? (
                  <div className="text-gray-500">{t[language].loading}...</div>
                ) : companyClients.length === 0 ? (
                  <div className="text-amber-600 bg-amber-50 p-3 rounded">
                    {language === 'ar'
                      ? 'لا يوجد عملاء من نوع شركة بدون سجل مؤسسي'
                      : 'No company clients without corporate records. Add a company client first.'}
                  </div>
                ) : (
                  <select
                    value={formData.client_id}
                    onChange={(e) => setFormData({...formData, client_id: e.target.value})}
                    className="w-full px-3 py-2 border rounded-md"
                    required
                  >
                    <option value="">{t[language].selectClient}...</option>
                    {companyClients.map(client => (
                      <option key={client.client_id} value={client.client_id}>
                        {language === 'ar' && client.client_name_arabic
                          ? client.client_name_arabic
                          : client.client_name}
                        {client.entity_type_name && ` (${language === 'ar' ? client.entity_type_name_ar : client.entity_type_name})`}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            )}

            {/* Show client info when editing or adding details for specific client */}
            {editingEntity && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="font-medium">
                  {language === 'ar' && editingEntity.client_name_arabic
                    ? editingEntity.client_name_arabic
                    : editingEntity.client_name}
                </div>
                {editingEntity.entity_type_name && (
                  <div className="text-sm text-gray-500">
                    {language === 'ar' ? editingEntity.entity_type_name_ar : editingEntity.entity_type_name}
                  </div>
                )}
                {editingEntity.isNewForClient && (
                  <div className="text-sm text-blue-600 mt-1">
                    {language === 'ar' ? 'إضافة تفاصيل مؤسسية لهذا العميل' : 'Adding corporate details for this client'}
                  </div>
                )}
              </div>
            )}

            {/* Registration Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                  {t[language].registrationNumber}
                </label>
                <input
                  type="text"
                  value={formData.registration_number}
                  onChange={(e) => setFormData({...formData, registration_number: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md"
                />
              </div>
              <div>
                <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                  {t[language].registrationDate}
                </label>
                <input
                  type="date"
                  value={formData.registration_date}
                  onChange={(e) => setFormData({...formData, registration_date: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md"
                />
              </div>
            </div>

            <div>
              <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                {t[language].registeredAddress}
              </label>
              <textarea
                value={formData.registered_address}
                onChange={(e) => setFormData({...formData, registered_address: e.target.value})}
                rows={2}
                className="w-full px-3 py-2 border rounded-md"
              />
            </div>

            {/* Capital Info */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                  {t[language].shareCapital}
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.share_capital}
                  onChange={(e) => setFormData({...formData, share_capital: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md"
                />
              </div>
              <div>
                <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                  {t[language].capitalCurrency || 'Currency'}
                </label>
                <select
                  value={formData.share_capital_currency}
                  onChange={(e) => setFormData({...formData, share_capital_currency: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md"
                >
                  {currencies.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                  {t[language].numberOfShares}
                </label>
                <input
                  type="number"
                  value={formData.total_shares}
                  onChange={(e) => setFormData({...formData, total_shares: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md"
                />
              </div>
            </div>

            {/* Tax & Commercial Info */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                  {t[language].taxId}
                </label>
                <input
                  type="text"
                  value={formData.tax_id}
                  onChange={(e) => setFormData({...formData, tax_id: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md"
                />
              </div>
              <div>
                <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                  {t[language].commercialRegister}
                </label>
                <input
                  type="text"
                  value={formData.commercial_register}
                  onChange={(e) => setFormData({...formData, commercial_register: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md"
                />
              </div>
              <div>
                <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                  {t[language].fiscalYearEnd}
                </label>
                <input
                  type="text"
                  placeholder="MM-DD"
                  value={formData.fiscal_year_end}
                  onChange={(e) => setFormData({...formData, fiscal_year_end: e.target.value})}
                  className="w-full px-3 py-2 border rounded-md"
                />
              </div>
            </div>

            {/* Status */}
            <div>
              <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                {t[language].status}
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({...formData, status: e.target.value})}
                className="w-full px-3 py-2 border rounded-md"
              >
                <option value="active">{t[language].entityActive || 'Active'}</option>
                <option value="dormant">{t[language].entityDormant || 'Dormant'}</option>
                <option value="liquidating">{t[language].entityLiquidating || 'Liquidating'}</option>
                <option value="struck_off">{t[language].entityStruckOff || 'Struck Off'}</option>
              </select>
            </div>

            {/* Notes */}
            <div>
              <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                {t[language].notes}
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                rows={3}
                className="w-full px-3 py-2 border rounded-md"
              />
            </div>

            {/* Buttons */}
            <div className={`flex gap-3 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <button
                type="submit"
                disabled={saving || (!editingEntity && companyClients.length === 0)}
                className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-300"
              >
                {saving ? (language === 'ar' ? 'جاري الحفظ...' : 'Saving...') : t[language].save}
              </button>
              <button
                type="button"
                onClick={() => { setShowEntityForm(false); setEditingEntity(null); setActiveTab('details'); }}
                className="px-6 py-2 border rounded-lg hover:bg-gray-50"
              >
                {t[language].cancel}
              </button>
            </div>
          </form>
        )}

        {/* Shareholders Tab */}
        {activeTab === 'shareholders' && (
          <div className="space-y-4">
            <CompanyContextBanner />
            {/* Add Shareholder Button */}
            <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h3 className="text-lg font-medium">
                {language === 'ar' ? 'المساهمون' : 'Shareholders'}
              </h3>
              <button
                onClick={() => {
                  setEditingShareholder(null);
                  setShareholderForm({ name: '', id_number: '', nationality: '', shares_owned: '', share_class: 'Ordinary', date_acquired: '' });
                  setShowShareholderForm(true);
                }}
                className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
              >
                <Plus size={18} />
                {language === 'ar' ? 'إضافة مساهم' : 'Add Shareholder'}
              </button>
            </div>

            {/* Shareholder Form (inline) */}
            {showShareholderForm && (
              <div className="bg-gray-50 p-4 rounded-lg space-y-4">
                <h4 className="font-medium">
                  {editingShareholder
                    ? (language === 'ar' ? 'تعديل المساهم' : 'Edit Shareholder')
                    : (language === 'ar' ? 'إضافة مساهم' : 'Add Shareholder')}
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      {language === 'ar' ? 'الاسم' : 'Name'} *
                    </label>
                    <input
                      type="text"
                      value={shareholderForm.name}
                      onChange={(e) => setShareholderForm({...shareholderForm, name: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      {language === 'ar' ? 'رقم الهوية' : 'ID Number'}
                    </label>
                    <input
                      type="text"
                      value={shareholderForm.id_number}
                      onChange={(e) => setShareholderForm({...shareholderForm, id_number: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      {language === 'ar' ? 'الجنسية' : 'Nationality'}
                    </label>
                    <input
                      type="text"
                      value={shareholderForm.nationality}
                      onChange={(e) => setShareholderForm({...shareholderForm, nationality: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      {language === 'ar' ? 'الأسهم المملوكة' : 'Shares Owned'}
                    </label>
                    <input
                      type="number"
                      value={shareholderForm.shares_owned}
                      onChange={(e) => setShareholderForm({...shareholderForm, shares_owned: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      {language === 'ar' ? 'فئة الأسهم' : 'Share Class'}
                    </label>
                    <select
                      value={shareholderForm.share_class}
                      onChange={(e) => setShareholderForm({...shareholderForm, share_class: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                    >
                      <option value="Ordinary">{language === 'ar' ? 'عادية' : 'Ordinary'}</option>
                      <option value="Preferred">{language === 'ar' ? 'ممتازة' : 'Preferred'}</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      {language === 'ar' ? 'تاريخ الاقتناء' : 'Date Acquired'}
                    </label>
                    <input
                      type="date"
                      value={shareholderForm.date_acquired}
                      onChange={(e) => setShareholderForm({...shareholderForm, date_acquired: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleShareholderSubmit}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                  >
                    {language === 'ar' ? 'حفظ' : 'Save'}
                  </button>
                  <button
                    onClick={() => { setShowShareholderForm(false); setEditingShareholder(null); }}
                    className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                  >
                    {language === 'ar' ? 'إلغاء' : 'Cancel'}
                  </button>
                </div>
              </div>
            )}

            {/* Shareholders Table */}
            {loadingShareholders ? (
              <div className="text-center py-8 text-gray-500">{t[language].loading}...</div>
            ) : shareholders.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                {language === 'ar' ? 'لا يوجد مساهمون مسجلون' : 'No shareholders registered'}
              </div>
            ) : (
              <>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                          {language === 'ar' ? 'الاسم' : 'Name'}
                        </th>
                        <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                          {language === 'ar' ? 'رقم الهوية' : 'ID Number'}
                        </th>
                        <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                          {language === 'ar' ? 'الجنسية' : 'Nationality'}
                        </th>
                        <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                          {language === 'ar' ? 'الأسهم' : 'Shares'}
                        </th>
                        <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                          {language === 'ar' ? 'فئة' : 'Class'}
                        </th>
                        <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                          {language === 'ar' ? 'النسبة' : '%'}
                        </th>
                        <th className="px-4 py-3 font-medium text-center">
                          {language === 'ar' ? 'إجراءات' : 'Actions'}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {shareholders.map(s => (
                        <tr key={s.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3">{s.name}</td>
                          <td className="px-4 py-3">{s.id_number || '-'}</td>
                          <td className="px-4 py-3">{s.nationality || '-'}</td>
                          <td className="px-4 py-3">{s.shares_owned?.toLocaleString() || 0}</td>
                          <td className="px-4 py-3">
                            {s.share_class === 'Ordinary'
                              ? (language === 'ar' ? 'عادية' : 'Ordinary')
                              : (language === 'ar' ? 'ممتازة' : 'Preferred')}
                          </td>
                          <td className="px-4 py-3">{getSharePercentage(s.shares_owned)}%</td>
                          <td className="px-4 py-3 text-center">
                            <button
                              onClick={() => handleEditShareholder(s)}
                              className="text-blue-600 hover:text-blue-800 p-1"
                              title={language === 'ar' ? 'تعديل' : 'Edit'}
                            >
                              <Pencil size={16} />
                            </button>
                            <button
                              onClick={() => handleDeleteShareholder(s.id)}
                              className="text-red-600 hover:text-red-800 p-1 ml-2"
                              title={language === 'ar' ? 'حذف' : 'Delete'}
                            >
                              <Trash2 size={16} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Total row */}
                <div className={`bg-gray-100 p-3 rounded-lg flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <span className="font-medium">
                    {language === 'ar' ? 'إجمالي الأسهم:' : 'Total Shares:'}
                  </span>
                  <span className="font-bold text-lg">
                    {getTotalShares().toLocaleString()}
                    {formData.share_capital && (
                      <span className="text-sm text-gray-500 ml-2">
                        ({language === 'ar' ? 'رأس المال:' : 'Capital:'} {parseFloat(formData.share_capital).toLocaleString()})
                      </span>
                    )}
                  </span>
                </div>
              </>
            )}
          </div>
        )}

        {/* Directors Tab (v41.8) */}
        {activeTab === 'directors' && (
          <div className="space-y-4">
            <CompanyContextBanner />
            {/* Add Director Button */}
            <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h3 className="font-medium text-lg">
                {language === 'ar' ? 'أعضاء مجلس الإدارة' : 'Directors'}
              </h3>
              <button
                onClick={() => {
                  setEditingDirector(null);
                  setDirectorForm({ name: '', id_number: '', nationality: '', position: 'Director', date_appointed: '', date_resigned: '', is_signatory: false, notes: '' });
                  setShowDirectorForm(true);
                }}
                className="bg-blue-600 text-white px-3 py-1.5 rounded-lg hover:bg-blue-700 flex items-center gap-1"
              >
                <Plus size={16} />
                {language === 'ar' ? 'إضافة مدير' : 'Add Director'}
              </button>
            </div>

            {/* Director Form (inline) */}
            {showDirectorForm && (
              <div className="bg-gray-50 p-4 rounded-lg space-y-4">
                <h4 className="font-medium">
                  {editingDirector
                    ? (language === 'ar' ? 'تعديل المدير' : 'Edit Director')
                    : (language === 'ar' ? 'إضافة مدير' : 'Add Director')}
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">{language === 'ar' ? 'الاسم' : 'Name'} *</label>
                    <input
                      type="text"
                      value={directorForm.name}
                      onChange={(e) => setDirectorForm({...directorForm, name: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">{language === 'ar' ? 'رقم الهوية' : 'ID Number'}</label>
                    <input
                      type="text"
                      value={directorForm.id_number}
                      onChange={(e) => setDirectorForm({...directorForm, id_number: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">{language === 'ar' ? 'الجنسية' : 'Nationality'}</label>
                    <input
                      type="text"
                      value={directorForm.nationality}
                      onChange={(e) => setDirectorForm({...directorForm, nationality: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">{language === 'ar' ? 'المنصب' : 'Position'}</label>
                    <select
                      value={directorForm.position}
                      onChange={(e) => setDirectorForm({...directorForm, position: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                    >
                      <option value="Chairman">{language === 'ar' ? 'رئيس مجلس الإدارة' : 'Chairman'}</option>
                      <option value="Vice Chairman">{language === 'ar' ? 'نائب رئيس مجلس الإدارة' : 'Vice Chairman'}</option>
                      <option value="Managing Director">{language === 'ar' ? 'المدير العام' : 'Managing Director'}</option>
                      <option value="Director">{language === 'ar' ? 'عضو مجلس إدارة' : 'Director'}</option>
                      <option value="Secretary">{language === 'ar' ? 'السكرتير' : 'Secretary'}</option>
                      <option value="Treasurer">{language === 'ar' ? 'أمين الصندوق' : 'Treasurer'}</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">{language === 'ar' ? 'تاريخ التعيين' : 'Date Appointed'}</label>
                    <input
                      type="date"
                      value={directorForm.date_appointed}
                      onChange={(e) => setDirectorForm({...directorForm, date_appointed: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">{language === 'ar' ? 'تاريخ الاستقالة' : 'Date Resigned'}</label>
                    <input
                      type="date"
                      value={directorForm.date_resigned}
                      onChange={(e) => setDirectorForm({...directorForm, date_resigned: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={directorForm.is_signatory}
                        onChange={(e) => setDirectorForm({...directorForm, is_signatory: e.target.checked})}
                        className="w-4 h-4 rounded border-gray-300"
                      />
                      <span className="text-sm font-medium">{language === 'ar' ? 'مخول بالتوقيع' : 'Authorized Signatory'}</span>
                    </label>
                  </div>
                  <div className="col-span-2">
                    <label className="block text-sm font-medium mb-1">{language === 'ar' ? 'ملاحظات' : 'Notes'}</label>
                    <textarea
                      value={directorForm.notes}
                      onChange={(e) => setDirectorForm({...directorForm, notes: e.target.value})}
                      className="w-full px-3 py-2 border rounded-md"
                      rows={2}
                    />
                  </div>
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={handleDirectorSubmit}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                  >
                    {language === 'ar' ? 'حفظ' : 'Save'}
                  </button>
                  <button
                    onClick={() => { setShowDirectorForm(false); setEditingDirector(null); }}
                    className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                  >
                    {language === 'ar' ? 'إلغاء' : 'Cancel'}
                  </button>
                </div>
              </div>
            )}

            {/* Directors Table */}
            {loadingDirectors ? (
              <div className="text-center py-8 text-gray-500">{t[language].loading}...</div>
            ) : directors.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                {language === 'ar' ? 'لا يوجد أعضاء مجلس إدارة مسجلون' : 'No directors registered'}
              </div>
            ) : (
              <>
                {/* Active Directors */}
                {getActiveDirectors().length > 0 && (
                  <div>
                    <h4 className={`text-sm font-medium text-gray-600 mb-2 ${isRTL ? 'text-right' : ''}`}>
                      {language === 'ar' ? 'أعضاء حاليون' : 'Active Directors'} ({getActiveDirectors().length})
                    </h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'ar' ? 'الاسم' : 'Name'}
                            </th>
                            <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'ar' ? 'المنصب' : 'Position'}
                            </th>
                            <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'ar' ? 'الجنسية' : 'Nationality'}
                            </th>
                            <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'ar' ? 'تاريخ التعيين' : 'Appointed'}
                            </th>
                            <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'ar' ? 'مخول' : 'Signatory'}
                            </th>
                            <th className="px-4 py-3 font-medium text-center">
                              {language === 'ar' ? 'إجراءات' : 'Actions'}
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {getActiveDirectors().map(d => (
                            <tr key={d.id} className="hover:bg-gray-50">
                              <td className="px-4 py-3 font-medium">{d.name}</td>
                              <td className="px-4 py-3">
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                                  {d.position === 'Chairman' ? (language === 'ar' ? 'رئيس' : 'Chairman') :
                                   d.position === 'Vice Chairman' ? (language === 'ar' ? 'نائب رئيس' : 'Vice Chairman') :
                                   d.position === 'Managing Director' ? (language === 'ar' ? 'مدير عام' : 'Managing Director') :
                                   d.position === 'Secretary' ? (language === 'ar' ? 'سكرتير' : 'Secretary') :
                                   d.position === 'Treasurer' ? (language === 'ar' ? 'أمين صندوق' : 'Treasurer') :
                                   (language === 'ar' ? 'عضو' : 'Director')}
                                </span>
                              </td>
                              <td className="px-4 py-3">{d.nationality || '-'}</td>
                              <td className="px-4 py-3">{d.date_appointed || '-'}</td>
                              <td className="px-4 py-3">
                                {d.is_signatory ? (
                                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                                    ✓ {language === 'ar' ? 'نعم' : 'Yes'}
                                  </span>
                                ) : (
                                  <span className="text-gray-400">-</span>
                                )}
                              </td>
                              <td className="px-4 py-3 text-center">
                                <button
                                  onClick={() => handleEditDirector(d)}
                                  className="text-blue-600 hover:text-blue-800 p-1"
                                  title={language === 'ar' ? 'تعديل' : 'Edit'}
                                >
                                  <Pencil size={16} />
                                </button>
                                <button
                                  onClick={() => handleDeleteDirector(d.id)}
                                  className="text-red-600 hover:text-red-800 p-1 ml-2"
                                  title={language === 'ar' ? 'حذف' : 'Delete'}
                                >
                                  <Trash2 size={16} />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Resigned Directors */}
                {getResignedDirectors().length > 0 && (
                  <div className="mt-6">
                    <h4 className={`text-sm font-medium text-gray-600 mb-2 ${isRTL ? 'text-right' : ''}`}>
                      {language === 'ar' ? 'أعضاء سابقون' : 'Former Directors'} ({getResignedDirectors().length})
                    </h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm opacity-75">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'ar' ? 'الاسم' : 'Name'}
                            </th>
                            <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'ar' ? 'المنصب' : 'Position'}
                            </th>
                            <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'ar' ? 'تاريخ التعيين' : 'Appointed'}
                            </th>
                            <th className={`px-4 py-3 font-medium ${isRTL ? 'text-right' : 'text-left'}`}>
                              {language === 'ar' ? 'تاريخ الاستقالة' : 'Resigned'}
                            </th>
                            <th className="px-4 py-3 font-medium text-center">
                              {language === 'ar' ? 'إجراءات' : 'Actions'}
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {getResignedDirectors().map(d => (
                            <tr key={d.id} className="hover:bg-gray-50">
                              <td className="px-4 py-3">{d.name}</td>
                              <td className="px-4 py-3">{d.position}</td>
                              <td className="px-4 py-3">{d.date_appointed || '-'}</td>
                              <td className="px-4 py-3">{d.date_resigned || '-'}</td>
                              <td className="px-4 py-3 text-center">
                                <button
                                  onClick={() => handleEditDirector(d)}
                                  className="text-blue-600 hover:text-blue-800 p-1"
                                  title={language === 'ar' ? 'تعديل' : 'Edit'}
                                >
                                  <Pencil size={16} />
                                </button>
                                <button
                                  onClick={() => handleDeleteDirector(d.id)}
                                  className="text-red-600 hover:text-red-800 p-1 ml-2"
                                  title={language === 'ar' ? 'حذف' : 'Delete'}
                                >
                                  <Trash2 size={16} />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Summary */}
                <div className={`bg-gray-100 p-3 rounded-lg flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <span className="font-medium">
                    {language === 'ar' ? 'إجمالي أعضاء مجلس الإدارة:' : 'Total Directors:'}
                  </span>
                  <span className="font-bold">
                    {getActiveDirectors().length} {language === 'ar' ? 'حالي' : 'active'}
                    {getResignedDirectors().length > 0 && (
                      <span className="text-gray-500 font-normal ml-2">
                        ({getResignedDirectors().length} {language === 'ar' ? 'سابق' : 'former'})
                      </span>
                    )}
                  </span>
                </div>
              </>
            )}
          </div>
        )}

        {/* Compliance Tab (v41.9) */}
        {activeTab === 'compliance' && (
          <div className="space-y-6">
            <CompanyContextBanner />
            {/* Upcoming Items Summary */}
            {getUpcomingItems().length > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <h4 className={`font-medium text-amber-800 mb-2 ${isRTL ? 'text-right' : ''}`}>
                  {language === 'ar' ? '📅 المواعيد القادمة' : '📅 Upcoming'}
                </h4>
                <div className="space-y-2">
                  {getUpcomingItems().slice(0, 5).map((item, idx) => (
                    <div key={idx} className={`flex justify-between items-center text-sm ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <span>
                        {item.item_type === 'filing' ? '📋 ' : '📅 '}
                        {item.item_type === 'filing' ? getFilingTypeName(item.filing_type) : getMeetingTypeName(item.meeting_type)}
                        {item.filing_description || item.meeting_description ? ` - ${item.filing_description || item.meeting_description}` : ''}
                      </span>
                      <span className="text-amber-700 font-medium">{item.due_date}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Commercial Register Section */}
            <div className="border rounded-lg p-4">
              <div className={`flex justify-between items-center mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <h4 className="font-medium text-gray-800">
                  {language === 'ar' ? '📋 السجل التجاري' : '📋 Commercial Register'}
                </h4>
                <button
                  type="button"
                  onClick={() => { setShowFilingForm(true); setEditingFiling(null); setFilingForm({ filing_type: 'renewal', filing_description: '', filing_date: '', filing_reference: '', next_due_date: '', reminder_days: 30, notes: '', status: 'completed' }); }}
                  className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm"
                >
                  {language === 'ar' ? '+ إضافة سجل' : '+ Add Filing'}
                </button>
              </div>

              {/* Filing Form */}
              {showFilingForm && (
                <div className="bg-gray-50 p-4 rounded-lg mb-4">
                  <form onSubmit={handleSaveFiling} className="space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'نوع السجل' : 'Filing Type'} *
                        </label>
                        <select
                          value={filingForm.filing_type}
                          onChange={(e) => setFilingForm({ ...filingForm, filing_type: e.target.value })}
                          className="w-full p-2 border rounded"
                        >
                          {filingTypes.map(t => (
                            <option key={t.code} value={t.code}>{language === 'ar' ? t.ar : t.en}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'الوصف' : 'Description'} {filingForm.filing_type === 'other' ? '*' : ''}
                        </label>
                        <input
                          type="text"
                          value={filingForm.filing_description}
                          onChange={(e) => setFilingForm({ ...filingForm, filing_description: e.target.value })}
                          className="w-full p-2 border rounded"
                          placeholder={language === 'ar' ? 'وصف السجل...' : 'Filing description...'}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'تاريخ التقديم' : 'Filing Date'}
                        </label>
                        <input
                          type="date"
                          value={filingForm.filing_date}
                          onChange={(e) => setFilingForm({ ...filingForm, filing_date: e.target.value })}
                          className="w-full p-2 border rounded"
                        />
                      </div>
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'رقم المرجع' : 'Reference #'}
                        </label>
                        <input
                          type="text"
                          value={filingForm.filing_reference}
                          onChange={(e) => setFilingForm({ ...filingForm, filing_reference: e.target.value })}
                          className="w-full p-2 border rounded"
                        />
                      </div>
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'الحالة' : 'Status'}
                        </label>
                        <select
                          value={filingForm.status}
                          onChange={(e) => setFilingForm({ ...filingForm, status: e.target.value })}
                          className="w-full p-2 border rounded"
                        >
                          <option value="completed">{language === 'ar' ? 'مكتمل' : 'Completed'}</option>
                          <option value="pending">{language === 'ar' ? 'معلق' : 'Pending'}</option>
                        </select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'تاريخ الاستحقاق التالي' : 'Next Due Date'}
                        </label>
                        <input
                          type="date"
                          value={filingForm.next_due_date}
                          onChange={(e) => setFilingForm({ ...filingForm, next_due_date: e.target.value })}
                          className="w-full p-2 border rounded"
                        />
                      </div>
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'التذكير قبل (أيام)' : 'Reminder (days before)'}
                        </label>
                        <input
                          type="number"
                          value={filingForm.reminder_days}
                          onChange={(e) => setFilingForm({ ...filingForm, reminder_days: parseInt(e.target.value) || 30 })}
                          className="w-full p-2 border rounded"
                        />
                      </div>
                    </div>
                    <div>
                      <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                        {language === 'ar' ? 'ملاحظات' : 'Notes'}
                      </label>
                      <textarea
                        value={filingForm.notes}
                        onChange={(e) => setFilingForm({ ...filingForm, notes: e.target.value })}
                        className="w-full p-2 border rounded"
                        rows={2}
                      />
                    </div>
                    <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                        {editingFiling ? (language === 'ar' ? 'تحديث' : 'Update') : (language === 'ar' ? 'حفظ' : 'Save')}
                      </button>
                      <button type="button" onClick={() => { setShowFilingForm(false); setEditingFiling(null); }} className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">
                        {language === 'ar' ? 'إلغاء' : 'Cancel'}
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Filings List */}
              {loadingFilings ? (
                <div className="text-center py-4 text-gray-500">{language === 'ar' ? 'جاري التحميل...' : 'Loading...'}</div>
              ) : filings.length === 0 ? (
                <div className="text-center py-4 text-gray-500">{language === 'ar' ? 'لا توجد سجلات' : 'No filings recorded'}</div>
              ) : (
                <div className="space-y-2">
                  {filings.map(f => (
                    <div key={f.id} className={`flex justify-between items-center p-3 bg-white border rounded hover:bg-gray-50 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <div>
                        <div className="font-medium">
                          {getFilingTypeName(f.filing_type)}
                          {f.filing_description && <span className="text-gray-600 ml-2">- {f.filing_description}</span>}
                        </div>
                        <div className="text-sm text-gray-500">
                          {f.filing_date && <span>{language === 'ar' ? 'التاريخ: ' : 'Filed: '}{f.filing_date}</span>}
                          {f.filing_reference && <span className="ml-3">{language === 'ar' ? 'المرجع: ' : 'Ref: '}{f.filing_reference}</span>}
                          {f.next_due_date && <span className="ml-3 text-amber-600">{language === 'ar' ? 'التالي: ' : 'Next: '}{f.next_due_date}</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-1 rounded text-xs ${f.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
                          {f.status === 'completed' ? (language === 'ar' ? 'مكتمل' : 'Completed') : (language === 'ar' ? 'معلق' : 'Pending')}
                        </span>
                        <button onClick={() => handleEditFiling(f)} className="text-blue-600 hover:text-blue-800 p-1"><Pencil size={16} /></button>
                        <button onClick={() => handleDeleteFiling(f.id)} className="text-red-600 hover:text-red-800 p-1"><Trash2 size={16} /></button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Meetings Section */}
            <div className="border rounded-lg p-4">
              <div className={`flex justify-between items-center mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <h4 className="font-medium text-gray-800">
                  {language === 'ar' ? '📅 الاجتماعات' : '📅 Meetings'}
                </h4>
                <button
                  type="button"
                  onClick={() => { setShowMeetingForm(true); setEditingMeeting(null); setMeetingForm({ meeting_type: getMeetingTypes()[0]?.code || 'board', meeting_description: '', meeting_date: '', meeting_notes: '', attendees: '', next_meeting_date: '', next_meeting_agenda: '', reminder_days: 14, status: 'held' }); }}
                  className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm"
                >
                  {language === 'ar' ? '+ إضافة اجتماع' : '+ Add Meeting'}
                </button>
              </div>

              {/* Meeting Form */}
              {showMeetingForm && (
                <div className="bg-gray-50 p-4 rounded-lg mb-4">
                  <form onSubmit={handleSaveMeeting} className="space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'نوع الاجتماع' : 'Meeting Type'} *
                        </label>
                        <select
                          value={meetingForm.meeting_type}
                          onChange={(e) => setMeetingForm({ ...meetingForm, meeting_type: e.target.value })}
                          className="w-full p-2 border rounded"
                        >
                          {getMeetingTypes().map(t => (
                            <option key={t.code} value={t.code}>{language === 'ar' ? t.ar : t.en}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'الوصف' : 'Description'} {meetingForm.meeting_type === 'other' ? '*' : ''}
                        </label>
                        <input
                          type="text"
                          value={meetingForm.meeting_description}
                          onChange={(e) => setMeetingForm({ ...meetingForm, meeting_description: e.target.value })}
                          className="w-full p-2 border rounded"
                          placeholder={language === 'ar' ? 'وصف الاجتماع...' : 'Meeting description...'}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'تاريخ الاجتماع' : 'Meeting Date'}
                        </label>
                        <input
                          type="date"
                          value={meetingForm.meeting_date}
                          onChange={(e) => setMeetingForm({ ...meetingForm, meeting_date: e.target.value })}
                          className="w-full p-2 border rounded"
                        />
                      </div>
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'الحضور' : 'Attendees'}
                        </label>
                        <input
                          type="text"
                          value={meetingForm.attendees}
                          onChange={(e) => setMeetingForm({ ...meetingForm, attendees: e.target.value })}
                          className="w-full p-2 border rounded"
                          placeholder={language === 'ar' ? 'أسماء الحضور...' : 'Names of attendees...'}
                        />
                      </div>
                    </div>
                    <div>
                      <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                        {language === 'ar' ? 'ملاحظات / القرارات' : 'Notes / Decisions'}
                      </label>
                      <textarea
                        value={meetingForm.meeting_notes}
                        onChange={(e) => setMeetingForm({ ...meetingForm, meeting_notes: e.target.value })}
                        className="w-full p-2 border rounded"
                        rows={2}
                        placeholder={language === 'ar' ? 'ما تم مناقشته أو اتخاذه من قرارات...' : 'What was discussed or decided...'}
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'الاجتماع القادم' : 'Next Meeting Date'}
                        </label>
                        <input
                          type="date"
                          value={meetingForm.next_meeting_date}
                          onChange={(e) => setMeetingForm({ ...meetingForm, next_meeting_date: e.target.value })}
                          className="w-full p-2 border rounded"
                        />
                      </div>
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'التذكير قبل (أيام)' : 'Reminder (days)'}
                        </label>
                        <input
                          type="number"
                          value={meetingForm.reminder_days}
                          onChange={(e) => setMeetingForm({ ...meetingForm, reminder_days: parseInt(e.target.value) || 14 })}
                          className="w-full p-2 border rounded"
                        />
                      </div>
                      <div>
                        <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                          {language === 'ar' ? 'الحالة' : 'Status'}
                        </label>
                        <select
                          value={meetingForm.status}
                          onChange={(e) => setMeetingForm({ ...meetingForm, status: e.target.value })}
                          className="w-full p-2 border rounded"
                        >
                          <option value="held">{language === 'ar' ? 'تم عقده' : 'Held'}</option>
                          <option value="scheduled">{language === 'ar' ? 'مجدول' : 'Scheduled'}</option>
                          <option value="cancelled">{language === 'ar' ? 'ملغى' : 'Cancelled'}</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className={`block text-sm font-medium mb-1 ${isRTL ? 'text-right' : ''}`}>
                        {language === 'ar' ? 'جدول أعمال الاجتماع القادم' : 'Next Meeting Agenda'}
                      </label>
                      <textarea
                        value={meetingForm.next_meeting_agenda}
                        onChange={(e) => setMeetingForm({ ...meetingForm, next_meeting_agenda: e.target.value })}
                        className="w-full p-2 border rounded"
                        rows={2}
                        placeholder={language === 'ar' ? 'المواضيع المخطط مناقشتها...' : 'Topics to be discussed...'}
                      />
                    </div>
                    <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                        {editingMeeting ? (language === 'ar' ? 'تحديث' : 'Update') : (language === 'ar' ? 'حفظ' : 'Save')}
                      </button>
                      <button type="button" onClick={() => { setShowMeetingForm(false); setEditingMeeting(null); }} className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">
                        {language === 'ar' ? 'إلغاء' : 'Cancel'}
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Meetings List */}
              {loadingMeetings ? (
                <div className="text-center py-4 text-gray-500">{language === 'ar' ? 'جاري التحميل...' : 'Loading...'}</div>
              ) : meetings.length === 0 ? (
                <div className="text-center py-4 text-gray-500">{language === 'ar' ? 'لا توجد اجتماعات' : 'No meetings recorded'}</div>
              ) : (
                <div className="space-y-2">
                  {meetings.map(m => (
                    <div key={m.id} className={`flex justify-between items-center p-3 bg-white border rounded hover:bg-gray-50 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <div>
                        <div className="font-medium">
                          {getMeetingTypeName(m.meeting_type)}
                          {m.meeting_description && <span className="text-gray-600 ml-2">- {m.meeting_description}</span>}
                        </div>
                        <div className="text-sm text-gray-500">
                          {m.meeting_date && <span>{language === 'ar' ? 'التاريخ: ' : 'Date: '}{m.meeting_date}</span>}
                          {m.attendees && <span className="ml-3">{language === 'ar' ? 'الحضور: ' : 'Attendees: '}{m.attendees}</span>}
                        </div>
                        {m.meeting_notes && <div className="text-sm text-gray-600 mt-1">{m.meeting_notes.substring(0, 100)}{m.meeting_notes.length > 100 ? '...' : ''}</div>}
                        {m.next_meeting_date && (
                          <div className="text-sm text-amber-600 mt-1">
                            {language === 'ar' ? 'الاجتماع القادم: ' : 'Next: '}{m.next_meeting_date}
                            {m.next_meeting_agenda && <span className="text-gray-500"> - {m.next_meeting_agenda.substring(0, 50)}{m.next_meeting_agenda.length > 50 ? '...' : ''}</span>}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-1 rounded text-xs ${
                          m.status === 'held' ? 'bg-green-100 text-green-800' : 
                          m.status === 'scheduled' ? 'bg-blue-100 text-blue-800' : 
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {m.status === 'held' ? (language === 'ar' ? 'تم عقده' : 'Held') : 
                           m.status === 'scheduled' ? (language === 'ar' ? 'مجدول' : 'Scheduled') : 
                           (language === 'ar' ? 'ملغى' : 'Cancelled')}
                        </span>
                        <button onClick={() => handleEditMeeting(m)} className="text-blue-600 hover:text-blue-800 p-1"><Pencil size={16} /></button>
                        <button onClick={() => handleDeleteMeeting(m.id)} className="text-red-600 hover:text-red-800 p-1"><Trash2 size={16} /></button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
});

export default EntityForm;

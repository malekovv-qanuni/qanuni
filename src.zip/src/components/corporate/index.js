/**
 * Corporate Components Barrel Export (v42.0.3)
 */
export { default as EntityForm } from './EntityForm';
export { default as EntitiesList } from './EntitiesList';

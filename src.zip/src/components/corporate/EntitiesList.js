/**
 * EntitiesList Component (v42.0.3)
 * Corporate Entities list with search and filtering
 * Extracted from App.js for better maintainability
 */
import React, { useState } from 'react';
import { Building2, Edit3, Plus, Trash2 } from 'lucide-react';

const EntitiesList = React.memo(({ language, isRTL, corporateEntities, setShowEntityForm, setEditingEntity, showToast, refreshCorporateEntities, t }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredEntities = corporateEntities.filter(entity => {
    const matchesSearch = !searchTerm ||
      entity.client_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entity.client_name_arabic?.includes(searchTerm) ||
      entity.registration_number?.toLowerCase().includes(searchTerm.toLowerCase());
    // Filter by corporate_status (not client status) - 'all' shows all including those without details
    const matchesStatus = statusFilter === 'all' ||
      (statusFilter === 'no_details' && !entity.has_corporate_details) ||
      (entity.has_corporate_details && entity.corporate_status === statusFilter);
    return matchesSearch && matchesStatus;
  });

  const handleEdit = (entity) => {
    // For clients with corporate details, load the full entity data for editing
    if (entity.has_corporate_details) {
      setEditingEntity({
        ...entity,
        entity_type: entity.entity_type,
        entity_id: entity.entity_id,
        status: entity.corporate_status
      });
    } else {
      // For clients without details, pass client info to pre-select in form
      // Mark as new (no entity_id) but pre-populate client_id
      setEditingEntity({
        client_id: entity.client_id,
        client_name: entity.client_name,
        client_name_arabic: entity.client_name_arabic,
        entity_type: entity.entity_type,
        isNewForClient: true  // Flag to indicate adding details for existing client
      });
    }
    setShowEntityForm(true);
  };

  const handleAddDetails = (entity) => {
    // Pass client info to pre-populate in form
    setEditingEntity({
      client_id: entity.client_id,
      client_name: entity.client_name,
      client_name_arabic: entity.client_name_arabic,
      entity_type: entity.entity_type,
      isNewForClient: true
    });
    setShowEntityForm(true);
  };

  const handleDelete = async (clientId) => {
    if (window.confirm(language === 'ar' ? 'هل أنت متأكد من الحذف؟' : 'Are you sure you want to delete this corporate record?')) {
      try {
        await window.electronAPI.deleteCorporateEntity(clientId);
        showToast(language === 'ar' ? 'تم الحذف بنجاح' : 'Corporate record deleted', 'success');
        refreshCorporateEntities();
      } catch (error) {
        showToast(language === 'ar' ? 'خطأ في الحذف' : 'Error deleting', 'error');
      }
    }
  };

  const getStatusBadge = (entity) => {
    // Show different badge for clients without corporate details
    if (!entity.has_corporate_details) {
      return (
        <span className="px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">
          {language === 'ar' ? 'بدون تفاصيل' : 'No Details'}
        </span>
      );
    }

    const status = entity.corporate_status;
    const styles = {
      active: 'bg-green-100 text-green-800',
      dormant: 'bg-gray-100 text-gray-600',
      liquidating: 'bg-orange-100 text-orange-800',
      struck_off: 'bg-red-100 text-red-800'
    };
    const labels = {
      active: language === 'ar' ? 'نشط' : 'Active',
      dormant: language === 'ar' ? 'خامل' : 'Dormant',
      liquidating: language === 'ar' ? 'تحت التصفية' : 'Liquidating',
      struck_off: language === 'ar' ? 'شُطب' : 'Struck Off'
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs ${styles[status] || styles.active}`}>
        {labels[status] || status}
      </span>
    );
  };

  const formatCurrency = (amount, currency) => {
    if (!amount) return '-';
    return new Intl.NumberFormat(language === 'ar' ? 'ar-SA' : 'en-US', {
      style: 'currency',
      currency: currency || 'USD'
    }).format(amount);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className={`flex justify-between items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
        <h2 className="text-xl font-semibold">{t[language].companies}</h2>
      </div>

      {/* Info message */}
      <div className={`flex items-center gap-2 text-gray-500 ${isRTL ? 'flex-row-reverse text-right' : ''}`} style={{ fontSize: '13px' }}>
        <span>ℹ️</span>
        <span>
          {language === 'ar'
            ? "يتم عرض العملاء الذين نوع خدمتهم 'شركات فقط' أو 'كلاهما'. انقر على صف للتعديل. لإضافة شركة هنا، قم بتحديث نوع الخدمة في قسم العملاء."
            : "Showing clients with Service Type 'Corporate Only' or 'Both'. Click a row to edit. To add a company here, update Service Type in Clients."}
        </span>
      </div>

      {/* Filters */}
      <div className={`flex gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className="flex-1">
          <input
            type="text"
            placeholder={t[language].search}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-3 py-2 border rounded-lg"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 border rounded-lg"
        >
          <option value="all">{t[language].all}</option>
          <option value="no_details">{language === 'ar' ? 'بدون تفاصيل' : 'No Details'}</option>
          <option value="active">{t[language].entityActive || 'Active'}</option>
          <option value="dormant">{t[language].entityDormant || 'Dormant'}</option>
          <option value="liquidating">{t[language].entityLiquidating || 'Liquidating'}</option>
          <option value="struck_off">{t[language].entityStruckOff || 'Struck Off'}</option>
        </select>
      </div>

      {/* List */}
      {filteredEntities.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          <Building2 size={48} className="mx-auto mb-4 opacity-50" />
          <p className="font-medium">{t[language].noEntities || 'No corporate clients found'}</p>
          <p className="text-sm max-w-md mx-auto">
            {language === 'ar'
              ? 'لإظهار العملاء هنا، قم بإنشاء عميل بنوع العميل = كيان قانوني ونوع الخدمة = شركات فقط أو كلاهما.'
              : 'To see clients here, create a client with Client Type = Legal Entity and Service Type = Corporate Only or Both.'}
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className={`px-4 py-3 text-xs font-medium text-gray-500 uppercase ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t[language].client}
                </th>
                <th className={`px-4 py-3 text-xs font-medium text-gray-500 uppercase ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t[language].entityType}
                </th>
                <th className={`px-4 py-3 text-xs font-medium text-gray-500 uppercase ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t[language].registrationNumber}
                </th>
                <th className={`px-4 py-3 text-xs font-medium text-gray-500 uppercase ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t[language].shareCapital}
                </th>
                <th className={`px-4 py-3 text-xs font-medium text-gray-500 uppercase ${isRTL ? 'text-right' : 'text-left'}`}>
                  {t[language].status}
                </th>
                <th className="px-4 py-3 text-xs font-medium text-gray-500 uppercase">
                  {t[language].actions}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredEntities.map(entity => (
                <tr
                  key={entity.client_id}
                  onClick={() => handleEdit(entity)}
                  className={`cursor-pointer hover:bg-blue-50 transition-colors ${!entity.has_corporate_details ? 'bg-yellow-50' : ''}`}
                >
                  <td className={`px-4 py-3 ${isRTL ? 'text-right' : ''}`}>
                    <div className="font-medium">
                      {language === 'ar' && entity.client_name_arabic ? entity.client_name_arabic : entity.client_name}
                      {!entity.has_corporate_details && (
                        <span className={`${isRTL ? 'mr-2' : 'ml-2'} text-xs text-amber-600`}>
                          ({language === 'ar' ? 'يحتاج تفاصيل' : 'needs details'})
                        </span>
                      )}
                    </div>
                  </td>
                  <td className={`px-4 py-3 ${isRTL ? 'text-right' : ''}`}>
                    {language === 'ar' ? entity.entity_type_name_ar : entity.entity_type_name}
                  </td>
                  <td className={`px-4 py-3 ${isRTL ? 'text-right' : ''}`}>
                    {entity.registration_number || '-'}
                  </td>
                  <td className={`px-4 py-3 ${isRTL ? 'text-right' : ''}`}>
                    {formatCurrency(entity.share_capital, entity.share_capital_currency)}
                  </td>
                  <td className={`px-4 py-3 ${isRTL ? 'text-right' : ''}`}>
                    {getStatusBadge(entity)}
                  </td>
                  <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                    <div className="flex gap-2 justify-center">
                      {entity.has_corporate_details ? (
                        <>
                          <button
                            onClick={() => handleEdit(entity)}
                            className="text-blue-600 hover:text-blue-800"
                            title={t[language].edit}
                          >
                            <Edit3 size={16} />
                          </button>
                          <button
                            onClick={() => handleDelete(entity.client_id)}
                            className="text-red-600 hover:text-red-800"
                            title={t[language].delete}
                          >
                            <Trash2 size={16} />
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => handleAddDetails(entity)}
                          className="text-green-600 hover:text-green-800 flex items-center gap-1"
                          title={language === 'ar' ? 'إضافة تفاصيل' : 'Add Details'}
                        >
                          <Plus size={16} />
                          <span className="text-xs">{language === 'ar' ? 'إضافة' : 'Add'}</span>
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
});

export default EntitiesList;
